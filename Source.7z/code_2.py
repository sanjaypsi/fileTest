import os
import sys
import maya.cmds as cmds
from PySide2.QtWidgets import QWidget, QMainWindow
from PySide2 import QtWidgets, QtCore, QtUiTools
import maya.OpenMayaUI as omui
import maya.OpenMaya as om
from shiboken2 import wrapInstance

# ==========================================================================================================
sliderStyleSheet = """
QSlider::groove:horizontal {
    border: 1px solid #999;
    height: 6px;
    background: #ccc;
    margin: 0px;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #5c5c5c;
    border: 1px solid #444;
    width: 14px;
    margin: -5px 0; /* Ensures the handle is properly positioned */
    border-radius: 7px;
}
QSlider::handle:horizontal:hover {
    background: #787878;
    border: 1px solid #555;
}
QSlider::sub-page:horizontal {
    background: #409eff;
    border: 1px solid #5a9;
    height: 6px;
    border-radius: 3px;
}
QSlider::add-page:horizontal {
    background: #ccc;
    border: 1px solid #999;
    height: 6px;
    border-radius: 3px;
}
"""

# ==========================================================================================================
SCRIPT_LOC = os.path.dirname(__file__)
icons = os.path.join(SCRIPT_LOC, 'resource')

# ==========================================================================================================
def get_maya_window():
    """Get Maya's main window as a PySide2 object."""
    main_window_ptr = omui.MQtUtil.mainWindow()
    if not main_window_ptr:
        raise RuntimeError("Failed to obtain Maya's main window.")
    return wrapInstance(int(main_window_ptr), QWidget)

# ==========================================================================================================
def load_ui(ui_file, parent=None):
    """Load the .ui file and return the corresponding widget."""
    loader = QtUiTools.QUiLoader()
    ui_file = QtCore.QFile(ui_file)
    if not ui_file.exists():
        raise FileNotFoundError(f"UI file {ui_file.fileName()} not found.")
    ui_file.open(QtCore.QFile.ReadOnly)
    ui_widget = loader.load(ui_file, parent)
    ui_file.close()
    if not ui_widget:
        raise RuntimeError(f"Failed to load UI file {ui_file.fileName()}.")
    return ui_widget

# ==========================================================================================================
class MyWindow(QMainWindow):
    """Main window class."""
    def __init__(self, parent=None):
        super(MyWindow, self).__init__(parent)
        self.main_ui = os.path.join(SCRIPT_LOC, "ui", "main.ui")
        if not os.path.exists(self.main_ui):
            raise FileNotFoundError(f"UI file not found: {self.main_ui}")
        print(f"Loading UI from: {self.main_ui}")
        self.ui = load_ui(self.main_ui, parent=self)
        if not self.ui:
            raise RuntimeError("UI failed to load.")
        
        # Setup the window
        self.setWindowTitle("Master File Manager ver2.0")
        self.resize(500, 700)
        self.setCentralWidget(self.ui)
        self.init_ui()

        # Example spheres and their sliders/labels
        self.sphere_sliders = {
            "pSphere1": {"slider": self.ui.slider1, "label": self.ui.label1, "attribute": "translateX"},
            "pSphere2": {"slider": self.ui.slider2, "label": self.ui.label2, "attribute": "translateY"}
        }

        self.callbacks = []
        self.create_connections()
        self.create_callbacks()

    def init_ui(self):
        """Initialize the UI."""
        self.ui.destroyed.connect(self.on_exit_code)
        for sphere, components in self.sphere_sliders.items():
            slider = components["slider"]
            slider.setGeometry(10, 10, 300, 40)
            slider.setStyleSheet(sliderStyleSheet)
            slider.setMaximum(1000)
            slider.setMinimum(-1000)
            label = components["label"]
            label.setText(f"{sphere}: 0.0")

    def create_connections(self):
        """Create the signal/slot connections for each slider."""
        for sphere, components in self.sphere_sliders.items():
            slider = components["slider"]
            slider.valueChanged.connect(lambda value, sp=sphere: self.update_sphere_attribute(sp, value))

    def update_sphere_attribute(self, sphere, slider_value):
        """Update the specified sphere's attribute when the slider is moved."""
        components  = self.sphere_sliders[sphere]
        attribute   = components["attribute"]
        label       = components["label"]
        value       = slider_value / 10.0

        cmds.setAttr(f"{sphere}.{attribute}", value)
        label.setText(f"{sphere}: {value:.2f}")

    def on_exit_code(self):
        """Cleanup when the UI is closed."""
        sys.stdout.write("UI successfully closed\n")
        self.deleteLater()

    def create_callbacks(self):
        """Create callbacks for all spheres to monitor attribute changes."""
        for sphere, components in self.sphere_sliders.items():
            try:
                selection_list = om.MSelectionList()
                selection_list.add(sphere)
                node = om.MObject()
                selection_list.getDependNode(0, node)
                callback_id = om.MNodeMessage.addAttributeChangedCallback(
                    node, self.on_attribute_change, sphere
                )
                self.callbacks.append(callback_id)
            except RuntimeError:
                cmds.warning(f"Sphere '{sphere}' not found in the scene.")
    
    def on_attribute_change(self, msg, plug, other_plug, client_data):
        """Update the slider and label when the attribute changes."""
        sphere = client_data
        if sphere in self.sphere_sliders:
            components  = self.sphere_sliders[sphere]
            attribute   = components["attribute"]
            slider      = components["slider"]
            label       = components["label"]

            node_fn = om.MFnDependencyNode(plug.node())
            translate_plug = node_fn.findPlug(attribute, False)
            if plug == translate_plug:
                value = cmds.getAttr(f"{sphere}.{attribute}")
                slider.blockSignals(True)
                slider.setValue(int(value * 10))  # Match slider granularity
                slider.blockSignals(False)
                label.setText(f"{sphere}: {value:.2f}")

    def closeEvent(self, event):
        """Cleanup callbacks when the window is closed."""
        for callback_id in self.callbacks:
            om.MMessage.removeCallback(callback_id)
        self.callbacks = []
        event.accept()

# ==========================================================================================================
def show_window():
    """Show the window."""
    global my_window
    if 'my_window' in globals() and my_window is not None:
        try:
            my_window.close()  # Close the window if it already exists
            my_window.deleteLater()
            
        except:
            pass

    my_window = MyWindow(parent=get_maya_window())
    my_window.show()
