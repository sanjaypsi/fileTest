import logging
import maya.OpenMaya as om
import maya.cmds as cmds


class CallbackManager:
    """Manages Maya attribute callbacks."""

    def __init__(self):
        self.callback_id_map = {}  # Store callback IDs for cleanup

    def create_callback(self, node_name, attr_name, callback_func, default_range=(0.0, 10.0), query_range=True):
        """
        Create a callback for a specific attribute on a node.

        Args:
            node_name (str): Name of the Maya node.
            attr_name (str): Name of the attribute to monitor.
            callback_func (callable): Function to call when the attribute changes.
            default_range (tuple): Default range to use if the attribute range cannot be queried.
            query_range (bool): Whether to dynamically query the attribute range (default: True).

        Returns:
            bool: True if the callback was successfully created, False otherwise.
        """
        try:
            if not cmds.objExists(node_name):
                logging.warning(f"Node '{node_name}' does not exist.")
                return False

            if not cmds.attributeQuery(attr_name, node=node_name, exists=True):
                logging.warning(f"Attribute '{attr_name}' does not exist on node '{node_name}'.")
                return False

            # Query attribute range if enabled
            attr_range = default_range
            if query_range and cmds.attributeQuery(attr_name, node=node_name, range=True):
                attr_range = cmds.attributeQuery(attr_name, node=node_name, range=True)
            else:
                logging.warning(f"Cannot query range for attribute '{node_name}.{attr_name}'. Using default range {default_range}.")

            # Get MObject for node
            mobject = self._get_mobject(node_name)
            if not mobject or mobject.isNull():
                logging.error(f"Failed to retrieve a valid MObject for node '{node_name}'.")
                return False

            # Create the callback
            callback_id = om.MNodeMessage.addAttributeChangedCallback(
                mobject,
                lambda msg, plug, other_plug: callback_func(msg, plug, other_plug, attr_range)
            )
            self.callback_id_map[f"{node_name}.{attr_name}"] = callback_id
            logging.info(f"Callback created for {node_name}.{attr_name}. Range: {attr_range}")
            return True
        except Exception as e:
            logging.error(f"Error creating callback for {node_name}.{attr_name}: {e}")
            return False

    def create_callbacks(self, node_name, attributes, callback_func, default_range=(0.0, 10.0), query_range=True):
        """
        Create callbacks for multiple attributes on a node.

        Args:
            node_name (str): Name of the Maya node.
            attributes (list): List of attribute names to monitor.
            callback_func (callable): Function to call when any of the attributes change.
            default_range (tuple): Default range to use if the attribute range cannot be queried.
            query_range (bool): Whether to dynamically query the attribute range (default: True).
        """
        for attr_name in attributes:
            self.create_callback(node_name, attr_name, callback_func, default_range, query_range)

    def remove_callback(self, node_name, attr_name):
        """
        Remove a specific callback for an attribute.

        Args:
            node_name (str): Name of the Maya node.
            attr_name (str): Name of the attribute.
        """
        key = f"{node_name}.{attr_name}"
        if key in self.callback_id_map:
            try:
                om.MMessage.removeCallback(self.callback_id_map[key])
                del self.callback_id_map[key]
                logging.info(f"Callback removed for {key}.")
            except Exception as e:
                logging.error(f"Error removing callback for {key}: {e}")

    def remove_all_callbacks(self):
        """Remove all registered Maya callbacks."""
        for key, callback_id in list(self.callback_id_map.items()):
            try:
                om.MMessage.removeCallback(callback_id)
                logging.info(f"Callback removed for {key}.")
                del self.callback_id_map[key]
            except Exception as e:
                logging.error(f"Error removing callback for {key}: {e}")

    def _get_mobject(self, node_name):
        """
        Get the MObject for a Maya node.

        Args:
            node_name (str): The name of the Maya node.

        Returns:
            MObject: The MObject for the specified node, or None if not found.
        """
        try:
            sel_list = om.MSelectionList()
            sel_list.add(node_name)
            mobject = om.MObject()
            sel_list.getDependNode(0, mobject)
            return mobject
        except RuntimeError as e:
            logging.error(f"Failed to get MObject for node '{node_name}': {e}")
            return None


# Sample usage:
def attribute_changed_callback(msg, plug, other_plug, attr_range):
    """Callback function to handle attribute changes."""
    if msg & om.MNodeMessage.kAttributeSet:
        node_name = om.MFnDependencyNode(plug.node()).name()
        attr_name = plug.partialName()
        value = cmds.getAttr(f"{node_name}.{attr_name}")
        logging.info(f"Attribute {node_name}.{attr_name} changed to {value}. Range: {attr_range}")

# Create the callback manager and register a callback
manager = CallbackManager()
manager.create_callback("con_world_L", "all_scale", attribute_changed_callback)
manager.create_callback("con_world_L", "all_translate", attribute_changed_callback)

# Create multiple callbacks for a node
manager.create_callbacks("con_world_L", ["all_scale", "all_translate"], attribute_changed_callback)

# Clean up all callbacks when done
manager.remove_all_callbacks()
