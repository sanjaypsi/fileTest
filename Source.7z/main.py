import os
import sys
from PySide2.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel, QSlider
)
from PySide2 import QtUiTools, QtCore  # Ensure QtCore is imported
import maya.OpenMayaUI as omui
from shiboken2 import wrapInstance
import importlib

# Import external widget module
import LoadCollapsed_widget
importlib.reload(LoadCollapsed_widget)

SCRIPT_LOC = os.path.dirname(__file__)
collapseWidgetUI = os.path.join(SCRIPT_LOC, 'ui', 'collapsible_widget.ui')

sliderStyleSheet = """
                QSlider::groove:horizontal {
                    border: 1px solid #999;
                    height: 6px;
                    background: #ccc;
                    margin: 0px;
                    border-radius: 3px;
                }
                QSlider::handle:horizontal {
                    background: #5c5c5c;
                    border: 1px solid #444;
                    width: 14px;
                    margin: -5px 0; /* Ensures the handle is properly positioned */
                    border-radius: 7px;
                }
                QSlider::handle:horizontal:hover {
                    background: #787878;
                    border: 1px solid #555;
                }
                QSlider::sub-page:horizontal {
                    background: #409eff;
                    border: 1px solid #5a9;
                    height: 6px;
                    border-radius: 3px;
                }
                QSlider::add-page:horizontal {
                    background: #ccc;
                    border: 1px solid #999;
                    height: 6px;
                    border-radius: 3px;
                }
                """

class CollapsibleTab(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.setLayout(self.layout)
        self.toggle_button = QPushButton(title)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(True)
        self.toggle_button.clicked.connect(self.toggle_content)
        self.content_area = QWidget()
        self.content_layout = QVBoxLayout(self.content_area)
        self.content_area.setLayout(self.content_layout)
        self.layout.addWidget(self.toggle_button)
        self.layout.addWidget(self.content_area)

    def toggle_content(self):
        """Toggle the visibility of the content area."""
        self.content_area.setVisible(self.toggle_button.isChecked())


def get_maya_window():
    """Get Maya's main window as a PySide2 object."""
    main_window_ptr = omui.MQtUtil.mainWindow()
    if not main_window_ptr:
        raise RuntimeError("Failed to obtain Maya's main window.")
    return wrapInstance(int(main_window_ptr), QWidget)


def load_ui(ui_file, parent=None):
    """Load the .ui file and return the corresponding widget."""
    loader = QtUiTools.QUiLoader()
    ui_file = QtCore.QFile(ui_file)
    if not ui_file.exists():
        raise FileNotFoundError(f"UI file {ui_file.fileName()} not found.")
    ui_file.open(QtCore.QFile.ReadOnly)
    ui_widget = loader.load(ui_file, parent)
    ui_file.close()
    if not ui_widget:
        raise RuntimeError(f"Failed to load UI file {ui_file.fileName()}.")
    return ui_widget


class MyWindow(QMainWindow):
    """Main window class."""
    def __init__(self, parent=None):
        super(MyWindow, self).__init__(parent)
        self.main_ui = os.path.join(SCRIPT_LOC, "ui", "main01.ui")
        if not os.path.exists(self.main_ui):
            raise FileNotFoundError(f"UI file not found: {self.main_ui}")
        print(f"Loading UI from: {self.main_ui}")
        
        self.ui = load_ui(self.main_ui, parent=self)
        self.setWindowTitle("Master File Manager ver2.0")
        self.resize(500, 700)
        self.setCentralWidget(self.ui)

        # Setup collapsible tabs
        self.add_uiWidget()

    def add_uiWidget(self):
        """Add collapsible functionality to the layout."""
        # Retrieve collapsible widget from external module
        self.collapseWidgets 	= LoadCollapsed_widget._loadWidget(widgetCollapse=collapseWidgetUI)
        self.getUIWidget 		= self.collapseWidgets._loadUI()
        self.getUIWidget.setMinimumHeight(150)
        self.getUIWidget.setMinimumWidth(150)
        
        # Create a sphere in Maya
        import maya.cmds as cmds
        sphere = cmds.polySphere()[0]  # Create a polygon sphere and get its name
        
        # Loop through all sliders and connect each one to print its name and move the sphere
        slider_widgets = [getattr(self.getUIWidget, "sliderSacler_3", None)]  # Add more sliders if needed
        
        for slider_widget in slider_widgets:
            if slider_widget is None:
                print("Slider widget not found")
            else:
                slider_widget.setStyleSheet(sliderStyleSheet)

                # Function to print active widget's name and update translateX of the sphere
                def update_translateX(value, name=slider_widget.objectName()):
                    print(f"Slider '{name}' moved to value: {value}")
                    cmds.setAttr(f"{sphere}.translateX", value)

                # Connect the slider's value to the update function
                slider_widget.valueChanged.connect(lambda value: update_translateX(value))

                # Print the name of the slider when it's activated
                slider_widget.valueChanged.connect(lambda: self.print_active_widget(slider_widget))

        # Attach to the existing layout
        layout = getattr(self.ui, "verticalLayout", None)
        if layout is None:
            layout = QVBoxLayout(self.ui)
            self.ui.setLayout(layout)

        # Add collapsible tab
        tab1 = CollapsibleTab("Tab 1")
        tab1.content_layout.addWidget(self.getUIWidget)
        layout.addWidget(tab1)

        tab2 = CollapsibleTab("Tab 2")
        tab2.content_layout.addWidget(QLabel("This is the content of Tab 2."))
        layout.addWidget(tab2)
        
        tab3 = CollapsibleTab("Tab hh")
        tab3.content_layout.addWidget(QLabel("This is the content of Tab 3."))
        layout.addWidget(tab3)
        
        layout.addStretch()

    def print_active_widget(self, widget):
        """Print the name of the active widget when it is interacted with."""
        print(f"Active widget: {widget.objectName()}")


def show_window():
    """Show the window."""
    parent = get_maya_window()
    for child in parent.findChildren(MyWindow):
        child.close()
    window = MyWindow(parent=parent)
    window.show()
