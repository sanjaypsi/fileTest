
import os
import sys
import maya.cmds as cmds
from PySide2.QtWidgets import QWidget, QMainWindow
from PySide2 import QtWidgets, QtCore, QtUiTools
import maya.OpenMayaUI as omui
import maya.OpenMaya as om
from shiboken2 import wrapInstance

class MyWindow(QMainWindow):
    def __init__(self, parent=None):
        super(MyWindow, self).__init__(parent)
        self.callback_id_map = {}  # Store callback IDs for cleanup

        # Map sliders to control attributes
        self.slider_control_map = {
            "sliderSacler01": "con_world_L.all_scale",
            "sliderSacler02": "con_world_L.all_translate",
        }

        # Setup UI and connections
        self.setup_ui()
        self.connect_to_controls()
        self.create_callbacks()

    def setup_ui(self):
        """Load and initialize the UI."""
        loader = QtUiTools.QUiLoader()
        ui_path = os.path.join(os.path.dirname(__file__), "your_ui_file.ui")
        self.ui = loader.load(ui_path, self)

    def connect_to_controls(self):
        """Connect sliders and QLineEdits dynamically to Maya attributes."""
        float_min, float_max = 0.0, 10.0

        for slider_name, control_attr in self.slider_control_map.items():
            # Get the slider and QLineEdit widgets
            slider = getattr(self.ui, slider_name, None)
            line_edit_name = f"{slider_name}_LineEdit"
            line_edit = getattr(self.ui, line_edit_name, None)

            if not slider or not line_edit:
                print(f"Error: {slider_name} or {line_edit_name} widget not found!")
                continue

            # Connect slider value change to update Maya attribute
            slider.valueChanged.connect(
                lambda value, attr=control_attr: cmds.setAttr(
                    attr, float_min + value * (float_max - float_min) / 100.0
                )
            )

            # Connect slider value change to update QLineEdit
            slider.valueChanged.connect(
                lambda value, le=line_edit: le.setText(
                    f"{float_min + value * (float_max - float_min) / 100.0:.2f}"
                )
            )

            # Initialize QLineEdit with the slider's current value
            line_edit.setText(
                f"{float_min + slider.value() * (float_max - float_min) / 100.0:.2f}"
            )

            # Connect QLineEdit editingFinished to update slider and Maya attribute
            line_edit.editingFinished.connect(
                lambda le=line_edit, sl=slider, attr=control_attr: self.update_slider_from_line_edit(
                    le, sl, float_min, float_max, attr
                )
            )

    def update_slider_from_line_edit(self, line_edit, slider, float_min, float_max, attr):
        """Update slider and Maya attribute based on QLineEdit value."""
        try:
            value = float(line_edit.text())
            if float_min <= value <= float_max:
                slider_value = int((value - float_min) / (float_max - float_min) * 100)
                slider.blockSignals(True)
                slider.setValue(slider_value)
                slider.blockSignals(False)
                cmds.setAttr(attr, value)
            else:
                cmds.warning(
                    f"Value out of range ({float_min}-{float_max})."
                )
        except ValueError:
            cmds.warning("Invalid input. Please enter a valid float.")

    def on_attribute_change(self, msg, plug, other_plug, client_data):
        """Update sliders and QLineEdits when their associated Maya attributes change."""
        node_fn = om.MFnDependencyNode(client_data)
        for slider_name, control_attr in self.slider_control_map.items():
            attribute = control_attr.split('.')[-1]
            control_node = control_attr.split('.')[0]

            attr_plug = node_fn.findPlug(attribute, False)
            if plug == attr_plug:
                value = cmds.getAttr(control_attr)

                slider = getattr(self.ui, slider_name, None)
                line_edit_name = f"{slider_name}_LineEdit"
                line_edit = getattr(self.ui, line_edit_name, None)

                if slider:
                    slider.blockSignals(True)
                    slider.setValue(int(value * 10))  # Match slider granularity
                    slider.blockSignals(False)

                if line_edit:
                    line_edit.setText(f"{value:.2f}")

    def create_callbacks(self):
        """Create callbacks to monitor changes for all control attributes."""
        for slider_name, control_attr in self.slider_control_map.items():
            control_node = control_attr.split('.')[0]
            attribute = control_attr.split('.')[-1]

            selection_list = om.MSelectionList()
            try:
                selection_list.add(control_node)
            except RuntimeError:
                cmds.warning(f"Node '{control_node}' not found in the scene.")
                continue

            node = om.MObject()
            selection_list.getDependNode(0, node)
            callback_id = om.MNodeMessage.addAttributeChangedCallback(
                node, self.on_attribute_change, node
            )
            self.callback_id_map[slider_name] = callback_id
            print(f"Callback created for {control_node}.{attribute}")

    def closeEvent(self, event):
        """Clean up callbacks when the window is closed."""
        for callback_id in self.callback_id_map.values():
            om.MMessage.removeCallback(callback_id)
        self.callback_id_map.clear()
        event.accept()
