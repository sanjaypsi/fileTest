from PySide2.QtCore import QtWidgets
from PySide2.QtCore import QtGui
from astlib.ui import BaseWidget


class CollapsibleWidget(BaseWidget):
    def __init__(self, label="", parent=None, ui_file='ui/collapsible_widget.ui', **kwargs):
        super(CollapsibleWidget, self).__init__(parent=parent, ui_file=ui_file, **kwargs)
        self._collapsed_icon = None
        self._expanded_icon = None
        self._initialize_connections()
        # self._setup_icons()
        self.header_pb.setChecked(True)
        if label:
            self.set_text(label)

    def _initialize_connections(self):
        self.header_pb.toggled.connect(self.toggle_content_widget)

    def _setup_icons(self):
        collapsed_icon_file = 'D:/icons/grid_white_1.png'
        self._collapsed_icon = QtGui.QIcon(collapsed_icon_file)

        expanded_icon_file = 'D:/icons/down_arrow.png'
        self._expanded_icon = QtGui.QIcon(expanded_icon_file)

    def set_text(self, text):
        self.header_pb.setText(text)

    def add_child_widget(self, widget):
        self.content_layout.addWidget(widget)

    def toggle_content_widget(self, value):
        self.content_wgt.setVisible(value)
        icon = self._expanded_icon if value else self._collapsed_icon
        self.header_pb.setIcon(icon)


def main():
    app = QtWidgets.QApplication([])
    win = CollapsibleWidget('Viewer')
    btn = QtWidgets.QPushButton('test')
    btn2 = QtWidgets.QPushButton('test')
    btn3 = QtWidgets.QPushButton('test')
    win.add_child_widget(btn)
    win.add_child_widget(btn2)
    win.add_child_widget(btn3)
    win.show()
    app.exec_()


# if __name__ == '__main__':
#     main()


