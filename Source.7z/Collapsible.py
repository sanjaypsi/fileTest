from PySide2.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QFrame, QPushButton, QLabel, QWidget
from PySide2 import QtCore

class CollapsibleTab(QFrame):
    def __init__(self, title, parent=None):
        super().__init__(parent)

        # Style the QFrame
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        # self.setStyleSheet("background-color: #f0f0f0; border: 1px solid #ccc;")

        # Layout for the collapsible tab
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # Toggle Button
        self.toggle_button = QPushButton(title, self)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(True)
        self.toggle_button.clicked.connect(self.toggle_content)

        # Content Area
        self.content_area = QWidget(self)
        self.content_layout = QVBoxLayout(self.content_area)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_area.setLayout(self.content_layout)

        # Add the toggle button and content area to the layout
        self.main_layout.addWidget(self.toggle_button)
        self.main_layout.addWidget(self.content_area)

    def toggle_content(self):
        """Toggle the visibility of the content area and update the size."""
        is_expanded = self.toggle_button.isChecked()
        self.content_area.setVisible(is_expanded)
        self.updateGeometry()  # Adjust size hints when collapsing/expanding

