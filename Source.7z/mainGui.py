from PySide2 import QtWidgets, QtCore
from shiboken2 import wrapInstance
import maya.OpenMayaUI as omui
import maya.cmds as cmds

def get_maya_main_window():
    """
    Get Maya's main window as a PySide2 widget.
    """
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)

class MyMayaWindow(QtWidgets.QDialog):
    def __init__(self, parent=get_maya_main_window()):
        super(MyMayaWindow, self).__init__(parent)

        self.setWindowTitle("Fully Synced Slider with connectControl")
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.setMinimumSize(300, 150)

        # Layout
        self.layout = QtWidgets.QVBoxLayout(self)

        # Label to display the slider value
        self.slider_label = QtWidgets.QLabel("Slider Value: 1.0")
        self.layout.addWidget(self.slider_label)

        # Add Maya's native slider using cmds.floatSliderGrp
        self.slider_name = "customSlider"  # Unique name for the slider
        self._add_maya_slider()

        # Create  connect it to the slider
        self._connectLayout()

    def _add_maya_slider(self):
        """
        Add a Maya floatSliderGrp and embed it into the PySide2 dialog.
        """
        if cmds.control(self.slider_name, exists=True):
            cmds.deleteUI(self.slider_name)

        self.slider_widget = cmds.floatSliderGrp(self.slider_name,
                            label           ="Control Slider",
                            minValue        =0.1,
                            maxValue        =10.0,
                            field           =True,
                            value           =1.0,
                            changeCommand   =self._update_label  # Updates the label on value change
        )
        slider_ptr = omui.MQtUtil.findControl(self.slider_name)
        if slider_ptr:
            slider_widget = wrapInstance(int(slider_ptr), QtWidgets.QWidget)
            self.layout.addWidget(slider_widget)

    def _connectLayout(self):
        _cntName = 'con_upArm_L'
        # Connect the slider to the sphere's scaleY attribute
        cmds.connectControl(self.slider_name, f"{_cntName}.size")

    def _update_label(self, *args):
        """
        Update the label to display the current slider value.
        """
        slider_value = cmds.floatSliderGrp(self.slider_name, query=True, value=True)
        self.slider_label.setText(f"Slider Value: {slider_value:.1f}")

def show_window():
    """
    Show the PySide2 GUI window.
    """
    # Close any existing window
    for widget in QtWidgets.QApplication.topLevelWidgets():
        if isinstance(widget, MyMayaWindow):
            widget.close()
            widget.deleteLater()

    # Create and show the new window
    window = MyMayaWindow()
    window.show()
