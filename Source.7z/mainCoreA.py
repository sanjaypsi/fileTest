import maya.api.OpenMaya as om
import maya.cmds as cmds
import shiboken2
import weakref
import logging
from PySide2 import QtWidgets, QtCore

logging.basicConfig(level=logging.INFO)


class MayaSliderUI(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(MayaSliderUI, self).__init__(parent)
        self.setWindowTitle("Slider UI")
        self.setMinimumSize(300, 200)

        # Initialize UI elements
        self.layout = QtWidgets.QVBoxLayout(self)
        self.sliders = {}
        self.line_edits = {}
        self.slider_control_map = {}
        self.callback_id_map = {}

        self.create_ui()
        self.create_callbacks()

    def create_ui(self):
        """Create sliders and line edits dynamically."""
        attributes = ["pCube1.translateX", "pCube1.translateY", "pCube1.translateZ"]

        for attr in attributes:
            slider_name = f"{attr.replace('.', '_')}_slider"
            line_edit_name = f"{attr.replace('.', '_')}_lineEdit"

            # Create slider
            slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
            slider.setRange(0, 100)
            slider.valueChanged.connect(self.on_slider_value_changed)
            self.layout.addWidget(slider)

            # Create line edit
            line_edit = QtWidgets.QLineEdit()
            line_edit.editingFinished.connect(self.on_line_edit_changed)
            self.layout.addWidget(line_edit)

            # Store references
            self.sliders[slider_name] = slider
            self.line_edits[line_edit_name] = line_edit
            self.slider_control_map[slider_name] = attr

    def create_callbacks(self):
        """Create Maya callbacks for attribute changes."""
        self.weak_self = weakref.ref(self)

        for slider_name, control_attr in self.slider_control_map.items():
            try:
                node, attr = control_attr.split('.', 1)
                mobject = self.get_mobject(node)

                if not mobject or mobject.isNull():
                    continue

                callback_id = om.MNodeMessage.addAttributeChangedCallback(
                    mobject,
                    lambda msg, plug, otherPlug, attr=control_attr: self.weak_self().on_attribute_changed(msg, plug, attr)
                )
                self.callback_id_map[control_attr] = callback_id
            except Exception as e:
                logging.error(f"Error creating callback for '{control_attr}': {e}")

    def on_slider_value_changed(self):
        """Handle slider value changes."""
        slider = self.sender()
        if not slider:
            return

        for slider_name, control_attr in self.slider_control_map.items():
            if self.sliders[slider_name] == slider:
                try:
                    float_min = 0.0
                    float_max = 10.0
                    value = slider.value() / 100 * (float_max - float_min) + float_min
                    cmds.setAttr(control_attr, value)
                except Exception as e:
                    logging.error(f"Error setting attribute '{control_attr}': {e}")
                break

    def on_line_edit_changed(self):
        """Handle line edit value changes."""
        line_edit = self.sender()
        if not line_edit:
            return

        for line_edit_name, control_attr in self.slider_control_map.items():
            if self.line_edits[line_edit_name] == line_edit:
                try:
                    value = float(line_edit.text())
                    cmds.setAttr(control_attr, value)

                    slider_name = line_edit_name.replace("lineEdit", "slider")
                    slider = self.sliders.get(slider_name)
                    if slider and not shiboken2.isdeleted(slider):
                        float_min = 0.0
                        float_max = 10.0
                        slider_value = int((value - float_min) / (float_max - float_min) * 100)
                        slider.setValue(slider_value)
                except Exception as e:
                    logging.error(f"Error updating attribute '{control_attr}': {e}")
                break

    def on_attribute_changed(self, msg, plug, control_attr):
        """Callback triggered when a Maya attribute is changed."""
        if not (msg & om.MNodeMessage.kAttributeSet):
            return

        try:
            for slider_name, mapped_attr in self.slider_control_map.items():
                if mapped_attr == control_attr:
                    slider = self.sliders.get(slider_name)
                    line_edit_name = slider_name.replace("slider", "lineEdit")
                    line_edit = self.line_edits.get(line_edit_name)

                    if slider and not shiboken2.isdeleted(slider) and line_edit and not shiboken2.isdeleted(line_edit):
                        value = cmds.getAttr(control_attr)
                        self.update_ui_elements(slider, line_edit, value)
        except Exception as e:
            logging.error(f"Error handling attribute change for '{control_attr}': {e}")

    def update_ui_elements(self, slider, line_edit, value, float_min=0.0, float_max=10.0):
        """Safely update UI elements."""
        try:
            slider_value = int((value - float_min) / (float_max - float_min) * 100)
            if slider and not shiboken2.isdeleted(slider):
                slider.setValue(slider_value)
            if line_edit and not shiboken2.isdeleted(line_edit):
                line_edit.setText(f"{value:.2f}")
        except Exception as e:
            logging.error(f"Error updating UI elements: {e}")

    def disconnect_signals(self):
        """Disconnect all signals to prevent accessing deleted widgets."""
        for slider_name, slider in self.sliders.items():
            try:
                slider.valueChanged.disconnect()
            except TypeError:
                pass  # Signal was not connected

        for line_edit_name, line_edit in self.line_edits.items():
            try:
                line_edit.editingFinished.disconnect()
            except TypeError:
                pass  # Signal was not connected

    def remove_callbacks(self):
        """Remove Maya callbacks."""
        for control_attr, callback_id in self.callback_id_map.items():
            try:
                om.MMessage.removeCallback(callback_id)
            except Exception as e:
                logging.error(f"Error removing callback for '{control_attr}': {e}")

        self.callback_id_map.clear()

    def get_mobject(self, node_name):
        """Get the MObject for a Maya node."""
        try:
            selection_list = om.MSelectionList()
            selection_list.add(node_name)
            return selection_list.getDependNode(0)
        except Exception as e:
            logging.error(f"Error getting MObject for node '{node_name}': {e}")
            return None

    def closeEvent(self, event):
        """Handle UI closure."""
        self.disconnect_signals()
        self.remove_callbacks()
        super(MayaSliderUI, self).closeEvent(event)


# To run the UI
def show_ui():
    global slider_ui
    try:
        slider_ui.close()
    except:
        pass

    slider_ui = MayaSliderUI()
    slider_ui.show()


# Call `show_ui()` to display the UI in Maya.
