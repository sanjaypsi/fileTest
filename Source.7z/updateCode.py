from PySide2 import QtWidgets, QtCore
from shiboken2 import wrapInstance
import maya.OpenMayaUI as omui
import maya.cmds as cmds

def get_maya_main_window():
    """
    Get Maya's main window as a PySide2 widget.
    """
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)

class MyMayaWindow(QtWidgets.QDialog):
    def __init__(self, parent=get_maya_main_window()):
        super(MyMayaWindow, self).__init__(parent)

        self.setWindowTitle("Two Synced Sliders with connectControl")
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.setMinimumSize(300, 200)

        # Layout
        self.layout = QtWidgets.QVBoxLayout(self)

        # Label to display the slider values
        self.slider1_label = QtWidgets.QLabel("Slider 1 Value (Scale Y): 1.0")
        self.layout.addWidget(self.slider1_label)

        self.slider2_label = QtWidgets.QLabel("Slider 2 Value (Scale Z): 1.0")
        self.layout.addWidget(self.slider2_label)

        self.slider3_label = QtWidgets.QLabel("Slider 2 Value (Scale Z): 1.0")
        self.layout.addWidget(self.slider2_label)

        # Add Maya's native sliders
        self.slider1_name = "customSlider1"
        self.slider2_name = "customSlider2"
        self.slider3_name = "customSlider3"

        self.add_maya_slider(self.slider1_name, "Scale Y", self.update_label1)
        self.add_maya_slider(self.slider2_name, "Scale Z", self.update_label2)
        self.add_maya_slider(self.slider3_name, "Scale X", self.update_label3)

        # Create a sphere and connect it to the sliders
        self.create_sphere()

    def add_maya_slider(self, slider_name, label_text, change_command):
        """
        Add a Maya floatSliderGrp and embed it into the PySide2 dialog.
        """
        if cmds.control(slider_name, exists=True):
            cmds.deleteUI(slider_name)

        slider_widget = cmds.floatSliderGrp(
            slider_name,
            label=label_text,
            minValue=0.1,
            maxValue=10.0,
            field=True,
            value=1.0,
            changeCommand=change_command
        )
        slider_ptr = omui.MQtUtil.findControl(slider_name)
        if slider_ptr:
            slider_widget = wrapInstance(int(slider_ptr), QtWidgets.QWidget)
            self.layout.addWidget(slider_widget)

    def create_sphere(self):
        """
        Create a sphere and connect it to the sliders' scale attributes.
        """
        sphere_name = "pSphere1"
        if not cmds.objExists(sphere_name):
            cmds.polySphere(name=sphere_name)

        # Connect sliders to the sphere's attributes
        cmds.connectControl(self.slider1_name, f"{sphere_name}.scaleY")
        cmds.connectControl(self.slider2_name, f"{sphere_name}.scaleZ")
        cmds.connectControl(self.slider3_name, f"{sphere_name}.scaleX")

    def update_label1(self, *args):
        """
        Update the label for slider 1 to display the current slider value.
        """
        slider_value = cmds.floatSliderGrp(self.slider1_name, query=True, value=True)
        self.slider1_label.setText(f"Slider 1 Value (Scale Y): {slider_value:.1f}")

    def update_label2(self, *args):
        """
        Update the label for slider 2 to display the current slider value.
        """
        slider_value = cmds.floatSliderGrp(self.slider2_name, query=True, value=True)
        self.slider2_label.setText(f"Slider 2 Value (Scale Z): {slider_value:.1f}")

    def update_label3(self, *args):
        """
        Update the label for slider 2 to display the current slider value.
        """
        slider_value = cmds.floatSliderGrp(self.slider3_name, query=True, value=True)
        self.slider3_label.setText(f"Slider 2 Value (Scale Z): {slider_value:.1f}")

def show_window():
    """
    Show the PySide2 GUI window.
    """
    # Close any existing window
    for widget in QtWidgets.QApplication.topLevelWidgets():
        if isinstance(widget, MyMayaWindow):
            widget.close()
            widget.deleteLater()

    # Create and show the new window
    window = MyMayaWindow()
    window.show()
