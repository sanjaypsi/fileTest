from PySide2 import QtWidgets, QtCore
from shiboken2 import wrapInstance
import maya.OpenMayaUI as omui
import maya.cmds as cmds

def get_maya_main_window():
    """
    Get Maya's main window as a PySide2 widget.
    """
    main_window_ptr = omui.MQtUtil.mainWindow()
    return wrapInstance(int(main_window_ptr), QtWidgets.QWidget)

class MyMayaWindow(QtWidgets.QDialog):
    def __init__(self, parent=get_maya_main_window()):
        super(MyMayaWindow, self).__init__(parent)

        self.setWindowTitle("Generalized Sliders with connectControl")
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.setMinimumSize(300, 400)

        # Layout
        self.layout = QtWidgets.QVBoxLayout(self)

        # Slider configuration: slider_name -> Maya attribute
        self.sliders_config = {
            "customSliderScaleX": ("scaleX", "Scale X"),
            "customSliderScaleY": ("scaleY", "Scale Y"),
            "customSliderScaleZ": ("scaleZ", "Scale Z"),
            "customSliderTranslateX": ("translateX", "Translate X"),
            "customSliderTranslateY": ("translateY", "Translate Y"),
            "customSliderTranslateZ": ("translateZ", "Translate Z"),
        }

        # Labels dictionary
        self.labels = {}

        # Create sliders and labels dynamically
        for slider_name, (attr, label_text) in self.sliders_config.items():
            self.labels[slider_name] = QtWidgets.QLabel(f"{label_text} Value: 1.0")
            self.layout.addWidget(self.labels[slider_name])
            self.add_maya_slider(slider_name, label_text)

        # Create a sphere and connect it to the sliders
        self.create_sphere()

    def add_maya_slider(self, slider_name, label_text):
        """
        Add a Maya floatSliderGrp and embed it into the PySide2 dialog.
        """
        if cmds.control(slider_name, exists=True):
            cmds.deleteUI(slider_name)

        slider_widget = cmds.floatSliderGrp(
            slider_name,
            label=label_text,
            minValue=0.1,
            maxValue=10.0,
            field=True,
            value=1.0,
            changeCommand=lambda *args: self.update_label(slider_name)  # Pass slider name
        )
        slider_ptr = omui.MQtUtil.findControl(slider_name)
        if slider_ptr:
            slider_widget = wrapInstance(int(slider_ptr), QtWidgets.QWidget)
            self.layout.addWidget(slider_widget)

    def create_sphere(self):
        """
        Create a sphere and connect it to the sliders' attributes.
        """
        self.sphere_name = "pSphere1"
        if not cmds.objExists(self.sphere_name):
            cmds.polySphere(name=self.sphere_name)

        # Connect each slider to the respective attribute
        for slider_name, (attr, _) in self.sliders_config.items():
            cmds.connectControl(slider_name, f"{self.sphere_name}.{attr}")

    def update_label(self, slider_name):
        """
        Update the label corresponding to the slider dynamically.
        """
        slider_value = cmds.floatSliderGrp(slider_name, query=True, value=True)
        if slider_name in self.labels:
            attr_name = self.sliders_config[slider_name][1]
            self.labels[slider_name].setText(f"{attr_name} Value: {slider_value:.1f}")

def show_window():
    """
    Show the PySide2 GUI window.
    """
    # Close any existing window
    for widget in QtWidgets.QApplication.topLevelWidgets():
        if isinstance(widget, MyMayaWindow):
            widget.close()
            widget.deleteLater()

    # Create and show the new window
    window = MyMayaWindow()
    window.show()
