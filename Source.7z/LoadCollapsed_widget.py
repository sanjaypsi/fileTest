import os
from PySide2 import QtCore, QtUiTools, QtWidgets

class _loadWidget(object):
    def __init__(self, widgetCollapse=None, parent=None, geometry=None):
        """
        Initializes the widget loader with an optional parent and geometry.
        
        :param widgetCollapse: Path to the .ui file (str)
        :param parent: Parent widget (optional)
        :param geometry: Tuple (x, y, width, height) for setting widget geometry (optional)
        """
        self.CollapsibleWidget = widgetCollapse
        self.parent = parent
        self.geometry = geometry  # Optional geometry for setting position and size

    def _loadUI(self):
        """
        Loads the .ui file and returns the widget.
        
        :return: Loaded widget
        """
        if not self.CollapsibleWidget:
            raise ValueError("No widget file provided.")
        
        UiFile = self.CollapsibleWidget
        print(f"Loading UI from: {UiFile}")

        # Create QUiLoader and QFile for loading the UI
        loader = QtUiTools.QUiLoader()
        ui_loader = QtCore.QFile(UiFile)

        if not ui_loader.exists():
            raise FileNotFoundError(f"UI file {UiFile} not found.")

        # Open the UI file
        ui_loader.open(QtCore.QFile.ReadOnly)
        
        # Load the UI
        ui = loader.load(ui_loader, parent=self.parent)
        
        # Ensure the file is closed after loading
        ui_loader.close()

        if not ui:
            raise RuntimeError(f"Failed to load UI from {UiFile}.")

        print("UI loaded successfully.")

        # Apply geometry if provided
        if self.geometry:
            x, y, width, height = self.geometry
            ui.setGeometry(x, y, width, height)
            print(f"Set geometry to: {x}, {y}, {width}, {height}")

        return ui
