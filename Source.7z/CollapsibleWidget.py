import os
import sys
import maya.cmds as cmds
from PySide2.QtWidgets import QWidget, QMainWindow, QSlider, QLabel, QFrame, QHBoxLayout, QPushButton, QGroupBox, QVBoxLayout
from PySide2 import QtWidgets, QtCore, QtUiTools
import maya.OpenMayaUI as omui
import maya.OpenMaya as om
from shiboken2 import wrapInstance

# ==========================================================================================================
sliderStyleSheet = """
QSlider::groove:horizontal {
    border: 1px solid #999;
    height: 6px;
    background: #ccc;
    margin: 0px;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #5c5c5c;
    border: 1px solid #444;
    width: 14px;
    margin: -5px 0; /* Ensures the handle is properly positioned */
    border-radius: 7px;
}
QSlider::handle:horizontal:hover {
    background: #787878;
    border: 1px solid #555;
}
QSlider::sub-page:horizontal {
    background: #409eff;
    border: 1px solid #5a9;
    height: 6px;
    border-radius: 3px;
}
QSlider::add-page:horizontal {
    background: #ccc;
    border: 1px solid #999;
    height: 6px;
    border-radius: 3px;
}
"""

# ==========================================================================================================
SCRIPT_LOC = os.path.dirname(__file__)
icons = os.path.join(SCRIPT_LOC, 'resource')

# ==========================================================================================================
def get_maya_window():
    """Get Maya's main window as a PySide2 object."""
    main_window_ptr = omui.MQtUtil.mainWindow()
    if not main_window_ptr:
        raise RuntimeError("Failed to obtain Maya's main window.")
    return wrapInstance(int(main_window_ptr), QWidget)

# ==========================================================================================================
def load_ui(ui_file, parent=None):
    """Load the .ui file and return the corresponding widget."""
    loader = QtUiTools.QUiLoader()
    ui_file = QtCore.QFile(ui_file)
    if not ui_file.exists():
        raise FileNotFoundError(f"UI file {ui_file.fileName()} not found.")
    ui_file.open(QtCore.QFile.ReadOnly)
    ui_widget = loader.load(ui_file, parent)
    ui_file.close()
    if not ui_widget:
        raise RuntimeError(f"Failed to load UI file {ui_file.fileName()}.")
    return ui_widget

# ==========================================================================================================
class MyWindow(QMainWindow):
    """Main window class."""
    def __init__(self, parent=None):
        super(MyWindow, self).__init__(parent)
        self.main_ui = os.path.join(SCRIPT_LOC, "ui", "UI.ui")
        if not os.path.exists(self.main_ui):
            raise FileNotFoundError(f"UI file not found: {self.main_ui}")
        print(f"Loading UI from: {self.main_ui}")
        
        self.ui = load_ui(self.main_ui, parent=self)
        if not self.ui:
            raise RuntimeError("UI failed to load.")
        
        # Setup the window
        self.setWindowTitle("Master File Manager ver2.0")
        self.resize(500, 700)
        self.setCentralWidget(self.ui)
        self.init_ui()

        self.createConnections()
        self.add_layers()

    def init_ui(self):
        """Initialize the UI."""
        self.ui.destroyed.connect(self.on_exit_code)

        # Create a QGroupBox to hold the slider, label, and button
        self.group_box = QGroupBox("Controls", self)  # Set the title for the group box
        self.group_box.setCheckable(True)  # Make the group box collapsible
        self.group_box.setChecked(True)  # Initially, the group box is expanded

        # Create a vertical layout for the group box
        group_layout = QVBoxLayout(self.group_box)

        # Create a horizontal layout for the frame (for slider, label, and button)
        frame_layout = QHBoxLayout()

        # Create a label to show the slider value
        self.slider_value_label = QLabel(self)
        self.slider_value_label.setText("Slider Value: 0")
        frame_layout.addWidget(self.slider_value_label)  # Add label to layout

        # Create and style the slider
        self.slider = QSlider(QtCore.Qt.Horizontal, self)
        self.slider.setRange(0, 100)  # Set the range (min, max)
        self.slider.setValue(0)  # Set initial value
        self.slider.setStyleSheet(sliderStyleSheet)  # Apply the custom stylesheet
        frame_layout.addWidget(self.slider)  # Add slider to layout

        # Create a button
        self.button = QPushButton(self)
        self.button.setText("Click Me")
        frame_layout.addWidget(self.button)  # Add button to layout

        # Add the horizontal layout to the group box's vertical layout
        group_layout.addLayout(frame_layout)

        # Set the group box layout
        self.group_box.setLayout(group_layout)

        # Add the group box to the main window layout
        self.ui.layout().addWidget(self.group_box)

        # Connect slider value change to a method
        self.slider.valueChanged.connect(self.on_slider_value_changed)
        
        # Connect button click to a method
        self.button.clicked.connect(self.on_button_click)

    def createConnections(self):
        pass

    def on_slider_value_changed(self):
        """Handle slider value change."""
        slider_value = self.slider.value()
        self.slider_value_label.setText(f"Slider Value: {slider_value}")
        # Additional logic can go here, like interacting with Maya's scene

    def on_button_click(self):
        """Handle button click."""
        print("Button clicked!")
        # You can add additional functionality here for the button

    def on_exit_code(self):
        """Cleanup when the UI is closed."""
        sys.stdout.write("UI successfully closed\n")
        self.deleteLater()

    def add_layers(self):
        pass

# ==========================================================================================================
def show_window():
    """Show the window."""
    global my_window
    if 'my_window' in globals() and my_window is not None:
        try:
            my_window.close()  # Close the window if it already exists
            my_window.deleteLater()
        except:
            pass

    my_window = MyWindow(parent=get_maya_window())
    my_window.show()
