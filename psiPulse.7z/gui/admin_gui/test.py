from PySide2.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem,
    QProgressBar, QLabel
)
from PySide2.QtCore import Qt
import sys


class ActivityBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        self.layout = QVBoxLayout(self)
        self.label = QLabel("0h 0m 0s / 8h")
        self.label.setAlignment(Qt.AlignCenter)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)

        self.layout.addWidget(self.label)
        self.layout.addWidget(self.progress)

    def setValue(self, value):
        self.progress.setValue(value)

    def setColor(self, color):
        self.progress.setStyleSheet(f"""
            QProgressBar {{
                border: 1px solid gray;
                border-radius: 5px;
                text-align: center;
            }}
            QProgressBar::chunk {{
                background-color: {color};
                width: 20px;
            }}
        """)

    def setLabel(self, text):
        self.label.setText(text)


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Activity Tracker")

        self.total_day_hours = 9.0  # total workday hours

        layout = QVBoxLayout(self)

        # Create table
        self.table = QTableWidget(10, 2)
        self.table.setHorizontalHeaderLabels(["Task", "Active Time (HH:MM:SS)"])
        # Example data
        times = ["0:03:00", "2:01:00", "0:00:00", "0:18:00", "0:10:30", "0:00:00", "0:08:50", "0:13:00", "0:01:00", "0:01:00"]
        for i, t in enumerate(times):
            self.table.setItem(i, 1, QTableWidgetItem(t))

        layout.addWidget(self.table)

        # Create ActivityBar
        self.progress_bar = ActivityBar()
        layout.addWidget(self.progress_bar)

        # Update progress
        self.update_progress_from_table_()

    def update_progress_from_table_(self):
        total_seconds = 0

        for row in range(self.table.rowCount()):
            item = self.table.item(row, 1)

            if item:
                time_str = item.text().strip()
                print(f"Active Time: {time_str}")
                try:
                    h, m, s = map(int, time_str.split(":"))
                    total_seconds += h * 3600 + m * 60 + s
                except ValueError:
                    print(f"Invalid time format: {time_str}")
                    continue  # Skip invalid entries

        total_hours = total_seconds / 3600
        print(f"Total Active Time in Hours >>>>>> : {total_hours:.4f} hours")

        # Avoid division by zero
        if self.total_day_hours == 0:
            percent = 0
        else:
            percent = int((total_hours / self.total_day_hours) * 100)

        self.progress_bar.setValue(min(percent, 100))  # Cap at 100%

        # Dynamic color based on percentage
        if percent < 30:
            color = "#d9534f"  # red
        elif percent < 70:
            color = "#f0ad4e"  # orange
        else:
            color = "#5cb85c"  # green

        self.progress_bar.setColor(color)

        # Update label
        h = int(total_seconds // 3600)
        m = int((total_seconds % 3600) // 60)
        s = int(total_seconds % 60)
        self.progress_bar.setLabel(f"{h:02}h {m:02}m {s:02}s / {self.total_day_hours:.0f}h")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.resize(400, 300)
    window.show()
    sys.exit(app.exec_())
