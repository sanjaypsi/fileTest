import sys
import calendar
from datetime import datetime
from PySide2.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel,
    QComboBox, QPushButton, QDateEdit, QRadioButton, QTableWidget,
    QTableWidgetItem, QFileDialog, QMessageBox, QHBoxLayout, QFrame
)
from PySide2.QtCore import QFile, QDate, Qt
from PySide2.QtUiTools import QUiLoader
import yaml
from mongo_utils import UserFetcher, GetPulseData, GetSummaryData

class AdminDashboard(QMainWindow):
    def __init__(self):
        super(AdminDashboard, self).__init__()
        self.setWindowTitle("Admin Dashboard - Inactivity Monitor")
        self.setGeometry(100, 100, 1200, 800)

        # Main layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)

        # Sidebar
        sidebar = QFrame()
        sidebar.setFrameShape(QFrame.StyledPanel)
        sidebar.setStyleSheet("background-color: #111;")
        sidebar.setFixedWidth(260)
        sidebar_layout = QVBoxLayout(sidebar)

        # User dropdown
        self.user_combo = QComboBox()
        self.user_combo.setStyleSheet("color: black;")
        sidebar_layout.addWidget(QLabel("Select User:"))
        sidebar_layout.addWidget(self.user_combo)

        # Role display (placeholder)
        self.role_label = QLabel("All Roles")
        self.role_label.setStyleSheet("color: #00ffcc;")
        sidebar_layout.addWidget(QLabel("Artist Role:"))
        sidebar_layout.addWidget(self.role_label)

        # Date pickers
        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDate(QDate.currentDate())

        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDate(QDate.currentDate())

        sidebar_layout.addWidget(QLabel("Start Date:"))
        sidebar_layout.addWidget(self.start_date)
        sidebar_layout.addWidget(QLabel("End Date:"))
        sidebar_layout.addWidget(self.end_date)

        # Radio buttons
        self.pulse_radio = QRadioButton("Pulse")
        self.summary_radio = QRadioButton("Summaries")
        self.pulse_radio.setChecked(True)

        sidebar_layout.addWidget(self.pulse_radio)
        sidebar_layout.addWidget(self.summary_radio)

        # Search button
        self.search_button = QPushButton("Search Logs")
        self.search_button.clicked.connect(self.search_logs)
        sidebar_layout.addWidget(self.search_button)

        main_layout.addWidget(sidebar)

        # Right panel
        right_panel = QVBoxLayout()

        # Summary bar
        summary_frame = QFrame()
        summary_layout = QHBoxLayout(summary_frame)
        current_month = calendar.month_name[datetime.now().month]

        self.month_label = QLabel(f"Current-Month :-  <b style='color:#00ffcc'>{current_month}</b>")
        self.holidays_label = QLabel()
        self.working_days_label = QLabel()
        self.update_month_summary()

        summary_layout.addWidget(self.month_label)
        summary_layout.addWidget(self.holidays_label)
        summary_layout.addWidget(self.working_days_label)
        right_panel.addWidget(summary_frame)

        # Table for data
        self.table = QTableWidget()
        right_panel.addWidget(self.table)

        main_layout.addLayout(right_panel)
        self.load_users()

    def update_month_summary(self):
        now = datetime.now()
        total_days = calendar.monthrange(now.year, now.month)[1]
        holidays = self.get_month_holidays(now.month)
        working_days = total_days - holidays

        self.holidays_label.setText(f"Holidays-Month :- <b style='color:#00ffcc'>{holidays}</b>")
        self.working_days_label.setText(f"Current-Month-Working-Days :- <b style='color:#00ffcc'>{working_days}</b>")

    def get_month_holidays(self, month):
        try:
            with open("config.yml", "r") as file:
                config = yaml.safe_load(file)
                return config.get("Holidays", {}).get(str(month), 0)
        except Exception:
            return 0

    def load_users(self):
        users = UserFetcher.fetch_all_users_from_db()
        self.user_combo.addItems(users)

    def search_logs(self):
        user = self.user_combo.currentText()
        start = self.start_date.date().toPython()
        end = self.end_date.date().toPython()

        if self.pulse_radio.isChecked():
            data = GetPulseData.get_pulse_data(user, start, end)
            self.display_pulse_data(data)
        else:
            data = GetSummaryData.get_summary_data(user, start, end)
            self.display_summary_data(data)

    def display_pulse_data(self, data):
        self.table.clear()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Timestamp", "ActiveTime", "InactiveTime", "Status"])
        self.table.setRowCount(len(data))

        for row, entry in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(entry["timestamp"]))
            self.table.setItem(row, 1, QTableWidgetItem(str(entry["active"])))
            self.table.setItem(row, 2, QTableWidgetItem(str(entry["inactive"])))
            self.table.setItem(row, 3, QTableWidgetItem(entry["status"]))

    def display_summary_data(self, data):
        self.table.clear()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Date", "TotalActiveTime", "Status"])
        self.table.setRowCount(len(data))

        for row, entry in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(entry["date"]))
            self.table.setItem(row, 1, QTableWidgetItem(str(entry["total_active"])))
            self.table.setItem(row, 2, QTableWidgetItem(entry["status"]))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AdminDashboard()
    window.show()
    sys.exit(app.exec_())
