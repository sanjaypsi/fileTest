# from datetime import datetime, timedelta

# def count_weekdays(start_date, end_date):
#     """
#     Count weekdays (Mon–Fri) between two dates.
#     """
#     weekdays = 0
#     current = start_date
#     while current <= end_date:
#         if current.weekday() < 5:
#             weekdays += 1
#         current += timedelta(days=1)
#     return weekdays

# # ------------------ Usage ------------------

# start_date  = datetime(2025, 5, 24).date()
# end_date    = datetime(2025, 5, 24).date()
# holiday_count = 1  # Assume 1 holiday in this range

# weekday_count = count_weekdays(start_date, end_date)
# working_days = max(0, weekday_count - holiday_count)

# print(f"Weekdays: {weekday_count}, Holidays: {holiday_count}, Final Working Days: {working_days}")


from pymongo import MongoClient
from pprint import pprint

# === MongoDB Configuration ===
MONGO_CONFIG = {
    "host": "10.160.0.17",
    "port": 27017,
    "username": "admin",
    "password": "root1234",
    "authSource": "admin",
    "db_name": "heartBeat",
    "collection_name": "activity_pulse"
}

def fetch_all_logs():
    try:
        # Connect to MongoDB with authentication
        client = MongoClient(
            host=MONGO_CONFIG["host"],
            port=MONGO_CONFIG["port"],
            username=MONGO_CONFIG["username"],
            password=MONGO_CONFIG["password"],
            authSource=MONGO_CONFIG["authSource"]
        )

        db = client[MONGO_CONFIG["db_name"]]
        collection = db[MONGO_CONFIG["collection_name"]]

        print(f"\nFetching all logs from '{MONGO_CONFIG['collection_name']}' collection...\n")

        # Query all logs, sorted by timestamp ascending
        cursor = collection.find().sort("timestamp", 1)

        for doc in cursor:
            pprint(doc)

        print(f"\nTotal logs found: {collection.count_documents({})}")

    except Exception as e:
        print(f"❌ Error: {e}")

    finally:
        client.close()

if __name__ == "__main__":
    fetch_all_logs()
