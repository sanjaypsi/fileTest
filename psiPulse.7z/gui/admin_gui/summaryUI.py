import sys
import os
from PySide2.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QFrame
)
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import QFile, QIODevice, Qt
# =============================================================================================================
script_path = os.path.abspath(__file__)
_root       = os.path.abspath(os.path.join(script_path, "..", "..")) 

sys.path.append(_root)

def load_ui_widget(ui_path, parent=None):
    """Utility function to load a .ui file as a QWidget."""
    loader = QUiLoader()
    file = QFile(ui_path)

    if not file.exists():
        print(f"[ERROR] UI file does not exist: {ui_path}")
        return QWidget(parent)

    if not file.open(QIODevice.ReadOnly):
        print(f"[ERROR] Could not open UI file: {ui_path}")
        return QWidget(parent)

    ui_widget = loader.load(file, parent)
    file.close()

    if not ui_widget:
        print(f"[ERROR] Failed to load UI from: {ui_path}")
        return QWidget(parent)
    


    return ui_widget

