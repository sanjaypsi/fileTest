import re
from datetime import timedelta

def parse_time_string(time_str):
    """
    Parses time strings like '1 day, 5:30:00', '0:45:00', or '2 days, 0:15:00' into total minutes.
    Returns 0 if parsing fails.
    """
    try:
        # Check if the format contains days
        day_match = re.match(r"(?:(\d+)\s+day[s]?,\s*)?(\d+):(\d+):(\d+)", time_str.strip())
        if not day_match:
            print(f"Invalid time format: {time_str}")
            return 0

        days = int(day_match.group(1)) if day_match.group(1) else 0
        hours = int(day_match.group(2))
        minutes = int(day_match.group(3))
        seconds = int(day_match.group(4))

        total_time = timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)
        return int(total_time.total_seconds() // 60)

    except Exception as e:
        print(f"Error parsing time string '{time_str}': {e}")
        return 0

# Example usage:
if __name__ == "__main__":
    sample_times = [
        "1 day, 5:30:00",
        "0:45:00",
        "2 days, 0:15:00",
        "3:00:00",
        "invalid",
        "1d 7h 30m"
    ]

    for time_str in sample_times:
        minutes = parse_time_string(time_str)
        print(f"{time_str} => {minutes} minutes")
