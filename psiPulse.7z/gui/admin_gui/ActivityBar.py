from PySide2.QtWidgets import QWidget
from PySide2.QtGui import QPainter, QColor, QFont
from PySide2.QtCore import Qt

class ActivityBar(QWidget):
    def __init__(self, active_percent=0, parent=None):
        super().__init__(parent)
        self.active_percent = max(0, min(100, active_percent))
        self.setMinimumHeight(25)

    def set_active_percent(self, value):
        self.active_percent = max(0, min(100, value))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        width = self.width()
        height = self.height()

        active_width = int(width * self.active_percent / 100)

        # Draw active (green)
        painter.fillRect(0, 0, active_width, height, QColor("#00C853"))

        # Draw inactive (red)
        painter.fillRect(active_width, 0, width - active_width, height, QColor("#D32F2F"))

        # Draw percentage text
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        text = f"{self.active_percent}% Active / {100 - self.active_percent}% Inactive"
        painter.drawText(self.rect(), Qt.AlignCenter, text)
