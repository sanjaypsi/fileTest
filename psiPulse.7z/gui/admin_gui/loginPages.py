import sys
import os
from PySide2.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QDateEdit, QRadioButton, QPushButton, QTableWidget, QTableWidgetItem,
    QComboBox, QFrame, QAction, QMessageBox, QHeaderView, QLineEdit, QProgressBar
)
from PySide2.QtCore import Qt, QDate
from PySide2.QtGui import QPixmap, QIcon, QColor
from PySide2.QtWidgets import QLabel, QWidget  # noqa: F811
import re
import datetime
import math
from datetime import datetime, timedelta  # noqa: F811
import logging
import yaml

# =============================================================================================================
script_path     = os.path.abspath(__file__)
_root           = os.path.abspath(os.path.join(script_path, "..", "..")) 

sys.path.append(_root)
icon_path       = os.path.join(os.path.dirname(_root), "resources/icons/user_icon.png").replace("\\", "/")
_holidays_path  = os.path.join(os.path.dirname(_root), "config/holidaysList.yml").replace("\\", "/")
_config_path    = os.path.join(os.path.dirname(_root), "config/userRoles.yml").replace("\\", "/")

# Importing necessary modules from the admin_gui package
from admin_gui.mongo_utils import UserFetcher  # noqa: E402
from admin_gui.mongo_utils import GetPulseData  # Update import path to actual location  # noqa: E402
from admin_gui.summaryUI import load_ui_widget  # Update import path to actual location  # noqa: E402
from admin_gui.mongo_utils import SummaryPanel  # Update import path to actual location  # noqa: E402
from admin_gui.mongo_utils import ActivityBar  # Update import path to actual location  # noqa: E402, F401
from admin_gui.mongo_utils import get_today_active_time  # Update import path to actual location # noqa: E402


# # =============================================================================================================
# # Load the YAML holiday configuration file
# # =============================================================================================================
def load_holidayConfig():
    """
    Load the holiday configuration and return a list of holidays for the current month.

    Returns:
        list: List of holidays for the current month.
    """
    try:
        if os.path.exists(_holidays_path):
            with open(_holidays_path, 'r') as f:
                cfg = yaml.safe_load(f) or {}
                current_month = datetime.now().strftime("%B")

                # Safely get holidays for the current month
                holidays = cfg.get(current_month, [])
                return holidays  # Return list of holidays this month

    except Exception as e:
        logging.error(f"[CONFIG] Failed to load holiday config: {e}")

    return []

# =============================================================================================================
# # Load the YAML configuration file
# =============================================================================================================
def load_config():
    # Load the YAML configuration and return a dictionary of User Role {psi_team}.
    try:
        if os.path.exists(_config_path):
            with open(_config_path, 'r') as f:
                cfg = yaml.safe_load(f) or {}
                user_roles = cfg.get("User_Roles", {})
                return user_roles
        else:
            logging.warning(f"[CONFIG] Config file not found at {_config_path}")

    except Exception as e:
        logging.error(f"[CONFIG] Failed to load config: {e}")

    return {}

# =============================================================================================================
# Function to parse time strings and convert them to total minutes
# ============================================================================================================
def parse_time_string(time_str):
    """
    Parses time strings like '1 day, 5:30:00', '0:45:00', or '2 days, 0:15:00' into total minutes.
    Returns 0 if parsing fails.
    """
    try:
        # Check if the format contains days
        day_match = re.match(r"(?:(\d+)\s+day[s]?,\s*)?(\d+):(\d+):(\d+)", time_str.strip())
        if not day_match:
            print(f"Invalid time format: {time_str}")
            return 0

        days        = int(day_match.group(1)) if day_match.group(1) else 0
        hours       = int(day_match.group(2))
        minutes     = int(day_match.group(3))
        seconds     = int(day_match.group(4))

        total_time  = timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)
        return math.ceil(total_time.total_seconds() / 60)

    except Exception as e:
        print(f"Error parsing time string '{time_str}': {e}")
        return 0

# =============================================================================================================
# Function to parse time strings and convert them to HH:MM:SS format
# ============================================================================================================
def parse_time_to_string(time_str):
    """Converts '1 day, 2:00:00' into '26:00:00' (HH:MM:SS format)"""
    try:
        match = re.match(r"(?:(\d+)\s+day[s]?,\s*)?(\d+):(\d+):(\d+)", time_str.strip())
        if not match:
            print(f"Invalid time format: {time_str}")
            return "0:00:00"

        days    = int(match.group(1)) if match.group(1) else 0
        hours   = int(match.group(2))
        minutes = int(match.group(3))
        seconds = int(match.group(4))

        total_hours = days * 24 + hours
        return f"{total_hours}:{minutes:02}:{seconds:02}"

    except Exception as e:
        print(f"Error: {e}")
        return "0:00:00"

# =============================================================================================================
# Function to parse time strings and convert them to total seconds
# =============================================================================================================
def parse_time_to_seconds(time_str):
    """Converts '0:02:40' to total seconds (int)"""
    try:
        parts = list(map(int, time_str.strip().split(":")))
        if len(parts) != 3:
            print(f"Invalid time format: {time_str}")
            return 0
        hours, minutes, seconds = parts
        return hours * 3600 + minutes * 60 + seconds
    except Exception as e:
        print(f"Error parsing time to seconds: {e}")
        return 0

# =============================================================================================================
# Function to format total seconds into HH:MM:SS format
# =============================================================================================================
def format_seconds_to_hms(total_seconds):
    hours   = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f"{hours}:{minutes:02}:{seconds:02}"

# =============================================================================================================
# Function to get the number of working days between two dates, excluding weekends and holidays
# =============================================================================================================
def count_weekdays(start_date, end_date):
    """
    Count weekdays (Mon–Fri) between two dates.
    """
    weekdays = 0
    current = start_date
    while current <= end_date:
        if current.weekday() < 5:
            weekdays += 1
        current += timedelta(days=1)
    return weekdays

# =============================================================================================================
# Login Window
# =============================================================================================================
class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Login Page")
        self.setFixedSize(400, 300)
        self.setWindowIcon(QIcon(icon_path))
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignCenter)

        title_label = QLabel("Welcome Back!")
        title_label.setStyleSheet("font-size: 20px; font-weight: bold;")
        title_label.setAlignment(Qt.AlignCenter)

        username_label = QLabel("Username:")
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Enter your username")
        self.username_input.setFixedHeight(35)

        password_label = QLabel("Password:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setPlaceholderText("Enter your password")
        self.password_input.setFixedHeight(35)

        login_button = QPushButton("Login")
        login_button.setFixedHeight(35)
        login_button.clicked.connect(self.handle_login)

        layout.addWidget(title_label)
        layout.addSpacing(15)
        layout.addWidget(username_label)
        layout.addWidget(self.username_input)
        layout.addWidget(password_label)
        layout.addWidget(self.password_input)
        layout.addSpacing(10)
        layout.addWidget(login_button)

        self.setLayout(layout)

        self.setStyleSheet("""
            QWidget {
                background-color: #f5f5f5;
                font-family: Arial;
                font-size: 14px;
            }
            QLineEdit {
                border: 1px solid #ccc;
                border-radius: 5px;
                padding-left: 10px;
                background-color: white;
            }
            QPushButton {
                background-color: #5cb85c;
                color: white;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #4cae4c;
            }
        """)

    def handle_login(self):
        username = self.username_input.text()
        password = self.password_input.text()

        if username == "admin" and password == "password123":
            self.open_dashboard()
        else:
            QMessageBox.warning(self, "Failed", "Incorrect username or password.")

    def open_dashboard(self):
        self.admin_dashboard = AdminDashboard()
        self.admin_dashboard.show()
        self.close()

# =============================================================================================================
# Admin Dashboard
# =============================================================================================================
class AdminDashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Admin Dashboard - Inactivity Monitor")
        self.setWindowIcon(QIcon(icon_path))

        self.total_day_hours = 9
        
        self.resize(1350, 650)
        self.setup_ui()
        self.setup_menu()
        self.mock_fetch_logs()
        self.update_month_active_inactive_time()
        self.connection()

    # ---------------------------------------------------------------------------------------------------------------
    # get number_of_holidays in the month
    # ---------------------------------------------------------------------------------------------------------------
    def get_number_of_holidays(self) -> int:
        """
        Returns the number of sessions in the pulse summary data.
        """
        self.holidays_in_month  = load_holidayConfig()
        return len(self.holidays_in_month) 

    # ---------------------------------------------------------------------------------------------------------------
    # setup the UI
    # ---------------------------------------------------------------------------------------------------------------
    def setup_ui(self):
        main_widget = QWidget()
        main_layout = QHBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)

        sidebar = QWidget()
        sidebar.setFixedWidth(250)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setAlignment(Qt.AlignTop)
        sidebar.setStyleSheet("""
            QWidget {
                background-color: #1c1c1c;
                color: white;
                font-family: Arial;
            }
        """)

        profile_layout  = QHBoxLayout()
        profile_pic     = QLabel()
        pixmap          = QPixmap(icon_path).scaled(40, 40, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        profile_pic.setPixmap(pixmap)
        profile_details = QLabel("Admin\n🟢 online")
        profile_details.setStyleSheet("color: white; font-size: 13px; margin-left: 5px;")
        profile_layout.addWidget(profile_pic)
        profile_layout.addWidget(profile_details)
        sidebar_layout.addLayout(profile_layout)

        sidebar_layout.addSpacing(20)
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        line.setStyleSheet("QFrame { background-color: #00FF7F; }")
        sidebar_layout.addWidget(line)

        users = UserFetcher.fetch_all_users_from_db()
        sidebar_layout.addSpacing(25)
        sidebar_layout.addWidget(QLabel("Select User:"))
        self.user_filter = QComboBox()
        self.user_filter.addItems(users)
        self.user_filter.setFixedHeight(35)
        self.user_filter.setStyleSheet("""
            QComboBox {
                color: #00FF7F;
                font-size: 12px;
                font-weight: bold;
                padding: 6px;
                border-radius: 6px;
                background-color: #2c2c2c;
            }
        """)
        self.user_filter.currentIndexChanged.connect(self.update_artiste_role)
        sidebar_layout.addWidget(self.user_filter)

        sidebar_layout.addSpacing(10)
        sidebar_layout.addWidget(QLabel("Artist Role:"))
        self.artiste_role_label = QLabel("All Roles")
        self.artiste_role_label.setFixedHeight(35)
        self.artiste_role_label.setStyleSheet("""
            QLabel {
                color: #00FF7F;
                font-size: 12px;
                font-weight: bold;
                padding: 8px;
                border-radius: 6px;
                background-color: #2c2c2c;
            }
        """)
        sidebar_layout.addWidget(self.artiste_role_label)

        sidebar_layout.addSpacing(30)
        sidebar_layout.addWidget(QLabel("Start Date:"))
        self.start_date = QDateEdit(calendarPopup=True)
        self.start_date.setDate(QDate.currentDate())
        self.start_date.setFixedHeight(30)
        sidebar_layout.addWidget(self.start_date)

        sidebar_layout.addWidget(QLabel("End Date:"))
        self.end_date = QDateEdit(calendarPopup=True)
        self.end_date.setDate(QDate.currentDate())
        self.end_date.setFixedHeight(30)
        sidebar_layout.addWidget(self.end_date)

        frame = QFrame()
        frame_layout = QVBoxLayout(frame)
        frame.setFrameShape(QFrame.Panel)
        frame.setFrameShadow(QFrame.Raised)
        frame.setStyleSheet("""
            QFrame {
                border: 2px solid #00FF7F;
                border-radius: 8px;
                background-color: #2c2c2c;
            }
        """)
        self.pulse_radio = QRadioButton("Pulse")
        self.pulse_radio.setChecked(True)
        self.pulse_radio.setStyleSheet("QRadioButton { color: white; font-size: 12px; }")
        self.summary_radio = QRadioButton("Summaries")
        self.summary_radio.setStyleSheet("QRadioButton { color: white; font-size: 12px; }")

        search_button = QPushButton("Search Logs")
        search_button.setFixedHeight(35)
        search_button.setStyleSheet("""
            QPushButton {
                background-color: #00FF7F;
                color: black;
                font-weight: bold;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #00cc66;
            }
        """)
        search_button.clicked.connect(self.mock_fetch_logs)

        frame_layout.addWidget(self.pulse_radio)
        frame_layout.addWidget(self.summary_radio)
        frame_layout.addSpacing(10)
        frame_layout.addWidget(search_button)

        sidebar_layout.addSpacing(30)
        sidebar_layout.addWidget(frame)

        holidays = self.get_number_of_holidays()
        total_work_days = 22 - holidays

        sidebar_layout.addWidget(QLabel("Number of Holidays:"))
        self.Number_of_Holiday = QLabel(str(holidays))
        self.Number_of_Holiday.setFixedHeight(35)
        self.Number_of_Holiday.setStyleSheet("""
            QLabel {
                color: #00FF7F;
                font-size: 12px;
                font-weight: bold;
                padding: 8px;
                border-radius: 6px;
                background-color: #2c2c2c;
            }
        """)
        sidebar_layout.addWidget(self.Number_of_Holiday)

        sidebar_layout.addSpacing(10)
        sidebar_layout.addWidget(QLabel("Total Working Days:"))
        self.Total_Working_Days = QLabel(str(total_work_days))
        self.Total_Working_Days.setFixedHeight(35)
        self.Total_Working_Days.setStyleSheet("""
            QLabel {
                color: #00FF7F;
                font-size: 12px;
                font-weight: bold;
                padding: 8px;
                border-radius: 6px;
                background-color: #2c2c2c;
            }
        """)
        sidebar_layout.addWidget(self.Total_Working_Days)
        sidebar_layout.addStretch()

        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setContentsMargins(5, 5, 5, 5)

        current_month = datetime.now().strftime("%B")
        current_year  = datetime.now().strftime("%Y")
        current_date  = datetime.now().strftime("%d")
        current_date  = f"{current_year}-{current_month}-{current_date}"

        top_bar         = QHBoxLayout()
        title           = QLabel(f"Current - Month :- {current_month}")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: black;")
        title.setAlignment(Qt.AlignLeft)
        top_bar.addWidget(title)
        top_bar.addStretch()
        content_layout.addLayout(top_bar)
        content_layout.addSpacing(2)

        summary_frame = QFrame()
        summary_frame.setStyleSheet("""
            QFrame {
                background-color: #1c1c1c;
                border-radius: 2px;
            }
            QLabel {
                color: white;
                font-size: 12px;
                font-weight: bold;
                padding: 8px;
                border-radius: 6px;
                background-color: #2c2c2c;
            }
        """)
        summary_frame.setFixedHeight(120)
        summary_layout = QVBoxLayout(summary_frame)
        summary_layout.setSpacing(0)
        summary_layout.setContentsMargins(2, 10, 2, 2)

        _ui_path = os.path.join(os.path.dirname(script_path), "ui/summary.ui")
        self.ui_widget = load_ui_widget(_ui_path, self)
        summary_layout.addWidget(self.ui_widget)
        content_layout.addWidget(summary_frame)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Timestamp", "ActiveTime", "InactiveTime", "Status"])
        self.table.setRowCount(0)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        header = self.table.horizontalHeader()
        for col in range(4):
            header.setSectionResizeMode(col, QHeaderView.Stretch)
        content_layout.addWidget(self.table)

        # --------------------------------------------------------------------------------------------------------
        # Today Active Summary (inline, tightly spaced)
        # --------------------------------------------------------------------------------------------------------
        activity_summary_container = QWidget()
        activity_summary_container.setStyleSheet("""
            QWidget {
                background-color: #1c1c1c;
                border-radius: 2px;
            }
            QLabel {
                color: white;
                font-size: 13px;
                font-weight: bold;
                background-color: transparent;
            }
        """)

        activity_summary_layout = QVBoxLayout()
        activity_summary_layout.setContentsMargins(2, 5, 2, 5)
        activity_summary_layout.setSpacing(6)
        activity_summary_container.setLayout(activity_summary_layout)

        # Inline "Today Active: 0" label
        inline_label_layout = QHBoxLayout()
        inline_label_layout.setContentsMargins(0, 0, 0, 0)
        inline_label_layout.setSpacing(5)  # <--- Keep it tight!

        # label_title = QLabel("Today Active:")
        # self.label_today_active = QLabel("0")
        # self.label_today_active.setObjectName("label_10")
        # self.label_today_active.setStyleSheet("color: #00FF7F; font-size: 13px;")

        # inline_label_layout.addWidget(label_title)
        # inline_label_layout.addWidget(self.label_today_active)
        # inline_label_layout.addStretch()

        # NEW: Label above the progress bar
        self.progress_bar_label = QLabel("00h 00m 00s / 8h")
        self.progress_bar_label.setAlignment(Qt.AlignCenter)
        self.progress_bar_label.setStyleSheet("color: white; font-size: 13px;")

        # Progress Bar Section
        progress_section = QWidget()
        progress_section.setStyleSheet("""
            QWidget {
                background-color: #1c1c1c;
                border-radius: 2px;
            }
            QLabel {
                color: white;
                font-size: 13px;
                font-weight: bold;
                background-color: transparent;
            }
        """)

        progress_layout = QVBoxLayout(progress_section)
        progress_layout.setContentsMargins(2, 5, 2, 5)

        # label_title = QLabel("Today Active:")
        # self.label_today_active = QLabel("0")
        # self.label_today_active.setStyleSheet("""
        #                                       color: #00FF7F;
        #                                       font-size: 13px;
        #                                       font-weight: bold;
        #                                       background-color: transparent;
        #                                       """)
        
        # self.label_today_active.setObjectName("label_10")
        # self.label_today_active.setAlignment(Qt.AlignCenter)
        # self.label_today_active.setFixedHeight(35)

        label_row = QHBoxLayout()
        # label_row.addWidget(label_title)
        # label_row.addWidget(self.label_today_active)
        label_row.addStretch()

        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(100)
        self.bottom_label = QLabel("00h 00m 00s / 8h")
        self.bottom_label.setStyleSheet("""
            color:#00FF7F;
            font-size: 13px;
            font-weight: bold;
            background-color: transparent;
        """)

        self.bottom_label.setAlignment(Qt.AlignLeft)
        progress_layout.addLayout(label_row)
        progress_layout.addWidget(self.progress_bar)
        progress_layout.addWidget(self.bottom_label)

        content_layout.addWidget(progress_section)

        main_layout.addWidget(sidebar)
        main_layout.addWidget(content_widget)
        self.setCentralWidget(main_widget)

    # ---------------------------------------------------------------------------------------------------------------
    # connection to the signals
    # ---------------------------------------------------------------------------------------------------------------
    def connection(self):
        """
        docstring
        """
        # Get selected user from the filter
        self.user_filter.currentTextChanged.connect(self.update_month_active_inactive_time)

    # ---------------------------------------------------------------------------------------------------------------
    # setup the menu bar
    # ---------------------------------------------------------------------------------------------------------------
    def setup_menu(self):
        menubar = self.menuBar()
        menubar.setStyleSheet("""
            QMenuBar {
                background-color: #1c1c1c;
                color: white;
                font-family: Arial;
            }
            QMenuBar::item {
                background-color: #1c1c1c;
                padding: 2px;
            }
            QMenuBar::item:selected {
                background-color: #2c2c2c;
            }
            QMenu {
                background-color: #1c1c1c;
                color: white;
            }
            QMenu::item:selected {
                background-color: #2c2c2c;
            }
        """)
        file_menu = menubar.addMenu("File")
        file_menu.addAction(QAction("Exit", self, triggered=self.close))

        view_menu = menubar.addMenu("View")
        view_menu.addAction(QAction("Refresh", self, triggered=self.mock_fetch_logs))

        help_menu = menubar.addMenu("Help")
        help_menu.addAction(QAction("About", self, triggered=self.show_about))

    # ---------------------------------------------------------------------------------------------------------------
    # update the user role
    # ---------------------------------------------------------------------------------------------------------------
    def update_artiste_role(self):
        # Get selected user role from the config file
        self.user_roles = load_config()
        selected_user   = self.user_filter.currentText()

        self.artiste_role_label.setText(
            "All Roles" if selected_user == "All Users" else self.user_roles.get(selected_user, "Unknown Role")
        )

    # ---------------------------------------------------------------------------------------------------------------
    # mock fetch logs
    # ---------------------------------------------------------------------------------------------------------------
    def mock_fetch_logs(self):
        """
        Fetches logs based on selected username and date range, and populates the table with the log data.
        """

        # Get selected user from the filter
        selected_user = self.user_filter.currentText()

        # Get start and end dates from the date pickers
        start_date  = self.start_date.date().toString("yyyy-MM-dd")
        end_date    = self.end_date.date().toString("yyyy-MM-dd")

        # Convert the date strings to datetime objects
        start_datetime  = datetime.strptime(start_date, "%Y-%m-%d")
        end_datetime    = datetime.strptime(end_date, "%Y-%m-%d")

        print(f"start_datetime: {start_datetime}")
        print(f"start_datetime: {end_datetime}")

        # Fetch the logs based on the selected filters
        ac = GetPulseData()

        # Check if we are fetching summary or pulse data based on the radio button selection
        if self.pulse_radio.isChecked():
            logs = ac.get_pulse_data(start_datetime, end_datetime, selected_user)
            
        else:
            logs = ac.get_summary_logs(start_datetime, end_datetime, selected_user)

        # Debugging line to check the fetched logs
        # Process the logs and structure them for display
        table_data = [
            (
                log.get("timestamp"),
                log.get("active_time", ""),
                log.get("inactive_time", ""),
                log.get("status", "")
            )
            for log in logs
        ]


        self.populate_table(table_data)
        self.update_progress_from_table_()

        # # ==== Your logic ====
        # activeTIme = []

        # # get active time from the logs
        # for log in logs:
        #     active_time = log.get("active_time", "")
        #     if active_time:
        #         formatted = parse_time_to_string(active_time)
        #         activeTIme.append(formatted)
        #         # print(f"Active Time: {formatted}")

        # # Step 1: Convert each to seconds
        # total_seconds = sum(parse_time_to_seconds(t) for t in activeTIme)

        # # Step 2: Format to HH:MM:SS
        # formatted_total = format_seconds_to_hms(total_seconds)

        # # Add the total active time to the QLabel label_10
        # label = self.findChild(QLabel, "label_10")
        # if label:
        #     label.setText(formatted_total)
        #     label.setStyleSheet("font-size: 16px; font-weight: bold; color: #00FF7F;")
        # else:
        #     print("label_10 (Total Active Time) not found")

        # print(f"Total Active formatted_total Time: {formatted_total} (HH:MM:SS)")
        
    # ---------------------------------------------------------------------------------------------------------------
    # populate the table with data
    # ---------------------------------------------------------------------------------------------------------------
    def populate_table(self, data):
        """
        Populates the table widget with the provided data.
        Args:
            data (list of list): A list of rows, where each row is a list of values 
                                representing the data to be displayed in the table.
        Behavior:
            - Sets the number of rows in the table to match the length of the data.
            - Iterates through the data to populate each cell in the table.
            - Aligns the text in each cell to the center.
            - Optionally sets the background and foreground colors 
            of the cells based on the "status" value in the data.
            - Calls `add_summary_panel` after populating the table.
        """
        self.table.setRowCount(len(data))
        active_color    = QColor("#24ff92")    # Green for active
        inactive_color  = QColor("#cd6155")  # Red for inactive

        for row_idx, row_data in enumerate(data):
            status = str(row_data[3]).lower()  # Assuming status is the 4th column (index 3)

            for col_idx, value in enumerate(row_data):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignCenter)

                # Color the cell based on status (active or inactive)
                # if status == "active":
                #     item.setBackground(active_color)
                #     item.setForeground(Qt.black)
                
                # elif status == "inactive":
                #     item.setBackground(inactive_color)
                #     item.setForeground(Qt.white)

                self.table.setItem(row_idx, col_idx, item)
    
    # ---------------------------------------------------------------------------------------------------------------
    # update the month active and inactive time
    # ---------------------------------------------------------------------------------------------------------------
    def update_month_active_inactive_time(self):
        selected_user = self.user_filter.currentText()
        print(f"Selected User: {selected_user}")

        sp = SummaryPanel()
        # act_time = sp.get_total_active_time(selected_user)
        act_time    = sp.get_total_working_days_readable(selected_user)
        inact_time  = sp.get_total_inactive_time(selected_user)
        # inact_time = sp.convert_inactive_time_to_working_days(selected_user)

        # Update Monthly Active Label
        label = self.ui_widget.findChild(QLabel, "label_2")
        if label:
            act_time_display = act_time.split(".")[0]
            label.setStyleSheet("font-size: 20px; font-weight: bold; color: #00FF7F;")
            label.setText(act_time_display)
        else:
            print("label_2 (Monthly Active) not found")

        # Update Monthly Inactive Label
        label = self.ui_widget.findChild(QLabel, "label_4")
        if label:
            inact_time_display = inact_time.split(".")[0]
            label.setStyleSheet("font-size: 20px; font-weight: bold; color: #00FF7F;")
            label.setText(inact_time_display)
        else:
            print("label_4 (Monthly Inactive) not found")

        # Today’s Active/Inactive
        # today_active_time   = sp.get_today_active_time(selected_user)
        today_active_time   = get_today_active_time(selected_user)

        # Redundant fallback call
        ac = GetPulseData()
        today_inactive_time = ac.get_today_inactive_time(selected_user)

        # Update Today's Active Label
        label = self.ui_widget.findChild(QLabel, "label_6")
        if label:
            today_active_time_display = today_active_time.split(".")[0]
            label.setStyleSheet("font-size: 20px; font-weight: bold; color: #00FF7F;")
            label.setText(today_active_time_display)
        else:
            print("label_6 (Today Active) not found")

        # Update Today's Inactive Label
        label = self.ui_widget.findChild(QLabel, "label_8")
        if label:
            today_inactive_time_display = str(today_inactive_time).split(".")[0]
            label.setStyleSheet("font-size: 20px; font-weight: bold; color: #00FF7F;")
            label.setText(today_inactive_time_display)
        else:
            print("label_8 (Today Inactive) not found")

        self.mock_fetch_logs()
        self.update_progress_from_table_()  # Reset progress bar to 0 before updating

        # -----------------------------------------------------------------------

    # -----------------------------------------------------------------------------------------------------------------
    # get total working days in the month
    # -----------------------------------------------------------------------------------------------------------------
    def get_total_working_days(self):
        """
        Returns the total number of working days in the month.
        """
        holidays        = self.get_number_of_holidays()
        total_work_days = 22 - holidays

        # Get the current date
        today = datetime.now()
        # Get the first day of the month
        first_day_of_month  = today.replace(day=1)

        # calculate 3600  seconds in total today current date 1 to current date
        total_seconds       = (today - first_day_of_month).total_seconds()

        # convert seconds to minutes
        total_minutes       = total_seconds / 60
        
        # convert minutes to hours
        # multiply by 9 hours into total_work_days
        total_work_hours    = total_work_days * 9

        # get total days in currents month its 30 or 31
        total_days_in_month = (today.replace(day=1) + timedelta(days=31)).replace(day=1) - timedelta(days=1)
        total_days_in_month = total_days_in_month.day

        # Get the total working days in the month
        total_month_work_hours    = total_days_in_month * 9

        # get total Active time 
        total_active_time   = self.ui_widget.findChild(QLabel, "label_2").text()
        total_active_time   = parse_time_string(total_active_time)

        # convert total_active_time minutes to hours
        total_active_time   = total_active_time / 60

        # print(f"Total Days in Month: {total_days_in_month} days")
        # print(f"Total Month Working Days: {total_month_work_hours} hours")

        # print(f"Total Seconds: {total_seconds} seconds")
        # print(f"Total Minutes: {total_minutes} minutes")

        # print(f"Total Active Time: {str(total_active_time)} hours")
        # print(f"Total Work Hours: {total_work_hours} hours")
        
        return (total_active_time, total_work_hours, total_month_work_hours, total_days_in_month)

    # -----------------------------------------------------------------------------------------------------------------
    # update progress bar
    # -----------------------------------------------------------------------------------------------------------------
    def update_progress_from_table_(self):
        total_seconds   = 0
        # Get the Start and End dates from the date pickers
        start_date      = self.start_date.date().toString("yyyy-MM-dd")
        end_date        = self.end_date.date().toString("yyyy-MM-dd")

        # caculate the total working days in the date pickers
        start_datetime  = datetime.strptime(start_date, "%Y-%m-%d")
        end_datetime    = datetime.strptime(end_date, "%Y-%m-%d")
        total_work_days = (end_datetime - start_datetime).days + 1

        # # ------------------ Usage -----------------------------------------------------------------------------------
        start_date      = start_datetime.date()
        end_date        = end_datetime.date()
        holiday_count   = self.get_number_of_holidays()
        weekday_count   = count_weekdays(start_date, end_date)
        working_days    = max(0, weekday_count - holiday_count)

        if working_days == 0:
            total_work_days = 1
        else:
            total_work_days = working_days

        self.total_day_hours = total_work_days* 9

        for row in range(self.table.rowCount()):
            item = self.table.item(row, 1)
            if item:
                time_str = item.text().strip()
                try:
                    h, m, s = map(int, time_str.split(":"))
                    total_seconds += h * 3600 + m * 60 + s
                except ValueError:
                    continue

        total_hours = total_seconds / 3600
        percent     = int((total_hours / self.total_day_hours) * 100)
        self.progress_bar.setValue(min(percent, 100))

        # Update bar color based on percentage
        if percent < 30:
            color = "#d9534f"  # red
        
        elif percent < 70:
            color = "#f0ad4e"  # orange
        
        else:
            color = "#5cb85c"  # green

        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                border: 1px solid gray;
                border-radius: 5px;
                text-align: center;
            }}
            QProgressBar::chunk {{
                background-color: {color};
                width: 20px;
            }}
        """)

        # Update bottom label
        h = int(total_seconds // 3600)
        m = int((total_seconds % 3600) // 60)
        s = int(total_seconds % 60)
        # self.label_today_active.setText(f"{h:02}h {m:02}m {s:02}s")
        self.bottom_label.setText(f"ACTIVE TIME :   {h:02}h {m:02}m {s:02}s / {self.total_day_hours}  Total Hours")
        
    # -----------------------------------------------------------------------------------------------------------------
    # show about dialog
    # -----------------------------------------------------------------------------------------------------------------
    def show_about(self):
        QMessageBox.information(self, "About", "Inactivity Monitor Admin Panel\nVersion 1.0\nDeveloped by Sanjay.")

# =============================================================================================================
# Main function to run the application
# =============================================================================================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    login = LoginWindow()
    login.show()
    sys.exit(app.exec_())
