
# -*- coding: utf-8 -*-
# Heart Beat Application - User GUI
# author: Sanja
# date: 2025-03-01
# description: This module provides the main GUI for the Heart Beat application.
# It includes functionalities for displaying user data, selecting dates,
# and applying themes. The GUI is built using PySide2 and Qt Designer.
# ========================================================================================================
# Imports # Standard Libraries
# ========================================================================================================
import os
import sys
import csv
import logging
from datetime import datetime
import socket

from PySide2.QtWidgets import (
    QApplication, QMainWindow, QLabel, QVBoxLayout, QSizePolicy,
    QWidget, QDateEdit, QPushButton, QHeaderView, QTableWidget, QTableWidgetItem,
    QComboBox, QMessageBox, QLineEdit, QRadioButton, QFileDialog, QStackedWidget,
)
from PySide2.QtCore import Qt, QFile, QIODevice, QDate, QSize
from PySide2.QtGui import QIcon, QPixmap, QFont, QPalette, QColor
from PySide2.QtUiTools import QUiLoader

# ========================================================================================================
# Custom Imports
# ========================================================================================================
superUser ={
    # Superuser credentials for logging in
    "username": "admin",
    "password": "admin123",
}


# === Paths =======================================================================================================
script_path = os.path.abspath(__file__)
ui_path     = os.path.join(os.path.dirname(script_path), "ui/fixed_layout.ui")
_root       = os.path.abspath(os.path.join(script_path, "..", "..")) 
icon_path   = os.path.join(os.path.dirname(_root), "resources/icons/user_icon.png").replace("\\", "/")

# === Logging ===
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# === Stylesheet (default fallback) =====================================================
default_stylesheet = """

    QMainWindow { background-color: #2b2b2b; }
    QWidget { background-color: #2b2b2b; color: #f0f0f0; font-family: 'Segoe UI'; font-size: 14px; }
    #sidePanel { background-color: #1c1c1c; border-right: 1px solid #444; padding: 12px; }
    QLabel { color: #e6e6e6; font-weight: 600; padding-bottom: 6px; }
    QPushButton { background-color: #3a86ff; color: white; border-radius: 6px; padding: 6px 12px; font-weight: 600; }
    QPushButton:hover { background-color: #265dd8; }
    QDateEdit, QLineEdit, QTextEdit { background-color: #3b3b3b; color: white; border: 1px solid #666; border-radius: 4px; padding: 4px 6px; }
    QTableWidget { background-color: #292929; color: #f0f0f0; border: 1px solid #444; gridline-color: #555; alternate-background-color: #333; selection-background-color: #444; selection-color: white; }
    QTableWidget::item { padding: 8px; font-weight: 500; }
    QComboBox { background-color: #3b3b3b; color: white; border: 1px solid #666; border-radius: 4px; padding: 4px 6px; }

"""

# ========================================================================================================
# Main GUI Class
# ========================================================================================================
class UserGUI(QMainWindow):
    
    # ----------------------------------------------------------------------------------------------------
    # Constructor
    # ----------------------------------------------------------------------------------------------------
    def __init__(self):
        """
        Initializes the main GUI window for the Heart Beat application.

        This constructor sets up the user interface, configures the main window,
        and initializes various components such as the summary panel, menu bar,
        date selectors, username display, and table. It also applies a default
        theme, connects signals and slots, and ensures the window stays on top.

        Attributes:
            ui (None): Placeholder for the user interface object.
            _summary_panel (dict): Dictionary to store summary panel components.
            _summary_month_info (SummaryPanel): Instance of the SummaryPanel class.
        """
        super().__init__()
        self.ui = None
        self.load_ui()
        self.setWindowTitle("Heart Beat")
        self.layout()
        self.add_menu_bar()
        # self.add_icon_to_layout()

        # self.add_username()
        # self.change_theme("Dark")

        # self.connection()
        self.setStyleSheet(default_stylesheet)
        # self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

    # ----------------------------------------------------------------------------------------------------
    # Load the UI file and set up the main window
    # ----------------------------------------------------------------------------------------------------
    def load_ui(self):
        """
        Loads the UI layout from a .ui file and sets it as the central widget of the main window.
        This method uses QUiLoader to dynamically load the UI file specified by `ui_path`.
        If the file cannot be opened or the UI fails to load, an error message is displayed,
        and the application exits. Upon successful loading, the method configures the main
        window's size, minimum size, and optionally sets a window icon if `icon_path` exists.
        It also adjusts the sizes and stretch factors of specific QSplitter widgets in the UI.
        Raises:
            SystemExit: If the UI file cannot be opened or the UI fails to load.
        Side Effects:
            - Displays a QMessageBox with an error message if loading fails.
            - Sets the central widget, size, and icon of the main window.
            - Configures splitter sizes and stretch factors in the UI.
        Attributes:
            self.ui: The loaded UI object, which is set as the central widget.
        """
        loader = QUiLoader()
        ui_file = QFile(ui_path)
        if not ui_file.open(QIODevice.ReadOnly):
            QMessageBox.critical(self, "Error", f"Cannot open UI file:\n{ui_path}")
            sys.exit(1)
        self.ui = loader.load(ui_file, self)
        ui_file.close()
        if self.ui:
            self.setCentralWidget(self.ui)
            self.resize(1100, 600)
            self.setMinimumSize(QSize(350, 600))
            if os.path.exists(icon_path):
                self.setWindowIcon(QIcon(icon_path))
                            
        else:
            QMessageBox.critical(self, "Error", "Failed to load the UI layout.")
            sys.exit(1)


    def layout(self):

        self.ui.splitter.setSizes([100, 500])






    def log_as_superuser(self):
        """
        Logs in as a superuser by checking the username and password against predefined values.
        If the credentials match, it allows access to superuser functionalities; otherwise, it denies access.
        """
        username = self.ui.findChild(QLineEdit, "usernameLineEdit").text()
        password = self.ui.findChild(QLineEdit, "passwordLineEdit").text()

        if username == superUser["username"] and password == superUser["password"]:
            QMessageBox.information(self, "Login", "Login successful!")
            
            # QstackedWidget got to the superuser page
            self.ui.stackedWidget.setCurrentIndex(1)  # Assuming index 1 is the superuser page
            # Proceed with superuser functionalities
        else:
            QMessageBox.critical(self, "Login", "Invalid username or password.")

    # ----------------------------------------------------------------------------------------------------
    # Add add_menu_bar to the layout
    # ----------------------------------------------------------------------------------------------------
    def add_menu_bar(self):
        """
        Creates and configures the menu bar for the GUI application.
        This method sets up the following menus and their respective actions:
        - File Menu:
            - "Export to CSV" (Shortcut: Ctrl+E): Triggers the `export_to_csv` method.
            - "Print" (Shortcut: Ctrl+P): Triggers the `print_table` method.
            - "Exit" (Shortcut: Ctrl+Q): Closes the application.
        - View Menu:
            - "Refresh Logs" (Shortcut: Ctrl+R): Triggers the `on_search_clicked` method.
            - "Toggle Filters" (Shortcut: Ctrl+F): Placeholder for toggling filters functionality.
        - Help Menu:
            - "About": Triggers the `show_about_dialog` method.
        Note:
            The "Toggle Filters" action currently does not have a connected method.
        """
        menu_bar = self.menuBar()
        menu_bar.setStyleSheet("background-color: black; color: white; font-weight: 600;")

        file_menu = menu_bar.addMenu("File")
        export_action = file_menu.addAction("Export to CSV")
        export_action.setShortcut("Ctrl+E")
        # export_action.triggered.connect(self.export_to_csv)

        print_action = file_menu.addAction("Print")
        print_action.setShortcut("Ctrl+P")
        print_action.triggered.connect(self.print_table)

        exit_action = file_menu.addAction("Exit")
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)

        view_menu = menu_bar.addMenu("View")
        refresh_action = view_menu.addAction("Refresh Logs")
        refresh_action.setShortcut("Ctrl+R")
        # refresh_action.triggered.connect(self.on_search_clicked)

        toggle_filters_action = view_menu.addAction("Toggle Filters")
        toggle_filters_action.setShortcut("Ctrl+F")
        # toggle_filters_action.triggered.connect(self.date_toggle_btn.click)

        help_menu = menu_bar.addMenu("Help")
        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self.show_about_dialog)

    # ----------------------------------------------------------------------------------------------------
    # Add the show_about_dialog to the layout
    # ----------------------------------------------------------------------------------------------------
    def show_about_dialog(self):
        QMessageBox.information(self, "About Heart Beat", "Heart Beat\n\nA productivity tracking tool.\nVersion 1.0\n\nCreated by You")

    # ----------------------------------------------------------------------------------------------------
    # Add the username to the layout
    # ----------------------------------------------------------------------------------------------------
    def print_table(self):
        QMessageBox.information(self, "Print", "Print functionality is not implemented yet.")

    # ----------------------------------------------------------------------------------------------------  
    # Add the username to the layout
    # ----------------------------------------------------------------------------------------------------
    def add_username(self):
        """
        Updates the GUI to display the current user's username.

        This method retrieves the current system username using `os.getlogin()` 
        and updates a QLabel widget in the GUI with the username. The label is 
        styled with specific font, alignment, size, and appearance properties.

        If the QLabel with the object name "usernameLabel" is not found, an 
        error is logged and the method exits without making any changes.

        Styling applied to the QLabel includes:
        - Font: Arial, size 10, bold
        - Alignment: Centered
        - Size policy: Expanding horizontally, fixed vertically
        - Minimum width: 100 pixels
        - Cursor: Pointing hand cursor
        - Background color: #3a86ff (blue)
        - Text color: White
        - Border radius: 6 pixels
        - Font weight: 600

        Raises:
            None

        Logs:
            - Logs an error if the QLabel "usernameLabel" is not found.

        Returns:
            None
        """
        current_user    = os.getlogin()
        username_label  = self.ui.findChild(QLabel, "usernameLabel")
        if not username_label:
            logging.error("username_label not found")
            return
        username_label.setText(f"{current_user}")
        username_label.setFont(QFont("Arial", 10, QFont.Bold))
        username_label.setAlignment(Qt.AlignCenter)
        username_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        username_label.setMinimumWidth(100)
        username_label.setCursor(Qt.PointingHandCursor)
        username_label.setStyleSheet("background-color: #3a86ff; color: white; border-radius: 6px; font-weight: 600;")
        
    # ----------------------------------------------------------------------------------------------------
    # change_theme method to change the theme of the GUI
    # ----------------------------------------------------------------------------------------------------
    # def change_theme(self, theme_name):
    #     """
    #     Changes the application's theme by applying the specified stylesheet and palette.

    #     Args:
    #         theme_name (str): The name of the theme to apply. If "Light", a light theme is used; 
    #                           otherwise, a dark theme is applied.

    #     Behavior:
    #         - Updates the application's stylesheet using the `themes` dictionary.
    #         - Sets the palette to white for the "Light" theme or black for other themes.
    #         - Enables auto-fill background for the application.
    #     """
    #     self.setStyleSheet(themes.get(theme_name, default_stylesheet))
    #     self.ui.setStyleSheet(themes.get(theme_name, default_stylesheet))
    #     self.setPalette(QPalette(QColor(255, 255, 255) if theme_name == "Light" else QColor(1, 1, 1)))
    #     self.setAutoFillBackground(True)

    # ----------------------------------------------------------------------------------------------------
    # add _icon_to_layout method to add the user icon to the layout
    # ----------------------------------------------------------------------------------------------------
    def add_icon_to_layout(self):
        """
        Adds an icon to a specified QVBoxLayout in the user interface.

        This method searches for a QVBoxLayout named "IconVLay" in the UI. If the layout
        is found, it creates a QLabel and attempts to load a QPixmap from the specified
        `icon_path`. If the pixmap is successfully loaded, it is scaled to 64x64 pixels
        while maintaining its aspect ratio, and added to the layout. If the pixmap cannot
        be loaded, a QLabel with an error message is added to the layout instead.

        The QLabel is configured with the following properties:
        - Alignment: Centered
        - Size policy: Expanding in both horizontal and vertical directions
        - Error message style: Red text with bold font (if the icon is not found)

        Attributes:
            None

        Parameters:
            None

        Returns:
            None
        """
        layout = self.ui.findChild(QVBoxLayout, "IconVLay")
        if layout:
            label = QLabel(self)
            pixmap = QPixmap(icon_path)
            if not pixmap.isNull():
                label.setPixmap(pixmap.scaled(64, 64, Qt.KeepAspectRatio))
                label.setAlignment(Qt.AlignCenter)
                label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
                layout.addWidget(label)
            else:
                label.setText("Icon not found")
                label.setAlignment(Qt.AlignCenter)
                label.setStyleSheet("color: red; font-weight: bold;")
                layout.addWidget(label)

    # ----------------------------------------------------------------------------------------------------
    # Connect the search button to the search function
    # ----------------------------------------------------------------------------------------------------
    def connection(self):
        self.ui.loginBtn.clicked.connect(self.log_as_superuser)

# --------------------------------------------------------------------------------------------------------
# Main function to run the application
# --------------------------------------------------------------------------------------------------------
def _main__():
    """
    Main function to run the User GUI application.
    This function initializes the QApplication, creates an instance of the UserGUI class,
    and starts the event loop. It ensures that the application exits cleanly when the main
    window is closed.
    """
    app = QApplication(sys.argv)
    gui = UserGUI()
    gui.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    _main__()