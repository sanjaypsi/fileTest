# -*- coding: utf-8 -*-
# Heart Beat Application - summary panel
# author: Sanja
# date: 2023-10-03
# description: This script is part of the Heart Beat Application and is responsible for the summary panel functionality.
# It includes methods to calculate the total active and inactive time for the current month, as well as the number of holidays.
# It also handles the loading of holiday configurations from a YAML file.

# === Imports ===
import yaml
from pymongo import MongoClient
from datetime import datetime
import os
import sys
import getpass
import logging
from typing import List, Dict
from datetime import timedelta
import getpass


# === Paths ===
script_path = os.path.abspath(__file__)
_root       = os.path.abspath(os.path.join(script_path, "..", "..", ".."))
sys.path.append(_root)

_holidays_path = os.path.join(_root, "config/holidaysList.yml")
if not os.path.exists(_holidays_path):
    raise FileNotFoundError(f"Holidays file not found at {_holidays_path}")

from core import connect_to_db

# === Logging === 
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# === Constants ===
def load_config():
    """
    Load the holiday configuration and return a list of holidays for the current month.

    Returns:
        list: List of holidays for the current month.
    """
    try:
        if os.path.exists(_holidays_path):
            with open(_holidays_path, 'r') as f:
                cfg = yaml.safe_load(f) or {}
                current_month = datetime.now().strftime("%B")

                # Safely get holidays for the current month
                holidays = cfg.get(current_month, [])
                return holidays  # Return list of holidays this month

    except Exception as e:
        logging.error(f"[CONFIG] Failed to load holiday config: {e}")

    return []

# =====================================================================================
# SummaryPanel Class
# =====================================================================================
class SummaryPanel:
    
    def __init__(self):
        
        self.client             = connect_to_db.MongoDatabase()
        self.pulse_logs_data    = self.client.get_logs()
        # self.pulse_summary_data = self.client.get_summaries()

    # -------------------------------------------------------------------------
    # get number_of_holidays in the month
    # -------------------------------------------------------------------------
    def get_number_of_holidays(self) -> int:
        """
        Returns the number of sessions in the pulse summary data.
        """
        
        self.holidays_in_month  = load_config()
        return len(self.holidays_in_month) 

    # -------------------------------------------------------------------------
    # get total Active time in this month
    # -------------------------------------------------------------------------
    def get_total_active_time(self) -> timedelta:
        """
        Returns the total active time in this month from pulse_summary_data.
        Supports:
        - timedelta
        - str in HH:MM:SS format
        - int/float representing seconds
        """
        total_active_time   = timedelta(0)
        current_user        = getpass.getuser()
        now = datetime.now()

        for summary in self.pulse_logs_data:
            if not isinstance(summary, dict):
                logging.warning(f"Ignored invalid summary type: {type(summary)}")
                continue

            # Check user
            if summary.get('username') != current_user:
                continue

            # Check timestamp for current month
            timestamp = summary.get('timestamp')
            if isinstance(timestamp, datetime):
                if timestamp.year != now.year or timestamp.month != now.month:
                    continue
            else:
                logging.warning(f"Ignored summary with invalid timestamp: {timestamp}")
                continue

            active_time = summary.get('active_time')

            if active_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("active_time is None, 0, or empty; skipping.")
                continue

            # Add active_time to total_active_time
            if isinstance(active_time, timedelta):
                total_active_time += active_time

            elif isinstance(active_time, str):
                try:
                    h, m, s = map(int, active_time.strip().split(":"))
                    total_active_time += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse active_time string '{active_time}': {e}")

            elif isinstance(active_time, (int, float)):
                total_active_time += timedelta(seconds=active_time)

            else:
                logging.warning(f"Ignored invalid active_time type: {type(active_time)} (value: {active_time})")

        return total_active_time

    # -------------------------------------------------------------------------
    # get total Inactive time in this month
    # -------------------------------------------------------------------------
    def get_total_inactive_time(self) -> timedelta:
        """
        Returns the total active time in this month from pulse_summary_data.
        Supports:
        - timedelta
        - str in HH:MM:SS format
        - int/float representing seconds
        """
        total_active_time = timedelta(0)
        current_user = getpass.getuser()
        now = datetime.now()

        for summary in self.pulse_logs_data:
            if not isinstance(summary, dict):
                logging.warning(f"Ignored invalid summary type: {type(summary)}")
                continue

            # Check user
            if summary.get('username') != current_user:
                continue

            # Check timestamp for current month
            timestamp = summary.get('timestamp')
            if isinstance(timestamp, datetime):
                if timestamp.year != now.year or timestamp.month != now.month:
                    continue
            else:
                logging.warning(f"Ignored summary with invalid timestamp: {timestamp}")
                continue

            inactive_time = summary.get('inactive_time')

            if inactive_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("inactive_time is None, 0, or empty; skipping.")
                continue

            # Add active_time to total_inactive_time
            if isinstance(inactive_time, timedelta):
                total_active_time += inactive_time

            elif isinstance(inactive_time, str):
                try:
                    h, m, s = map(int, inactive_time.strip().split(":"))
                    total_active_time += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse active_time string '{inactive_time}': {e}")

            elif isinstance(inactive_time, (int, float)):
                total_active_time += timedelta(seconds=inactive_time)

            else:
                logging.warning(f"Ignored invalid active_time type: {type(inactive_time)} (value: {inactive_time})")

        return total_active_time
    
    # -------------------------------------------------------------------------
    # get total active time off today in this month
    # -------------------------------------------------------------------------
    def get_total_active_time_off_today(self) -> timedelta:
        """
        Calculates the total active time for today from pulse_logs_data.
        Returns:
            timedelta: Total active time today.
        """
        today_date              = datetime.now().date()
        total_active_time_today = timedelta(0)
        current_user            = getpass.getuser()

        for summary in self.pulse_logs_data:
            # Check user
            if summary.get('username') != current_user:
                continue

            timestamp   = summary.get('timestamp')
            active_time = summary.get('active_time')

            # Validate and normalize timestamp
            if isinstance(timestamp, datetime):
                if timestamp.date() != today_date:
                    continue
            else:
                logging.warning(f"Ignored invalid timestamp: {timestamp} (type: {type(timestamp)})")
                continue
            
            if isinstance(active_time, timedelta):
                total_active_time_today += active_time

            elif isinstance(active_time, str):
                try:
                    h, m, s = map(int, active_time.split(":"))
                    total_active_time_today += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse active_time string '{active_time}': {e}")

            elif active_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("active_time is None, 0, or empty; skipping.")
                continue

            elif isinstance(active_time, (int, float)):
                total_active_time_today += timedelta(seconds=active_time)

            elif active_time is None:
                logging.debug("active_time is None; skipping.")

            else:
                logging.warning(f"Unsupported active_time type: {type(active_time)} (value: {active_time})")


        return total_active_time_today

    # -------------------------------------------------------------------------
    # get total inactive time off today in this month
    # -------------------------------------------------------------------------
    def get_total_inactive_time_off_today(self) -> timedelta:
        """
        first check today day  and get data from pulse_summary_data today
        and then return the total inactive time off today.
        Parses string durations into timedelta objects if needed.
        
        """
        today_date                  = datetime.now().date()
        total_inactive_time_today   = timedelta(0)
        current_user                = getpass.getuser()


        for summary in self.pulse_logs_data:
            # Check user
            if summary.get('username') != current_user:
                continue

            timestamp       = summary.get('timestamp')
            inactive_time   = summary.get('inactive_time')

            # Validate and normalize timestamp
            if isinstance(timestamp, datetime):
                if timestamp.date() != today_date:
                    continue
            else:
                logging.warning(f"Ignored invalid timestamp: {timestamp} (type: {type(timestamp)})")
                continue
            
            if isinstance(inactive_time, timedelta):
                total_inactive_time_today += inactive_time

            elif isinstance(inactive_time, str):
                try:
                    h, m, s = map(int, inactive_time.split(":"))
                    total_inactive_time_today += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse active_time string '{inactive_time}': {e}")

            elif inactive_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("active_time is None, 0, or empty; skipping.")
                continue

            elif isinstance(inactive_time, (int, float)):
                total_inactive_time_today += timedelta(seconds=inactive_time)

            elif inactive_time is None:
                logging.debug("active_time is None; skipping.")

            else:
                logging.warning(f"Unsupported active_time type: {type(inactive_time)} (value: {inactive_time})")

        return total_inactive_time_today
    
    # -------------------------------------------------------------------------
    # get inactive time since midnight
    # -------------------------------------------------------------------------
    def get_inactive_time_since_midnight(self) -> timedelta:
        """
        Calculates total inactive time for the current user since today's midnight.
        Handles timedelta, string, and numeric inactive_time formats.
        """
        start_of_today = datetime.combine(datetime.now().date(), datetime.min.time())
        total_inactive = timedelta(0)
        current_user = getpass.getuser()

        for summary in self.pulse_logs_data:
            if summary.get('username') != current_user:
                continue

            timestamp = summary.get('timestamp')
            inactive_time = summary.get('inactive_time')

            # Ensure timestamp is valid and after midnight today
            if not isinstance(timestamp, datetime):
                logging.warning(f"Ignored invalid timestamp: {timestamp} (type: {type(timestamp)})")
                continue
            if timestamp < start_of_today:
                continue

            # Add up inactive time based on its type
            if isinstance(inactive_time, timedelta):
                total_inactive += inactive_time

            elif isinstance(inactive_time, str):
                try:
                    h, m, s = map(int, inactive_time.strip().split(":"))
                    total_inactive += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse inactive_time string '{inactive_time}': {e}")

            elif isinstance(inactive_time, (int, float)):
                total_inactive += timedelta(seconds=inactive_time)

            elif inactive_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("inactive_time is empty or zero; skipping.")

            else:
                logging.warning(f"Unsupported inactive_time type: {type(inactive_time)} (value: {inactive_time})")

        return total_inactive

    # -------------------------------------------------------------------------
    # get inactive time summary for today and this month
    # -------------------------------------------------------------------------
    def get_inactive_time_summary(self):
        """
        Calculates:
        - Total inactive time today (since midnight)
        - Total inactive time this month
        Returns both as a tuple of timedeltas.
        Logs how many records matched each time range.
        """
        now = datetime.now()
        current_user = getpass.getuser()
        start_of_today = datetime.combine(now.date(), datetime.min.time())
        start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        total_today = timedelta(0)
        total_month = timedelta(0)

        match_today = 0
        match_month = 0

        for summary in self.pulse_logs_data:
            if summary.get('username') != current_user:
                continue

            timestamp = summary.get('timestamp')
            inactive_time = summary.get('inactive_time')

            # Validate timestamp
            if not isinstance(timestamp, datetime):
                logging.warning(f"Ignored invalid timestamp: {timestamp} (type: {type(timestamp)})")
                continue

            # Parse inactive_time
            parsed_time = None

            if isinstance(inactive_time, timedelta):
                parsed_time = inactive_time

            elif isinstance(inactive_time, str):
                try:
                    h, m, s = map(int, inactive_time.strip().split(":"))
                    parsed_time = timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse inactive_time string '{inactive_time}': {e}")

            elif isinstance(inactive_time, (int, float)):
                parsed_time = timedelta(seconds=inactive_time)

            elif inactive_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("inactive_time is empty or zero; skipping.")
                continue

            else:
                logging.warning(f"Unsupported inactive_time type: {type(inactive_time)} (value: {inactive_time})")
                continue

            # Accumulate totals based on time range
            if start_of_month <= timestamp <= now:
                total_month += parsed_time
                match_month += 1

            if start_of_today <= timestamp <= now:
                total_today += parsed_time
                match_today += 1

        logging.info(f"Matched entries for today: {match_today}")
        logging.info(f"Matched entries for this month: {match_month}")

        return total_today, total_month


# analyzer    = SummaryPanel()
# hd          = analyzer.get_number_of_holidays()
# print(f"Number of holidays this month: {hd}")

# # # total_time = analyzer.get_total_active_time()
# # # print(f"Total active time this month: {str(total_time).split('.')[0]}")

# # # total_time = analyzer.get_total_inactive_time()
# # # print(f"Total Inactive time this month: {str(total_time).split('.')[0]}")


# print(f"Total active time off today this month: {analyzer.get_total_active_time_off_today()}")
# print(f"Total Inactive time off today this month: {analyzer.get_total_inactive_time_off_today()}")
# print(f"Inactive time since midnight: {analyzer.get_inactive_time_since_midnight()}")

# today_inactive, month_inactive = analyzer.get_inactive_time_summary()
# print(f"Inactive time today: {today_inactive}")
# print(f"Inactive time this month: {month_inactive}")


