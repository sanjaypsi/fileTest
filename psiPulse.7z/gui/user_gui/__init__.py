
import sys
from PySide2.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QFrame
)
from PySide2.QtUiTools import QUiLoader
from PySide2.QtCore import QFile, QIODevice, Qt


class DashboardWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        container = self.load_ui("path_to_ui_file.ui")
        self.setCentralWidget(container)

    def load_ui(self, ui_path):
        loader = QUiLoader()
        file = QFile(ui_path)

        if not file.open(QIODevice.ReadOnly):
            print(f"[ERROR] Could not open UI file: {ui_path}")
            return QWidget()

        ui_widget = loader.load(file, None)
        file.close()

        if not ui_widget:
            print("[ERROR] UI loader returned None.")
            return QWidget()

        container = QWidget(self)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(ui_widget)

        stats_layout = QHBoxLayout()
        for label, value in [
            ("Total views", "186,257"),
            ("Total users", "9,712"),
            ("Total messages", "230"),
            ("Total connexions", "705")
        ]:
            card = self.create_stat_card(label, value)
            stats_layout.addWidget(card)

        stats_layout.setContentsMargins(0, 0, 0, 0)
        stats_layout.setSpacing(10)
        stats_layout.setAlignment(Qt.AlignLeft)

        layout.addLayout(stats_layout)

        self._loaded_widget = ui_widget
        self._container = container
        return container

    def create_stat_card(self, label, value):
        card = QFrame()
        card.setFixedSize(250, 80)
        card.setStyleSheet("""
            QFrame {
                background-color: #2c2c2c;
                border-bottom: 2px solid #00FFC6;
                border-radius: 6px;
            }
        """)
        layout  = QVBoxLayout(card)
        title   = QLabel(label)
        title.setStyleSheet("font-size: 12px; color: #bbb;")
        title.setAlignment(Qt.AlignCenter)

        val = QLabel(value)
        val.setStyleSheet("font-size: 20px; font-weight: bold;")
        val.setAlignment(Qt.AlignCenter)

        layout.addWidget(title)
        layout.addWidget(val)
        return card

