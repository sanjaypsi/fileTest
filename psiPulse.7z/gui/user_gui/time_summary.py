# -*- coding: utf-8 -*-
# Heart Beat Application - Time Summary Module
# author: Sanja
# date: 2023-10-01
# This module provides functionality to summarize active and inactive time
# from a list of time strings. It includes methods to parse time strings,
# calculate total active and inactive time, and format the results for display.
# The code is designed to be used in a GUI application, specifically for
# displaying time summaries in a user-friendly format.

# Import necessary libraries
from datetime import timedelta


# =====================================================================================================
# Class: TimeSummary
# =====================================================================================================
class TimeSummary:
    @staticmethod
    def parse_time_string(tstr):
        """
        Parses a time string in the format 'HH:MM' or 'HH:MM:SS' and returns a timedelta object.

        Args:
            tstr (str): The time string to be parsed.

        Returns:
            timedelta: A timedelta object representing the parsed time.

        """
        try:
            parts = tstr.split(":")
            if len(parts) == 2:
                return timedelta(hours=int(parts[0]), minutes=int(parts[1]))
            elif len(parts) == 3:
                return timedelta(hours=int(parts[0]), minutes=int(parts[1]), seconds=int(parts[2]))
        except:
            return timedelta()
        return timedelta()

    @staticmethod
    def summarize(data):
        """
        Summarizes the active and inactive time from the given data.

        Args:
            data (list): A list of rows containing time data.

        Returns:
            dict: A dictionary with the summarized active, inactive, and total time.
        """
        total_active = timedelta()
        total_inactive = timedelta()

        for row in data:
            active = TimeSummary.parse_time_string(row[1])
            inactive = TimeSummary.parse_time_string(row[2])

            total_active += active
            total_inactive += inactive

        total = total_active + total_inactive

        return {
            "active": TimeSummary.format_td(total_active),
            "inactive": TimeSummary.format_td(total_inactive),
            "total": TimeSummary.format_td(total)
        }

    @staticmethod
    def format_td(td):
        """
        Formats a timedelta object into a string representation of hours and minutes.

        Args:
            td (timedelta): The timedelta object to be formatted.

        Returns:
            str: The formatted string representation of the timedelta object in the format "Xh Ym".
        """
        total_minutes = int(td.total_seconds() // 60)
        hours = total_minutes // 60
        minutes = total_minutes % 60
        return f"{hours}h {minutes}m"
