
# from db.mongo_utils import UserFetcher
# users = UserFetcher.fetch_all_users_from_db()
# print(users)

import os
import sys
import re
from datetime import datetime
from datetime import timedelta
from typing import List, Optional, Dict
import logging
from PySide2.QtWidgets import QWidget
from PySide2.QtGui import QPainter, QColor, QFont
from PySide2.QtCore import Qt

# ============================================================================================================
# === Paths ===
# ============================================================================================================
script_path = os.path.abspath(__file__)
_root       = os.path.abspath(os.path.join(script_path, "..", "..", ".."))
sys.path.append(_root)

from core import connect_to_db  # noqa: E402

# ============================================================================================================
# === UserFetcher Class ===
# ============================================================================================================
class UserFetcher:

    @classmethod
    def fetch_all_users_from_db(cls):
        """
        Fetch and filter distinct usernames from the database.

        Filters out:
        - Machine accounts (ending in '$')
        - GUID-like strings (UUIDs)

        Returns:
            List of cleaned usernames (sorted).
        """
        client = connect_to_db.MongoDatabase()
        logs = client.get_logs()

        usernames = set()
        for log in logs:
            username = log.get("username", "")
            if not username:
                continue

            # Exclude machine accounts
            if username.endswith('$'):
                continue

            # Exclude UUID/GUID-like strings
            if re.fullmatch(r"[0-9A-Fa-f\-]{36}", username):
                continue

            usernames.add(username)

        return sorted(usernames)

# ============================================================================================================
# === GetPulseData Class ===
# ============================================================================================================
class GetPulseData:

    def __init__(self):
        self.client             = connect_to_db.MongoDatabase()
        self.pulse_logs_data    = self.client.get_logs()
        self.pulse_summary_data = self.client.get_summaries()

    @staticmethod
    def parse_time_to_seconds(value):
        if isinstance(value, (int, float)):
            return int(value)
        if isinstance(value, str):
            try:
                h, m, s = map(int, value.split(":"))
                return h * 3600 + m * 60 + s
            except Exception:
                return 0
        return 0

    # ---------------------------------------------------------------------------------------------------------
    # === Get pulse data for a specific date range and username ===
    # ---------------------------------------------------------------------------------------------------------
    def get_pulse_data(self,start_date: Optional[datetime] = None,end_date: Optional[datetime] = None,username: Optional[str] = None) -> List[dict]:

        filtered_logs = []

        # Normalize dates to cover full day span
        if start_date:
            start_date = datetime.combine(start_date.date(), datetime.min.time())
        if end_date:
            end_date = datetime.combine(end_date.date(), datetime.max.time())

        for log in self.pulse_logs_data:

            # Skip logs with unmatched username (exact match)
            if username and log.get("username") != username:
                continue

            timestamp = log.get("timestamp")
            if not timestamp:
                continue

            # Convert string timestamp to datetime if needed
            if isinstance(timestamp, str):
                try:
                    timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    continue

            # Filter by date range
            if start_date and timestamp < start_date:
                continue
            if end_date and timestamp > end_date:
                continue

            # Skip LOGON status entries
            if log.get('status') == "LOGON":
                continue

            # Parse active/inactive time
            active_seconds = self.parse_time_to_seconds(log.get('active_time', 0))
            inactive_seconds = self.parse_time_to_seconds(log.get('inactive_time', 0))

            log_data = {
                "username": log.get("username"),
                "hostname": log.get("hostname"),
                "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "status": log.get("status", "Unknown"),
                "active_time": str(timedelta(seconds=active_seconds)),
                "active_seconds": active_seconds,
                "inactive_time": str(timedelta(seconds=inactive_seconds)),
                "inactive_seconds": inactive_seconds
            }

            filtered_logs.append(log_data)

        return filtered_logs

    # ---------------------------------------------------------------------------------------------------------
    # === Get summary logs for a specific date range and username ===
    # ---------------------------------------------------------------------------------------------------------
    def get_summary_logs(self,start_date: Optional[datetime] = None,end_date: Optional[datetime] = None,username: Optional[str] = None) -> List[dict]:
        
        filtered_summaries = []

        # Normalize dates
        if start_date:
            start_date = datetime.combine(start_date.date(), datetime.min.time())
        if end_date:
            end_date = datetime.combine(end_date.date(), datetime.max.time())

        for summary in self.pulse_summary_data:
            user = summary.get("username", "")
            if username and user != username:
                # For case-insensitive match:
                # if username.lower() != user.lower():
                continue

            timestamp = summary.get("timestamp")
            if not timestamp:
                continue

            # Convert string timestamp if necessary
            if isinstance(timestamp, str):
                try:
                    timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    continue

            if start_date and timestamp < start_date:
                continue
            if end_date and timestamp > end_date:
                continue

            log_data = {
                "username": summary.get("username"),
                "hostname": summary.get("hostname"),
                "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "status": "Summary",
                "active_time": summary.get("active_time", "00:00:00"),
                "inactive_time": summary.get("inactive_time", "00:00:00")
            }

            filtered_summaries.append(log_data)

        # Sort by timestamp ascending
        filtered_summaries.sort(key=lambda x: x["timestamp"])

        return filtered_summaries

        # ---------------------------------------------------------------------------------------------------------
    
    # ---------------------------------------------------------------------------------------------------------
    # === Calculate total inactive time for today from gaps ===
    # ---------------------------------------------------------------------------------------------------------
    def calculate_today_inactive_time_from_gaps(self, username):
        today = datetime.now().date()
        start_of_day = datetime.combine(today, datetime.min.time())
        end_of_day = datetime.now()  # up to current time, not midnight tonight

        logs = self.get_pulse_data(start_date=start_of_day, end_date=end_of_day, username=username)

        # Sort logs chronologically
        logs = sorted(logs, key=lambda x: datetime.strptime(x["timestamp"], "%Y-%m-%d %H:%M:%S"))

        total_inactive = timedelta()
        current = start_of_day

        for log in logs:
            ts = datetime.strptime(log["timestamp"], "%Y-%m-%d %H:%M:%S")
            if ts > current:
                # Count the gap as inactivity
                total_inactive += ts - current

            # Advance current pointer based on activity
            active_seconds = log.get("active_seconds", 0)
            if active_seconds:
                current = ts + timedelta(seconds=active_seconds)
            else:
                current = ts

        # Add any remaining gap until now
        if current < end_of_day:
            total_inactive += end_of_day - current

        return str(total_inactive)
    
    # ---------------------------------------------------------------------------------------------------------
    # === Get total active time for today ===
    # ---------------------------------------------------------------------------------------------------------
    def get_today_active_time(self, username: str) -> timedelta:
        today = datetime.now().date()
        start_of_day = datetime.combine(today, datetime.min.time())
        end_of_now = datetime.now()

        logs = self.get_pulse_data(start_date=start_of_day, end_date=end_of_now, username=username)
        total_active = sum((log["active_seconds"] for log in logs), 0)

        return timedelta(seconds=total_active)
    
    # ---------------------------------------------------------------------------------------------------------
    # === Get total inactive time for today ===
    # ---------------------------------------------------------------------------------------------------------
    def get_today_inactive_time(self, username: str) -> timedelta:
        now = datetime.now()
        total_day_duration = now - datetime.combine(now.date(), datetime.min.time())

        active_time = self.get_today_active_time(username)

        inactive_time = total_day_duration - active_time
        return inactive_time if inactive_time > timedelta(0) else timedelta(0)

# ============================================================================================================
# ===  class SummaryPanel - get total active time in current month for a user === 
# ============================================================================================================
class SummaryPanel:
    def __init__(self):
        self.client = connect_to_db.MongoDatabase()
        self.pulse_summary_data = self.client.get_logs()  # Should return list of dicts

    # ---------------------------------------------------------------------------------------------------------
    # === Get total active time for a user in the current month ===
    # ---------------------------------------------------------------------------------------------------------
    def get_total_active_time(self, username):
        """
        Calculate the total active time for a given user in the current month.

        Args:
            username (str): The username to filter by.

        Returns:
            str: Total active time in "HH:MM:SS" format.
        """
        now = datetime.now()
        total_active_time = timedelta(0)

        for summary in self.pulse_summary_data:
            if not isinstance(summary, dict):
                logging.warning(f"Ignored invalid summary type: {type(summary)}")
                continue

            if summary.get("username") != username:
                continue

            timestamp = summary.get("timestamp")
            if isinstance(timestamp, str):
                try:
                    timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    logging.warning(f"Ignored summary with invalid timestamp format: {timestamp}")
                    continue
            elif not isinstance(timestamp, datetime):
                logging.warning(f"Ignored summary with non-datetime timestamp: {timestamp}")
                continue

            if timestamp.year != now.year or timestamp.month != now.month:
                continue

            active_time = summary.get("active_time")
            if active_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("active_time is None, 0, or empty; skipping.")
                continue

            if isinstance(active_time, timedelta):
                total_active_time += active_time

            elif isinstance(active_time, str):
                try:
                    h, m, s = map(int, active_time.strip().split(":"))
                    total_active_time += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse active_time string '{active_time}': {e}")

            elif isinstance(active_time, (int, float)):
                total_active_time += timedelta(seconds=active_time)

            else:
                logging.warning(f"Ignored invalid active_time type: {type(active_time)} (value: {active_time})")

        return str(total_active_time)

    # ---------------------------------------------------------------------------------------------------------
    # === Get total working days for a user in the current month ===
    # ---------------------------------------------------------------------------------------------------------
    def get_total_working_days_readable(self, username):
        """
        Converts total active time into working days (9h/day) and remaining time.
        Handles formats like '1 day, 7:43:29' or '49:15:52'.

        Args:
            username (str): The user to calculate for.

        Returns:
            str: Total working time in "X days, HH:MM:SS" format.
        """
        active_time_str = self.get_total_active_time(username).strip()

        try:
            # Handle format like '1 day, 7:43:29' or '2 days, 8:30:00'
            day_match = re.match(r"(?:(\d+)\s+day[s]?,\s*)?(\d+):(\d+):(\d+)", active_time_str)
            if not day_match:
                print(f"Invalid time format: {active_time_str}")
                return "Invalid time format"

            days    = int(day_match.group(1)) if day_match.group(1) else 0
            hours   = int(day_match.group(2))
            minutes = int(day_match.group(3))
            seconds = int(day_match.group(4))

            total_seconds = days * 86400 + hours * 3600 + minutes * 60 + seconds
            seconds_per_work_day = 9 * 3600  # 9 hours per workday

            full_work_days = total_seconds // seconds_per_work_day
            remainder_seconds = total_seconds % seconds_per_work_day

            remainder_td = timedelta(seconds=remainder_seconds)

            return f"{int(full_work_days)} days, {str(remainder_td)}"

        except Exception as e:
            print(f"Parsing failed: {e}")
            return "Invalid time format"

    # ---------------------------------------------------------------------------------------------------------
    # === Get total inactive time for a user in the current month ===
    # ---------------------------------------------------------------------------------------------------------
    def get_total_inactive_time(self, username):
        """
        Calculate the total inactive time for a given user in the current month.

        Args:
            username (str): The username to filter by.

        Returns:
            str: Total inactive time in "HH:MM:SS" format.
        """
        now = datetime.now()
        total_inactive_time = timedelta(0)

        for summary in self.pulse_summary_data:
            if not isinstance(summary, dict):
                logging.warning(f"Ignored invalid summary type: {type(summary)}")
                continue

            if summary.get("username") != username:
                continue

            timestamp = summary.get("timestamp")
            if isinstance(timestamp, str):
                try:
                    timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    logging.warning(f"Ignored summary with invalid timestamp format: {timestamp}")
                    continue
            elif not isinstance(timestamp, datetime):
                logging.warning(f"Ignored summary with non-datetime timestamp: {timestamp}")
                continue

            if timestamp.year != now.year or timestamp.month != now.month:
                continue

            inactive_time = summary.get("inactive_time")
            if inactive_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("inactive_time is None, 0, or empty; skipping.")
                continue

            if isinstance(inactive_time, timedelta):
                total_inactive_time += inactive_time

            elif isinstance(inactive_time, str):
                try:
                    h, m, s = map(int, inactive_time.strip().split(":"))
                    total_inactive_time += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse inactive_time string '{inactive_time}': {e}")

            elif isinstance(inactive_time, (int, float)):
                total_inactive_time += timedelta(seconds=inactive_time)

            else:
                logging.warning(f"Ignored invalid inactive_time type: {type(inactive_time)} (value: {inactive_time})")

        return str(total_inactive_time)

    # ---------------------------------------------------------------------------------------------------------
    # === Convert inactive time string for user to total working days ===
    # ---------------------------------------------------------------------------------------------------------
    def convert_inactive_time_to_working_days(self, username):
        """
        Converts inactive time string for the given username to total working days.

        Args:
            username (str): The username to calculate for.

        Returns:
            str: Total time as "X days, HH:MM:SS"
        """
        inactive_time_str = self.get_total_inactive_time(username).strip()

        try:
            day_match = re.match(r"(?:(\d+)\s+day[s]?,\s*)?(\d+):(\d+):(\d+)", inactive_time_str)
            if not day_match:
                logging.warning(f"Invalid time format: {inactive_time_str}")
                return "Invalid time format"

            days = int(day_match.group(1)) if day_match.group(1) else 0
            hours = int(day_match.group(2))
            minutes = int(day_match.group(3))
            seconds = int(day_match.group(4))

            total_seconds = days * 86400 + hours * 3600 + minutes * 60 + seconds
            seconds_per_work_day = 9 * 3600  # 9 hours per workday

            full_work_days = total_seconds // seconds_per_work_day
            remainder_seconds = total_seconds % seconds_per_work_day

            remainder_td = timedelta(seconds=remainder_seconds)

            return f"{int(full_work_days)} days, {str(remainder_td)}"

        except Exception as e:
            logging.error(f"Parsing failed: {e}")
            return "Invalid time format"

    # ---------------------------------------------------------------------------------------------------------
    # === Get Today active time for a user in the current month ===
    # ---------------------------------------------------------------------------------------------------------
    def get_today_active_time(self, username):
        """
        Calculate the total active time for a given user today.

        Args:
            username (str): The username to filter by.

        Returns:
            str: Total active time in "HH:MM:SS" format.
        """
        now = datetime.now()
        total_active_time = timedelta(0)

        for summary in self.pulse_summary_data:
            if not isinstance(summary, dict):
                logging.warning(f"Ignored invalid summary type: {type(summary)}")
                continue

            if summary.get("username") != username:
                continue

            timestamp = summary.get("timestamp")
            if isinstance(timestamp, str):
                try:
                    timestamp = datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    logging.warning(f"Ignored summary with invalid timestamp format: {timestamp}")
                    continue
            elif not isinstance(timestamp, datetime):
                logging.warning(f"Ignored summary with non-datetime timestamp: {timestamp}")
                continue

            if timestamp.year != now.year or timestamp.month != now.month or timestamp.day != now.day:
                continue

            active_time = summary.get("active_time")
            if active_time in (None, 0, "0", "", "0:00:00"):
                logging.debug("active_time is None, 0, or empty; skipping.")
                continue

            if isinstance(active_time, timedelta):
                total_active_time += active_time

            elif isinstance(active_time, str):
                try:
                    h, m, s = map(int, active_time.strip().split(":"))
                    total_active_time += timedelta(hours=h, minutes=m, seconds=s)
                except Exception as e:
                    logging.warning(f"Could not parse active_time string '{active_time}': {e}")

            elif isinstance(active_time, (int, float)):
                total_active_time += timedelta(seconds=active_time)

            else:
                logging.warning(f"Ignored invalid active_time type: {type(active_time)} (value: {active_time})")

        return str(total_active_time)
    
    # ---------------------------------------------------------------------------------------------------------
    # === Get Today inactive time for a user in the current month ===
    # ---------------------------------------------------------------------------------------------------------
    def get_today_inactive_time(self, username):
        now = datetime.now()
        midnight = datetime.combine(now.date(), datetime.min.time())
        total_inactive_time = timedelta()

        # Get today's records sorted by timestamp
        today_records = [
            s for s in self.pulse_summary_data
            if isinstance(s, dict)
            and s.get("username") == username
            and s.get("timestamp")
        ]

        # Sort by timestamp
        today_records.sort(key=lambda x: x["timestamp"])

        for entry in today_records:
            timestamp_str = entry.get("timestamp")
            try:
                timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S")
            except:
                continue

            # Only process today's logs
            if timestamp.date() != now.date():
                continue

            inactive_str = entry.get("inactive_time")
            if not inactive_str or inactive_str in ("", "0", "0:00:00"):
                continue

            try:
                h, m, s = map(int, inactive_str.split(":"))
                inactive_duration = timedelta(hours=h, minutes=m, seconds=s)
            except:
                continue

            total_inactive_time += inactive_duration

        return str(total_inactive_time)

# ============================================================================================================
# # === Example usage ===
# # ==========================================================================================================
class ActivityBar(QWidget):
    def __init__(self, active_percent=0, parent=None):
        super().__init__(parent)
        self.active_percent = max(0, min(100, active_percent))
        self.setMinimumHeight(25)

    def set_active_percent(self, value):
        self.active_percent = max(0, min(100, value))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        width = self.width()
        height = self.height()

        active_width = int(width * self.active_percent / 100)

        # Draw active (green)
        painter.fillRect(0, 0, active_width, height, QColor("#00C853"))

        # Draw inactive (red)
        painter.fillRect(active_width, 0, width - active_width, height, QColor("#D32F2F"))

        # Draw percentage text
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        text = f"{self.active_percent}% Active / {100 - self.active_percent}% Inactive"
        painter.drawText(self.rect(), Qt.AlignCenter, text)

# ============================================================================================================
# # # === Example usage ===
# # ==========================================================================================================
def parse_time_to_seconds(time_str):
    hours, minutes, seconds = map(int, time_str.split(":"))
    return hours * 3600 + minutes * 60 + seconds

def format_seconds_to_hms(total_seconds):
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f"{hours}:{minutes:02}:{seconds:02}"

def get_today_active_time(username):
    """
    Get the total active time for today for a given username.

    Args:
        username (str): The username to filter by.

    Returns:
        str: Total active time in "HH:MM:SS" format.
    """
    now = datetime.now()
    start_of_day    = datetime.combine(now.date(), datetime.min.time())
    end_of_now      = now

    logs = GetPulseData().get_pulse_data(start_date=start_of_day, end_date=end_of_now, username=username)
    total_active = sum((log["active_seconds"] for log in logs), 0)

    return str(timedelta(seconds=total_active))

# # ============================================================================================================
# sp = SummaryPanel()

# selected_user = "sanjay"
# act_time = sp.get_total_active_time(selected_user)
# print(f"Total active time for {selected_user} in current month: {act_time}")

# # === Example usage ===
# if __name__ == "__main__":
#     SP              = GetPulseData()
#     active_today    = SP.get_today_active_time("sanjay")
#     inactive_today  = SP.calculate_today_inactive_time_from_gaps("sanjay")

#     print("Today's Active Time:", active_today)
#     print("Today's Inactive Time:", inactive_today)


##=== Example usage ===
# if __name__ == "__main__":
#     SP = SummaryPanel()
#     result = SP.get_total_active_time("sanjay")
#     print(f"Total active time for sanjay in current month: {result}")

# if __name__ == "__main__":
#     dt = GetPulseData()

#     start_date  = datetime(2025, 5, 22)
#     end_date    = datetime(2025, 5, 22)
#     username    = "sanjay"
#     data        = dt.get_pulse_data(start_date, end_date, username)

#     act = []
#     for log in data:
#         act.append(log.get("active_time"))

# # Calculate total
# total_seconds   = sum(parse_time_to_seconds(t) for t in act)
# formatted_total = format_seconds_to_hms(total_seconds)

# print(f" Total Active Time: {formatted_total} (HH:MM:SS)")
