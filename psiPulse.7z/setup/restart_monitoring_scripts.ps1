# restart_monitoring_scripts.ps1

$pythonw    = "\\psi-emc\Zdrv\apps\win64\psi\tools\psiPulse\app\python310\pythonw.exe"
$scriptDir  = "\\psi-emc\Zdrv\apps\win64\psi\tools\psiPulse\core"
$scripts    = @("run_monitor.py", "idle_reporter.py")

# Get current username
$currentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$currentUser = $currentIdentity.Name.Split('\\')[-1]

foreach ($script in $scripts) {
    $fullPath = Join-Path $scriptDir $script

    # Find running instances owned by current user
    $running = Get-WmiObject Win32_Process -Filter "Name = 'pythonw.exe'" | Where-Object {
        $_.CommandLine -like "*$script*" -and (
            ($owner = $_.GetOwner()) -and $owner.User -eq $currentUser
        )
    }

    if ($running) {
        foreach ($proc in $running) {
            try {
                Stop-Process -Id $proc.ProcessId -Force
                Start-Sleep -Milliseconds 500
                Write-Output "[$(Get-Date)] Stopped ${script} (PID: $($proc.ProcessId))"
            } catch {
                $errorMsg = $_.Exception.Message
                Write-Output "[$(Get-Date)] Failed to stop ${script} (PID: $($proc.ProcessId)): $errorMsg"
            }
        }
    } else {
        Write-Output "[$(Get-Date)] ${script} was not running."
    }

    Start-Sleep -Seconds 2  # Optional pause before restart

    try {
        Start-Process -WindowStyle Hidden -FilePath $pythonw -ArgumentList "`"$fullPath`""
        Write-Output "[$(Get-Date)] Launched ${script}"
    } catch {
        $errorMsg = $_.Exception.Message
        Write-Output "[$(Get-Date)] Failed to launch ${script}: $errorMsg"
    }
}
