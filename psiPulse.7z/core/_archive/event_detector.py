# -*- coding: utf-8 -*-
# event_detector.py - Secure event log scanner
# Author: Sanja
# Updated: 2025-06-12

import win32evtlog
import win32security
import pywintypes
import socket
import logging
import os
import subprocess


class EventDetector:
    EVENT_IDS = [4624, 4647, 4634, 6005]

    def __init__(self, max_records=500):
        self.hostname = socket.gethostname()
        self.server = 'localhost'
        self.log_type = 'Security'
        self.max_records = max_records
        self.EXCLUDED_USERS = self.get_system_accounts()
        self.EXCLUDED_USERS.update({"SYSTEM", "PIPE$", "-", "ADMINISTRATOR"})

        # Adjust channel access so standard users can read Security logs
        try:
            subprocess.run(
                ['wevtutil', 'sl', 'Security', '/ca:O:BAG:SYD:(A;;0x1;;;S-1-5-32-545)'],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except Exception as e:
            logging.warning(f"Failed to adjust Security log channel access: {e}")

        # Setup logging
        log_path = "C:\\Users\\Public\\InactivityService\\event_detector.log"
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        logging.basicConfig(
            filename=log_path,
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s"
        )
        logging.info(f"Excluded users: {self.EXCLUDED_USERS}")

    @staticmethod
    def get_system_accounts():
        system_accounts = set()
        sids = [
            "S-1-5-18",  # Local System
            "S-1-5-19",  # Local Service
            "S-1-5-20",  # Network Service
        ]
        for sid_str in sids:
            try:
                sid = win32security.ConvertStringSidToSid(sid_str)
                name, _, _ = win32security.LookupAccountSid(None, sid)
                system_accounts.add(name.upper())
            except pywintypes.error:
                pass
        return system_accounts

    def resolve_sid_to_username(self, sid_str):
        try:
            sid = win32security.ConvertStringSidToSid(sid_str)
            name, _, _ = win32security.LookupAccountSid(None, sid)
            return name
        except Exception:
            return sid_str

    def parse_username(self, event):
        inserts = event.StringInserts
        if not inserts:
            return None

        try:
            username = None
            if event.EventID == 4624 and len(inserts) > 5:
                username = inserts[5].strip()
            elif event.EventID == 4647 and len(inserts) > 1:
                username = self.resolve_sid_to_username(inserts[1].strip())
            elif event.EventID == 4634 and len(inserts) > 0:
                username = self.resolve_sid_to_username(inserts[0].strip())
            elif event.EventID == 6005:
                username = "SYSTEM"

            if username:
                uname_upper = username.upper()
                if (
                    uname_upper in self.EXCLUDED_USERS or
                    uname_upper.startswith("UMFD-") or
                    uname_upper.startswith("DWM-")
                ):
                    return None
                return username
        except Exception as e:
            logging.warning(f"Failed to parse username: {e}")
        return None

    def get_latest_user_events(self, count=5):
        try:
            handle = win32evtlog.OpenEventLog(self.server, self.log_type)
        except Exception as e:
            logging.error(f"Failed to open event log: {e}")
            return []

        flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
        events = []
        seen = set()
        results = []

        try:
            while len(events) < self.max_records:
                chunk = win32evtlog.ReadEventLog(handle, flags, 0)
                if not chunk:
                    break
                events.extend(chunk)

            for event in events:
                if event.EventID not in self.EVENT_IDS:
                    continue

                username = self.parse_username(event)
                if not username or username.upper() in self.EXCLUDED_USERS:
                    continue

                event_type = {
                    4624: "Logon",
                    4647: "Logoff",
                    4634: "Logoff",
                    6005: "Startup"
                }.get(event.EventID, "Other")

                timestamp = str(event.TimeGenerated)
                key = (event_type, timestamp, username)

                if key in seen:
                    continue

                seen.add(key)
                results.append({
                    "event_type": event_type,
                    "username": username,
                    "hostname": self.hostname,
                    "timestamp": timestamp
                })

                if len(results) >= count:
                    break
        except Exception as e:
            logging.error(f"Error while scanning event log: {e}")

        return results


# === Example Usage ===
if __name__ == "__main__":
    detector = EventDetector()
    recent_events = detector.get_latest_user_events(count=5)

    print("Recent User Events:")
    if recent_events:
        print("Most Recent Valid User Event:")
        print(f"{recent_events[0]['timestamp']} - {recent_events[0]['event_type']} by {recent_events[0]['username']} on {recent_events[0]['hostname']}")
        print("\nRecent Valid User Events:")
        for event in recent_events:
            print(f"{event['timestamp']} - {event['event_type']} by {event['username']} on {event['hostname']}")
            logging.info(f"{event['timestamp']} - {event['event_type']} by {event['username']} on {event['hostname']}")
    else:
        print("No valid user events found.")
