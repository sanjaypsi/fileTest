# -*- coding: utf-8 -*-
# inactivity_monitor.py - Logs user activity and inactivity
# Author: Sanja

import os
import sys
import time
import socket
import signal
import logging
import yaml
import getpass
import atexit
from datetime import datetime, timedelta  # noqa: F401

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

import connect_to_db  # Custom module to handle MongoDB connections  # noqa: E402

# === Constants ===
BASE_DIR            = os.path.join(os.environ.get("USERPROFILE", os.getcwd()), "InactivityDetector")
LOG_FILE            = os.path.join(BASE_DIR, "inactivity_monitor.log")
DEFAULT_SETTINGS    = {'timeout': 300, 'log_level': "DEBUG"}

# Ensure base directory exists
os.makedirs(BASE_DIR, exist_ok=True)

# Set up logging (append mode to preserve logs)
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

logging.info("=== Inactivity monitor started ===")

# Path to config.yml
script_path     = os.path.dirname(os.path.abspath(__file__))
_root           = os.path.abspath(os.path.join(script_path, ".."))
SETTINGS_FILE   = os.path.join(_root, "config/config.yml").replace("\\", "/")


class InactivityMonitor:
    def __init__(self):
        # Signal handlers for graceful shutdown
        signal.signal(signal.SIGTERM, self.handle_exit)
        signal.signal(signal.SIGINT, self.handle_exit)
        atexit.register(self.insert_day_change)

        logging.info("Signal handlers registered for graceful shutdown.")

        self.username       = os.getlogin() or getpass.getuser()
        self.hostname       = socket.gethostname()
        self.status_file    = os.path.join(BASE_DIR, "status.txt")

        self.db             = self.connect_to_db()

        if self.db:
            logging.info("Database connection is active.")
        else:
            logging.warning("Database connection failed. Monitor will still run, but no data will be saved.")

        self.load_settings()

    def handle_exit(self, signum, frame):
        logging.info("Shutdown signal received. Exiting monitor...")
        sys.exit(0)

    def connect_to_db(self):
        try:
            db = connect_to_db.MongoDatabase()
            logging.info("Connected to MongoDB.")
            return db
        except Exception as e:
            logging.error(f"Database connection failed: {e}")
            return None

    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, 'r') as f:
                    user_settings = yaml.safe_load(f)
                    self.settings = {**DEFAULT_SETTINGS, **user_settings.get('settings', {})}
                    logging.info(f"Settings loaded: {self.settings}")
            except Exception as e:
                logging.error(f"Failed to load settings: {e}")
                self.settings = DEFAULT_SETTINGS
        else:
            self.settings = DEFAULT_SETTINGS

    def log_activity(self, status, duration):
        entry = {
            "username"      : self.username,
            "hostname"      : self.hostname,
            "timestamp"     : datetime.now(),
            "status"        : status,
            "active_time"   : round(duration, 2) if status == "Active" else 0,
            "inactive_time" : round(duration, 2) if status == "Inactive" else 0
        }

        try:
            if self.db:
                self.db.insert_pulse(entry)
                logging.info(f"Logged {status} to database: {entry}")
            else:
                logging.warning("No DB connection available.")
        except Exception as e:
            logging.exception(f"Failed to log activity: {e}")

    def monitor(self):
        last_status         = "Active"
        last_change_time    = time.time()
        start_time          = time.time()
        total_runtime       = self.settings.get("total_runtime", 0)
        check_interval      = self.settings.get("check_interval", 5)

        while True:
            try:
                if total_runtime > 0 and (time.time() - start_time) > total_runtime:
                    logging.info("Total runtime reached. Exiting monitor loop.")
                    break

                current_time = time.time()

                if os.path.exists(self.status_file):
                    with open(self.status_file, "r") as f:
                        status = f.read().strip() or last_status

                    if status != last_status:
                        duration = current_time - last_change_time
                        self.log_activity(status, duration)
                        logging.info(f"Status updated: {status}")

                        last_status = status
                        last_change_time = current_time
                else:
                    logging.warning(f"Status file not found: {self.status_file}")

                time.sleep(check_interval)

            except Exception as e:
                logging.exception("Error in monitor loop")

    def insert_day_change(self):
        """Insert a final entry at day change based on user's last known status."""
        current_time = datetime.now()
        start_of_day = datetime.combine(current_time.date(), datetime.min.time())

        try:
            if not self.db:
                logging.warning("No DB connection available for day change entry.")
                return

            # Read current status
            if os.path.exists(self.status_file):
                with open(self.status_file, "r") as f:
                    status = f.read().strip()
            else:
                logging.warning("Status file not found during day change insert.")
                return

            if status not in ("Active", "Inactive"):
                logging.warning(f"Invalid status '{status}' in status file.")
                return

            # Find last activity today
            last_entry = self.db.find_last_activity(self.username, start_of_day, current_time)

            if last_entry and "timestamp" in last_entry:
                last_activity_time = last_entry["timestamp"]
            else:
                last_activity_time = start_of_day
                logging.info("No activity record found for today. Assuming start of day.")

            duration = (current_time - last_activity_time).total_seconds()
            if duration <= 0:
                logging.info("No positive duration since last record. Skipping insert.")
                return

            entry = {
                "username"      : self.username,
                "hostname"      : self.hostname,
                "timestamp"     : current_time,
                "status"        : f"{status}_end_of_day",
                "active_time"   : round(duration / 3600, 2) if status == "Active" else 0,
                "inactive_time" : round(duration / 3600, 2) if status == "Inactive" else 0,
                "note": "Auto-inserted at day change"
            }

            self.db.insert_pulse(entry)
            logging.info(f"Inserted end-of-day '{status}' entry: {entry}")

        except Exception as e:
            logging.exception(f"Failed to insert day change activity entry: {e}")


# Run if launched directly
if __name__ == "__main__":
    monitor = InactivityMonitor()
    monitor.monitor()
