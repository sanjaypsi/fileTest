# -*- coding: utf-8 -*-
# SystemTray.py
# Author        : Sanja
# Project       : PulseWork
# Updated       : 2025-04-16
# Description   : This script creates a system tray icon for monitoring activity status.


import sys
import pystray
from PIL import Image, ImageDraw
import threading
import time
import os
import subprocess

# === Add absolute path to user_gui to sys.path ===
script_path         = os.path.abspath(__file__)
_root               = os.path.abspath(os.path.join(script_path, "..", ".."))
user_gui_path       = os.path.join(_root, "gui", "user_gui")  # Correct path to user_gui

sys.path.append(user_gui_path)

# === Imports ===
try:
    from main_ui import _main__  # noqa: F401
except ImportError as e:
    print(f"Error importing main_ui: {e}")
    sys.exit(1)

# ===============================================================================================================
# === Class: ActivityTrayIcon ===
# ===============================================================================================================
class ActivityTrayIcon:
    def __init__(self, detector):
        """Initializes the system tray icon for activity status."""
        self.detector = detector
        self.icon = pystray.Icon("activity_tracker", self.create_icon_image(), menu=self.create_menu())
        self.running = True
        self.status_file = getattr(detector, "status_file", None)
        self.log_file = getattr(detector, "log_file", None)

    # ------------------------------------------------------------------------------------------------------------
    # Create Icon
    # ------------------------------------------------------------------------------------------------------------
    def create_icon_image(self):
        """Generates a simple system tray icon."""
        image = Image.new("RGB", (64, 64), (0, 128, 255))
        draw = ImageDraw.Draw(image)
        draw.rectangle((10, 10, 54, 54), fill=(255, 255, 255))
        return image

    # ------------------------------------------------------------------------------------------------------------
    # Create Menu
    # ------------------------------------------------------------------------------------------------------------
    def create_menu(self):
        """Creates the right-click menu for the tray icon."""
        return pystray.Menu(
            pystray.MenuItem("Show Logs", self.show_logs),
            pystray.MenuItem("Refresh Status", self.refresh_status)
        )

    # ------------------------------------------------------------------------------------------------------------
    # Show Logs Ui
    # ------------------------------------------------------------------------------------------------------------
    def show_logs(self):
        """Opens the main UI using subprocess."""
        try:
            # Explicitly specify Python executable to launch the UI in a new process  \\psi-emc\Zdrv\apps\win64\psi\tools\psiPulse
            python_executable   = r"\\psi-emc\Zdrv\apps\win64\psi\tools\psiPulse\app\python310\python.exe"
            script_path         = r"\\psi-emc\Zdrv\apps\win64\psi\tools\psiPulse\gui\user_gui\main_ui.py"

            subprocess.Popen([python_executable, script_path])
        except Exception as e:
            print(f"Error opening main UI: {e}")

    # ------------------------------------------------------------------------------------------------------------
    # Refresh Status
    # ------------------------------------------------------------------------------------------------------------
    def refresh_status(self):
        """Forces a status refresh and updates tooltip."""
        try:
            if self.status_file and os.path.exists(self.status_file):
                with open(self.status_file, "r") as f:
                    status = f.read().strip()
                    self.icon.title = f"Status: {status}"
        except Exception as e:
            print(f"Error refreshing status: {e}")

    # ------------------------------------------------------------------------------------------------------------
    # Update Tray Time
    # ------------------------------------------------------------------------------------------------------------
    def update_tray_time(self):
        """Updates system tray tooltip with current activity status."""
        while self.running:
            try:
                status = getattr(self.detector, "last_status", "Unknown")
                self.icon.title = f"Status: {status}"
            except Exception:
                self.icon.title = "Status: Error"
            time.sleep(5)

    # ------------------------------------------------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------------------------------------------------
    def run(self):
        """Runs the system tray icon and updates it in a separate thread."""
        threading.Thread(target=self.update_tray_time, daemon=True).start()
        self.icon.run()

    # ------------------------------------------------------------------------------------------------------------
    # Stop
    # ------------------------------------------------------------------------------------------------------------
    def stop(self):
        """Stops the tray icon gracefully."""
        self.running = False
        self.icon.stop()

# # Uncomment the following lines to run the tray icon directly
# # Running the tray icon
# if __name__ == "__main__":
#     # Assuming 'detector' is an object or data structure you have initialized
#     detector = None  # Replace this with your actual detector object
#     tray_icon = ActivityTrayIcon(detector)
#     tray_icon.run()
