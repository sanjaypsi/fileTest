
import os
import sys
import time
import socket
import signal
import logging
import yaml
import getpass
from datetime import datetime, timedelta  # noqa: F401

def insert_day_change(self):
    """Insert a final entry at day change based on user's last known status."""
    current_time = datetime.now()
    start_of_day = datetime.combine(current_time.date(), datetime.min.time())

    try:
        if not self.db:
            logging.warning("No DB connection available for day change entry.")
            return

        # Read current status
        if os.path.exists(self.status_file):
            with open(self.status_file, "r") as f:
                status = f.read().strip()
        else:
            logging.warning("Status file not found during day change insert.")
            return

        if status not in ("Active", "Inactive"):
            logging.warning(f"Invalid status '{status}' in status file.")
            return

        # Find last activity today
        last_entry = self.db.find_last_activity(self.username, start_of_day, current_time)

        if last_entry and "timestamp" in last_entry:
            last_activity_time = last_entry["timestamp"]
        else:
            last_activity_time = start_of_day
            logging.info("No activity record found for today. Assuming start of day.")

        duration = (current_time - last_activity_time).total_seconds()
        if duration <= 0:
            logging.info("No positive duration since last record. Skipping insert.")
            return

        entry = {
            "username"      : self.username,
            "hostname"      : self.hostname,
            "timestamp"     : current_time,
            "status"        : f"{status}_end_of_day",
            "active_time"   : round(duration / 3600, 2) if status == "Active" else 0,
            "inactive_time" : round(duration / 3600, 2) if status == "Inactive" else 0,
            "note": "Auto-inserted at day change"
        }

        self.db.insert_pulse(entry)
        logging.info(f"Inserted end-of-day '{status}' entry: {entry}")

    except Exception as e:
        logging.exception(f"Failed to insert day change activity entry: {e}")

