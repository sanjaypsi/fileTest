import maya.OpenMaya as om
import maya.OpenMayaUI as omui
import maya.cmds as cmds
from shiboken2 import wrapInstance, isValid

class CallbackManager:
    """Manages attribute change callbacks for a Maya node."""

    def __init__(self, node_name, ui):
        """
        Initialize the CallbackManager.

        :param node_name: Name of the Maya node to monitor.
        :param slider_label_map: A dictionary mapping slider names to label names in the UI.
        :param ui: UI object containing sliders and labels.
        """
        self.node_name = node_name
        # self.slider_label_map = slider_label_map
        self.ui = ui
        self.callback_id = None

        # Attribute-slider pairs for different UI groups
        # self.attribute_slider_pairs   = {}
        self.attribute_slider_pairs = {
            'Main'    : {
                'con_world_L': [
                    ('all_scale',    'sliderSacler01',  'lineEditSacler01'),
                    ('all_translate',  'sliderSacler02', 'lineEditSacler02'),
                ],
            },
            'head'    : {
                'con_headScaleUp': [
                    ('size',    'HeadSliderSize',   'HeadLineEditSize'),
                    ('scaleX',  'HeadSliderScaleX', 'HeadLineEditScaleX'),
                    ('scaleY',  'HeadSliderScaleY', 'HeadLineEditScaleY'),
                    ('scaleZ',  'HeadSliderScaleZ', 'HeadLineEditScaleZ'),

                ],
                'con_headPosition': [
                    ('translateY', 'HeadSliderUpDn',    'HeadLineEditUpDn'),
                    ('translateZ', 'HeadSliderFntBack', 'HeadLineEditFntBack'),
                ],
                'con_headRotate': [
                    ('rotateY',  'HeadSliderRotate', 'HeadLineEditRotate'),
                ],
            },
            'Neck'    : {
                'con_headScaleDn': [
                    ('size', 'NeckUP_Size_SD', 'NeckUP_Size_LD'),
                    ('scaleY', 'NeckUP_ScaleY_SD', 'NeckUP_ScaleY_LD'),
                    ('scaleZ', 'NeckUP_ScaleZ_SD', 'NeckUP_ScaleZ_LD'),
                ],
                'con_neck': [
                    ('size',    'NeckDN_Size_SD',   'NeckDN_Size_LD'),
                    ('scaleY', 'NeckDN_ScaleY_SD', 'NeckDN_ScaleY_LD'),
                    ('scaleZ', 'NeckDN_ScaleZ_SD', 'NeckDN_ScaleZ_LD'),
                ],
                'con_neckPosition': [
                    ('translateY', 'NeckRootUP_Dn_SD', 'NeckRootUP_Dn_LD'),
                    ('translateZ', 'NeckRootFront_Back_SD', 'NeckRootFront_Back_LD'),
                ],
            },
            'Nose'    : {
                'con_headScaleDn': [
                    ('size',   'NoseTranslateY_SD', 'NoseTranslateY_LD'),
                    ('scaleY', 'NoseTranslateZ_SD', 'NoseTranslateZ_LD'),
                    ('scaleZ', 'NoseRotateX_SD',    'NoseRotateX_LD'),
                ],
                'con_neck': [
                    ('size',   'NoseScaleX_SD', 'NoseScaleX_LD'),
                    ('scaleY', 'NoseScaleY_SD', 'NoseScaleY_LD'),
                    ('scaleZ', 'NoseScaleZ_SD', 'NoseScaleZ_LD'),
                ],
            },
            'Ear'     : {
                'con_headScaleDn': [
                    ('size',   'EarTranslateX_SD', 'EarTranslateX_LD'),
                    ('scaleY', 'EarTranslateY_SD', 'EarTranslateY_LD'),
                    ('scaleZ', 'EarTranslateZ_SD', 'EarTranslateZ_LD'),
                ],
                'con_neck': [
                    ('size',   'EarScaleX_SD', 'EarScaleX_LD'),
                    ('scaleY', 'EarScaleY_SD', 'EarScaleY_LD'),
                    ('scaleZ', 'EarScaleZ_SD', 'EarScaleZ_LD'),
                ],
            },
            'Shoulder': {
                'con_upArmPosition_L': [
                    ('translateY', 'ShoulderUP_DN_SD', 'ShoulderUP_DN_LD'),
                    ('translateX', 'ShoulderWidth_SD', 'ShoulderWidth_LD'),
                    ('translateZ', 'ShoulderFT_BK_SD', 'ShoulderFT_BK_LD'),
                ],
                'adjust_clvclPosition_L': [
                    ('translateY', 'ClavicleUP_DN_SD', 'ClavicleUP_DN_LD'),
                    ('translateX', 'ClavicleWidth_SD', 'ClavicleWidth_LD'),
                    ('translateZ', 'ClavicleFT_BK_SD', 'ClavicleFT_BK_LD'),
                ],
            },
            'Arm'     : {
                'con_parameters': [
                    ('arm_length', 'ArmLength_SD', 'ArmLength_LD'),
                ],
                'con_upArm_L': [
                    ('size',   'ArmTopSize_SD',    'ArmTopSize_LD'),
                    ('scaleY', 'ArmTopScaleY_SD', 'ArmTopScaleY_LD'),
                    ('scaleZ', 'ArmTopScaleZSD', 'ArmTopScaleZ_LD'),
                ],
                'con_lowArmScaleUp_L': [
                    ('size',    'ArmMid_U_Size_SD', 'ArmMid_U_Size_LD'),
                    ('scaleY', 'ArmMid_U_SizeY_SD', 'ArmMid_U_SizeY_LD'),
                    ('scaleZ', 'ArmMid_U_SizeZ_SD', 'ArmMid_U_SizeZ_LD'),
                ],
                'con_lowArm_L': [
                    ('size',    'ArmMid_C_Size_SD', 'ArmMid_C_Size_LD'),
                    ('scaleY', 'ArmMid_C_SizeY_SD', 'ArmMid_C_SizeY_LD'),
                    ('scaleZ', 'ArmMid_C_SizeZ_SD', 'ArmMid_C_SizeZ_LD'),
                ],
                'con_lowArmScaleDn_L': [
                    ('size',    'ArmMid_D_Size_SD', 'ArmMid_D_Size_LD'),
                    ('scaleY', 'ArmMid_D_SizeY_SD', 'ArmMid_D_SizeY_LD'),
                    ('scaleZ', 'ArmMid_D_SizeZ_SD', 'ArmMid_D_SizeZ_LD'),
                ],
                'con_wristScaleUp_L': [
                    ('size',    'ArmMid_B_Size_SD', 'ArmMid_B_Size_LD'),
                    ('scaleY', 'ArmMid_B_SizeY_SD', 'ArmMid_B_SizeY_LD'),
                    ('scaleZ', 'ArmMid_B_SizeZ_SD', 'ArmMid_B_SizeZ_LD'),
                ], 
            },
            'Hand'    : {
                'con_hand_L': [
                    ('hand_scale',  'HandScale_SD',     'HandScale_LD'),
                    ('hand_width',  'HandWidth_SD',     'HandWidth_LD'),
                    ('finger_length', 'FingerLength_SD', 'FingerLength_LD'),
                    ('finger_width','FingerWidth_SD',   'FingerWidth_LD'),
                    ('palmSize',    'PalmSize_SD',      'PalmSize_LD'),
                ],
                'adjust_thuA_jtAdj_L': [
                    ('translateY', 'ThumbSlide_SD', 'ThumbSlide_LD'),
                    ('rotateZ', 'ThumbRotate_SD', 'ThumbRotate_LD'),
                ],
            },
            'Torso'   : {
                'con_parameters': [
                    ('torso_length', 'TorsoLength_SD',  'TorsoLength_LD'),
                    ('translateZ',   'TorsoBend_SD',    'TorsoBend_LD'),
                ],
                'con_spineCPosition': [
                    ('hip_position',  'HipPosition_SD', 'HipPosition_LD'),
                ],
                'con_hip': [
                    ('size',    'HipSize_SD', 'HipSize_LD'),
                    ('scaleY', 'HipScaleX_SD', 'HipScaleX_LD'),
                    ('scaleZ', 'HipScaleZ_SD', 'HipScaleZ_LD'),
                ],
                'con_spineA': [
                    ('size',    'SpineASize_SD',   'SpineASize_LD'),
                    ('scaleY', 'SpineAScaleX_SD', 'SpineAScaleX_LD'),
                    ('scaleZ', 'SpineAScaleZSD', 'SpineAScaleZ_LD'),
                ],
                'con_spineB': [
                    ('size',    'SpineBSize_SD',   'SpineBSize_LD'),
                    ('scaleY', 'SpineBScaleX_SD', 'SpineBScaleX_LD'),
                    ('scaleZ', 'SpineBScaleZSD', 'SpineBScaleZ_LD'),
                ],
                'con_spineC': [
                    ('size',    'SpineCSize_SD', 'SpineCSize_LD'),
                    ('scaleY', 'SpineCScaleX_SD', 'SpineCScaleX_LD'),
                    ('scaleZ', 'SpineCScaleZSD', 'SpineCScaleZ_LD'),
                ], 
            },
            'Leg'     : {
                'con_upLegRot_L': [
                    ('rotateY', 'LegAngle_SD',  'LegAngle_LD'),
                ],
                'con_parameters': [
                    ('leg_length',      'LegLength_SD', 'LegLength_LD'),
                    ('elbow_position',  'ElbowPosition_SD',  'ElbowPosition_LD'),
                    ('knee_position',   'KneePosition_SD',    'KneePosition_LD'),
                ],
                'con_upLeg_L': [
                    ('size',    'LefTopSize_SD', 'LefTopSize_LD'),
                    ('scaleY', 'LefTopScaleY_SD', 'LefTopScaleY_LD'),
                    ('scaleZ', 'LefTopScaleZ_SD', 'LefTopScaleZ_LD'),
                ],
                'con_lowLegScaleUp_L': [
                    ('size',    'LegMid_U_Size_SD',   'LegMid_U_Size_LD'),
                    ('scaleY', 'LefTop_U_ScaleY_SD', 'LegMid_U_ScaleY_LD'),
                    ('scaleZ', 'LefTop_U_ScaleZ_SD', 'LegMid_U_ScaleZ_LD'),
                ],
                'con_lowLeg_L': [
                    ('size',    'LegMid_C_Size_SD',   'LegMid_C_Size_LD'),
                    ('scaleY', 'LegMid_C_ScaleY_SD', 'LegMid_C_ScaleY_LD'),
                    ('scaleZ', 'LegMid_C_ScaleZ_SD', 'LegMid_C_ScaleZ_LD'),
                ],
                'con_lowLegScaleDn_L': [
                    ('size',    'LegMid_D_Size_SD', 'LegMid_D_Size_LD'),
                    ('scaleY', 'LegMid_D_ScaleY_SD', 'LegMid_D_ScaleY_LD'),
                    ('scaleZ', 'LegMid_D_ScaleZ_SD', 'LegMid_D_ScaleZ_LD'),
                ],
                'con_ankleScaleUp_L': [
                    ('size',    'LegMid_B_Size_SD', 'LegMid_B_Size_LD'),
                    ('scaleY', 'LegMid_B_ScaleY_SD', 'LegMid_B_ScaleY_LD'),
                    ('scaleZ', 'LegMid_B_ScaleZ_SD', 'LegMid_B_ScaleZ_LD'),
                ], 
            },
            'Foot'    : {
                'con_ankleScaleDn_L': [
                    ('size',    'FootSize_SD',    'FootSize_LD'),
                    ('scaleX',  'FootScaleX_SD',  'FootScaleX_LD'),
                    ('scaleY',  'FootScaleY_SD',  'FootScaleY_LD'),
                    ('scaleZ',  'FootScaleZ_SD',   'FootScaleZ_LD'),
                ],
                'con_ankle_L': [
                    ('rotateY', 'AnkleRotate_SD', 'AnkleRotate_LD'),
                ],
                'con_arch_L': [
                    ('rotateY', 'ArchRotate_SD', 'ArchRotate_LD'),
                ],
                'con_toe_L': [
                    ('rotateY', 'ToeRotate_SD', 'ToeRotate_LD'),
                ],               
            },
            'Adjust'    : {
                'con_parameters': [
                    ('torso_length',    'Torso_Length_SD',    'Torso_Length_LD'),
                    ('hip_position',    'Hip_Position_SD',    'Hip_Position_LD'),
                    ('arm_length',      'Arm_Length_SD',      'Arm_Length_LD'),
                    ('elbow_position',  'Elbow_Position_SD',  'Elbow_Position_LD'),
                    ('leg_length',      'Leg_Length_SD',      'Leg_Length_LD'),
                    ('knee_position',   'Knee_Position_SD',   'Knee_Position_LD'),
                ],
              
            },
        }

        # Create the necessary callbacks for the Maya node
        self.create_callbacks()

    def create_callbacks(self):
        """Create a callback for the specified Maya node."""
        if not cmds.objExists(self.node_name):
            print(f"Node '{self.node_name}' does not exist. Cannot create callback.")
            return

        selection_list      = om.MSelectionList()
        selection_list.add(self.node_name)
        self.node           = om.MObject()
        selection_list.getDependNode(0, self.node)
        self.callback_id    = om.MNodeMessage.addAttributeChangedCallback(self.node, self.attribute_changed)
        print(f"Callback created for node '{self.node_name}'.")

    def attribute_changed(self, msg, plug, other_plug, client_data):
        """
        Callback function to update sliders and labels when Maya attributes change.

        :param msg: Message from Maya.
        :param plug: Attribute that changed.
        :param other_plug: Other plug involved in the change (if any).
        :param client_data: Client data passed to the callback.
        """
        if msg & om.MNodeMessage.kAttributeSet:
            # Iterate over UI elements and their attribute mappings
            for ui_group, controls in self.attribute_slider_pairs.items():
                for control, mappings in controls.items():
                    
                    if control == self.node_name:  # Check if the callback is for this node
                        for attr_name, slider_name, label_name in mappings:
                            if plug.partialName(False, False, False, False, False, True) == attr_name:
                                # Get the current attribute value
                                value = cmds.getAttr(f"{self.node_name}.{attr_name}")

                                # Get the corresponding slider and label
                                slider  = getattr(self.ui, slider_name, None)
                                label   = getattr(self.ui, label_name, None)

                                # Update the slider
                                if slider and isValid(slider):
                                    slider.blockSignals(True)
                                    slider.setValue(int(value * 10))  # Assuming scaling factor
                                    slider.blockSignals(False)

                                # Update the label
                                if label and isValid(label):
                                    label.setText(f"{value:.1f}")  # Format to one decimal place

    def remove_callback(self):
        """Remove the callback when the window is closed."""
        if self.callback_id is not None:
            om.MMessage.removeCallback(self.callback_id)
            self.callback_id = None
            print("Callback removed.")
