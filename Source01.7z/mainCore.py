import os
import json
import maya.OpenMayaUI as omui
import maya.cmds as cmds
from functools import partial
from shiboken2 import wrapInstance
from PySide2.QtWidgets import QWidget, QMainWindow, QScrollArea, QVBoxLayout, QMessageBox
from PySide2.QtCore import QFile
from PySide2 import QtUiTools

import importlib

# External modules
import collapsedWidget
import collapsible
import callbackManager
import presetCore

importlib.reload(collapsible)
importlib.reload(collapsedWidget)
importlib.reload(callbackManager)

# Paths and Styles
SCRIPT_LOC 			= os.path.dirname(__file__)
collapseMainUI		= os.path.join(SCRIPT_LOC, 'ui', 'Global.ui')
collapseWidgetUI 	= os.path.join(SCRIPT_LOC, 'ui', 'Head.ui')
collapseNeckUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Neck.ui')
collapseNoseUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Nose.ui')
collapseEarUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Ear.ui')
collapseShoulderrUI = os.path.join(SCRIPT_LOC, 'ui', 'Shoulder.ui')
collapseArmUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Arm.ui')
collapseHandUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Hand.ui')
collapseTorsoUI 	= os.path.join(SCRIPT_LOC, 'ui', 'Torso.ui')
collapseLegUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Leg.ui')
collapseFootUI 		= os.path.join(SCRIPT_LOC, 'ui', 'Foot.ui')
collapseAdjustUI 	= os.path.join(SCRIPT_LOC, 'ui', 'adjust.ui')

# ============================================================================================================
def readyConfig():
	jsonPath = os.path.join(SCRIPT_LOC, 'config.json')
	
	# Check if the file exists
	if os.path.exists(jsonPath):
		with open(jsonPath, 'r', encoding='utf-8') as file:
			loaded_data = json.load(file)
			return loaded_data
	else:
		print(f"Config file not found at {jsonPath}")
		return None

# ============================================================================================================
SLIDER_STYLESHEET = """
				QSlider::groove:horizontal {
					border: 1px solid #999;
					height: 6px;
					background: #ccc;
					margin: 0px;
					border-radius: 3px;
				}
				QSlider::handle:horizontal {
					background: #5c5c5c;
					border: 1px solid #444;
					width: 14px;
					margin: -5px 0;
					border-radius: 7px;
				}
				QSlider::handle:horizontal:hover {
					background: #787878;
					border: 1px solid #555;
				}
				QSlider::sub-page:horizontal {
					background: #409eff;
					border: 1px solid #5a9;
					height: 6px;
					border-radius: 3px;
				}
				QSlider::add-page:horizontal {
					background: #ccc;
					border: 1px solid #999;
					height: 6px;
					border-radius: 3px;
				}
				"""

def get_maya_window():
	"""Get Maya's main window as a PySide2 object."""
	main_window_ptr = omui.MQtUtil.mainWindow()
	if not main_window_ptr:
		raise RuntimeError("Failed to obtain Maya's main window.")
	return wrapInstance(int(main_window_ptr), QWidget)  # Replace 'long' with 'int'

def load_ui(ui_file, parent=None):
	"""Load the .ui file and return the corresponding widget."""
	loader = QtUiTools.QUiLoader()
	ui_file = QFile(ui_file)
	if not ui_file.exists():
		raise FileNotFoundError("UI file {} not found.".format(ui_file.fileName()))
	ui_file.open(QFile.ReadOnly)
	ui_widget = loader.load(ui_file, parent)
	ui_file.close()
	if not ui_widget:
		raise RuntimeError("Failed to load UI file {}.".format(ui_file.fileName()))
	return ui_widget

class MyWindow(QMainWindow):
	"""Main UI Window."""
	def __init__(self, parent=None):
		super(MyWindow, self).__init__(parent)
		
		self.main_ui = os.path.join(SCRIPT_LOC, "ui", "main.ui")
		if not os.path.exists(self.main_ui):
			raise FileNotFoundError(f"UI file not found: {self.main_ui}")
		
		# Load UI
		self.ui = load_ui(self.main_ui, parent=self)
		self.setWindowTitle("Maya Attribute Controller")
		self.resize(600, 700)

		self.tabs 				= None
		self.MainUI				= None
		self.headUI 			= None
		self.NeckUI				= None
		self.NoseUI				= None
		self.EarUI 				= None
		self.ShoulderUI			= None
		self.ArmUI 				= None
		self.HandUI				= None
		self.TorsoUI			= None
		self.LegUI 				= None
		self.FootUI				= None
		self.AdjustUI			= None

		self.uiName_map     	={}
		self._dataConfig		={}
		self._dynamicUI			={}
		loaded_data 			=readyConfig()

		if 'SLIDER' in loaded_data:
			self._dataConfig = loaded_data['SLIDER']

		# if 'NAMEUI' in loaded_data:
		# 	self._dynamicUI = loaded_data['NAMEUI']
		# Configure UI
		self.create_menu_bar()
		self.add_ui_widget()
		self.connection()
		self.slider_StyleSheet()
		self.dynamic_connect_sliders()
		self.dynaicInitialize_ui_values()
		self.dynamicRest_value()
		self.dynamic_callback_connection()

	# =======================================================================================================
	# Create Custom MenuBar
	# =======================================================================================================
	def create_menu_bar(self):
		"""Create a menu bar for the application."""
		menu_bar = self.menuBar()

		# File menu
		file_menu = menu_bar.addMenu("File")
		file_menu.addAction("Open")
		file_menu.addAction("Save")
		file_menu.addSeparator()
		exit_action = file_menu.addAction("Exit")
		exit_action.triggered.connect(self.close)

		# Help menu
		help_menu 		= menu_bar.addMenu("Help")
		about_action 	= help_menu.addAction("About")
		about_action.triggered.connect(self.show_about_dialog)

	def show_about_dialog(self):
		"""Display an About dialog."""
		QMessageBox.about(self, "About", "Master File Manager ver2.0\nCreated using PySide2 for Maya.")
	
	# =======================================================================================================
	# Add Collapse Tab in Main UI : - collapseLegUI
	# =======================================================================================================
	def add_ui_widget(self):
		"""Add collapsible functionality to the layout."""
		self.MainUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseMainUI)._loadUI()
		self.headUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseWidgetUI)._loadUI()
		self.NeckUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseNeckUI)._loadUI()
		self.NoseUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseNoseUI)._loadUI()
		self.EarUI 		= collapsedWidget._loadWidget(widgetCollapse=collapseEarUI)._loadUI()
		self.ShoulderUI = collapsedWidget._loadWidget(widgetCollapse=collapseShoulderrUI)._loadUI()
		self.ArmUI 		= collapsedWidget._loadWidget(widgetCollapse=collapseArmUI)._loadUI()
		self.HandUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseHandUI)._loadUI()
		self.TorsoUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseTorsoUI)._loadUI()
		self.LegUI 		= collapsedWidget._loadWidget(widgetCollapse=collapseLegUI)._loadUI()
		self.FootUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseFootUI)._loadUI()
		self.AdjustUI 	= collapsedWidget._loadWidget(widgetCollapse=collapseAdjustUI)._loadUI()

		# Main layout of the UI (replace as needed)
		main_widget 	= QWidget()
		main_layout 	= QVBoxLayout(main_widget)

		# Set spacing between widgets
		main_layout.setSpacing(0)  # 15 pixels between widgets
		main_layout.setContentsMargins(0, 0, 0, 0)  # Left: 10px, Top: 20px, Right: 10px, Bottom: 20px

		# Define the list to store collapsible tabs
		self.tabs = []

		# Function to create a collapsible tab
		def create_tab(title, content):
			tab = collapsible.CollapsibleTab(title)
			tab.content_layout.addWidget(content)
			main_layout.addWidget(tab)
			tab.collapse()
			self.tabs.append(tab)

		create_tab("Head-Tab", 		self.headUI)
		create_tab("Neck-Tab", 		self.NeckUI)
		create_tab("Nose-Tab", 		self.NoseUI)
		create_tab("Ear-Tab", 		self.EarUI)
		create_tab("Shoulder-Tab", 	self.ShoulderUI)
		create_tab("Arm-Tab", 		self.ArmUI)
		create_tab("Hand-Tab", 		self.HandUI)
		create_tab("Torso-Tab", 	self.TorsoUI)
		create_tab("Leg-Tab", 		self.LegUI)
		create_tab("Foot-Tab", 		self.FootUI)
		create_tab("Main-Tab", 		self.MainUI)
		create_tab("Adjust-Tab", 	self.AdjustUI)

		main_layout.addStretch()

		# Add the main widget to a scroll area
		scroll_area = QScrollArea()
		scroll_area.setWidgetResizable(True)
		scroll_area.setWidget(main_widget)

		# Add the scroll area to a new tab in the tabWidget
		tab_widget = getattr(self.ui, "tabWidget", None)
		if tab_widget:
			tab_widget.addTab(scroll_area, " Options Tabs ")

		main_layout.setStretchFactor(tab_widget, 10)  # Tab widget should take more space

		self.expand_head_tab()

	def connection(self):
		"""Connect button actions to specific tab operations."""
		# Example connection for expanding the HEAD-TAB MainButton
		self.ui.MainButton.clicked.connect(lambda: self.expand_tab("Main-Tab"))
		self.ui.headButton.clicked.connect(lambda: self.expand_tab("Head-Tab"))
		self.ui.neckButton.clicked.connect(lambda: self.expand_tab("Neck-Tab"))
		self.ui.noseButton.clicked.connect(lambda: self.expand_tab("Nose-Tab"))
		self.ui.earButton.clicked.connect(lambda: self.expand_tab("Ear-Tab"))
		self.ui.shoulderButton.clicked.connect(lambda: self.expand_tab("Shoulder-Tab"))
		self.ui.armButton.clicked.connect(lambda: self.expand_tab("Arm-Tab"))
		self.ui.handButton.clicked.connect(lambda: self.expand_tab("Hand-Tab"))
		self.ui.torsoButton.clicked.connect(lambda: self.expand_tab("Torso-Tab"))
		self.ui.legButton.clicked.connect(lambda: self.expand_tab("Leg-Tab"))
		self.ui.footButton.clicked.connect(lambda: self.expand_tab("Foot-Tab"))
		self.ui.adjustButton.clicked.connect(lambda: self.expand_tab("Adjust-Tab"))

		self.ui.presetButton.clicked.connect(self.loadPrestUI)

	def expand_tab(self, tab_title):
		"""Collapse all tabs and expand only the specified tab."""
		for tab in self.tabs:
			if tab.toggle_button.text() == tab_title:
				tab.expand()  # Expand the specified tab
			else:
				tab.collapse()  # Collapse all other tabs

	def expand_head_tab(self):
		"""Collapse all tabs and expand only the specified tab."""
		for tab in self.tabs:
			if tab.toggle_button.text() == 'Head-Tab':
				tab.expand()

	def slider_StyleSheet(self):
		
		for ui_element, slider_mappings in self._dataConfig.items():
			# Determine the target UI object
			ui_object = None
			ui_object = getattr(self, f"{ui_element}UI", None) 	
			
			# Skip if no valid UI object is found
			if not ui_object:
				continue
			
			for sliderName, LineEdit, restBtn, contrl, attribute, value, restAll, restAttr in slider_mappings:
				# Apply the stylesheet if the slider exists
				if ui_object:
					slider = getattr(ui_object, sliderName, None)
					if slider:
						slider.setStyleSheet(SLIDER_STYLESHEET)
					else:
						print(f"Warning: Slider '{sliderName}' not found in {ui_element}.")

	# =======================================================================================================
	def dynamic_connect_sliders(self):
		"""Connect sliders and QLineEdits to update Maya attributes."""
		for ui_element, slider_mappings in self._dataConfig.items():
			# Determine the target UI object
			ui_object = None
			ui_object = getattr(self, f"{ui_element}UI", None) 

			# Skip if no valid UI object is found
			if not ui_object:
				continue
			
			for sliderName, LineEdit, restBtn, contrl, attribute, value, restAll, restAttr in slider_mappings:
				slider 		= getattr(ui_object, sliderName, None)
				line_edit 	= getattr(ui_object, str(LineEdit), None)

				# Connect slider to update Maya attribute and QLineEdit
				if slider:
					slider.valueChanged.connect(partial(self.dynamicUpdate_attribute_from_slider, line_edit,
														contrl, attribute, sliderName, ui_object
					)
				)

				# Connect QLineEdit to update Maya attribute and QSlider
				if line_edit and slider:
					line_edit.editingFinished.connect(partial(self.dynamicUpdate_slider_from_line_edit,
																line_edit, slider, attribute, contrl
					)
				)

	def dynamicUpdate_attribute_from_slider(self, line_edit, 
										 control, attribute, slider_name,  
										 Gui, slider_value):
		"""Update Maya attribute and QLineEdit when slider is moved."""
		float_value = slider_value / 10.0

		# Update Maya attribute
		if cmds.objExists(control):
			cmds.setAttr(f"{control}.{attribute}", float_value)

		# Update QLineEdit
		line_edit = getattr(Gui, str(line_edit), None)
		if line_edit:
			line_edit.setText(f"{float_value:.1f}")

	def dynamicUpdate_slider_from_line_edit(self, line_edit, slider, 
										 attribute, controlname):
		"""Update slider and Maya attribute when QLineEdit value is changed."""
		try:
			float_value 	= float(line_edit.text())
			slider_value 	= int(float_value * 10)

			# Update the QSlider
			slider.blockSignals(True)
			slider.setValue(slider_value)
			slider.blockSignals(False)

			# Update Maya attribute
			if cmds.objExists(controlname):
				cmds.setAttr(f"{controlname}.{attribute}", float_value)
		except ValueError:
			print("Invalid input in QLineEdit. Please enter a numeric value.")

	def dynaicInitialize_ui_values(self):
		"""Initialize slider and QLineEdit values with Maya attribute values."""
		"""Connect sliders and QLineEdits to update Maya attributes."""	
		for ui_element, slider_mappings in self._dataConfig.items():
			# Determine the target UI object
			ui_object = None

			# Get Dynamic Ui Name
			ui_object = getattr(self, f"{ui_element}UI", None)
			
			# Skip if no valid UI object is found
			if not ui_object:
				continue
			
			for sliderName, LineEdit, restBtn, contrl, attribute, value, restAll, restAttr in slider_mappings:
				current_value 	= cmds.getAttr(f"{contrl}.{attribute}")
				slider 			= getattr(ui_object, sliderName, None)
				line_edit 		= getattr(ui_object, LineEdit, None)

				if slider:
					slider.setValue(int(current_value * 10))
				
				if line_edit:
					line_edit.setText(f"{current_value:.1f}")

	def dynamicRest_value(self):
		# Iterate over UI elements and their attribute mappings
		for ui_element, slider_mappings in self._dataConfig.items():
			for slider_name, LineEditSize, restbtn, control, attribute, value, restAll, restAttr in slider_mappings:
				# Determine the target UI object
				ui_object 		= None

				# Get Dynamic Ui Name
				ui_object 		= getattr(self, f"{ui_element}UI", None)
				# Skip if no valid UI object is found
				if not ui_object:
					continue
				
				reset_all      	= getattr(ui_object, restAll, None)
				reset_button 	= getattr(ui_object, restbtn, None)
				line_edit 		= getattr(ui_object, str(LineEditSize), None)
				
				if reset_button:
					# Connect reset button to update Maya attribute
					reset_button.clicked.connect(
						lambda ctrl=control, attr=attribute, val=value: cmds.setAttr(f"{ctrl}.{attr}", float(val))
					)
					# Connect reset button to reset slider and line edit
					reset_button.clicked.connect(
						partial(self.reset_attribute, line_edit, slider_name, float(value), ui_object)
					)
				
				if reset_all:
					# Connect reset button to update Maya attribute
					reset_all.clicked.connect(
						lambda ctrl=control, attr=attribute, val=value: cmds.setAttr(f"{ctrl}.{attr}", float(val))
					)
					# Connect reset button to reset slider and line edit
					reset_all.clicked.connect(
						partial(self.reset_attribute, line_edit, slider_name, float(value), ui_object)
					)

	def reset_attribute(self, line_edit, slider_name, 
					 value, ui_object):
		slider 			= getattr(ui_object, slider_name, None)
		line_edit 		= getattr(ui_object, str(line_edit), None)

		if line_edit:
			line_edit.setText(f"{value:.1f}")

		if slider:
			slider.setValue(int(value * 10))  # Assuming scaling by 10 is correct dynamiccallback_manager

	# =======================================================================================================
	def dynamic_callback_connection(self):
		"""Initialize the Callback Manager"""
		for ui_element, slider_mappings in self._dataConfig.items():
			for slider_name, LineEdit, restbtn, control, attribute, value, restAll, restAttr in slider_mappings:
				# # Determine the target UI object
				ui_object = None

				# Get Dynamic Ui Name
				ui_object = getattr(self, f"{ui_element}UI", None)

				# Skip if no valid UI object is found
				if not ui_object:
					continue

				# callBack Manager function
				self.callback_manager = callbackManager.CallbackManager(control, slider_name, LineEdit, attribute, ui_object)

	def closeEvent(self, event):
		"""Clean up when the window is closed."""
		self.callback_manager.remove_callback()
		event.accept()

	def loadPrestUI(self):
		importlib.reload(presetCore)
		presetCore.show_window()

# ============================================================================================================
def show_window():
	"""Show the window."""
	global my_window
	try:
		my_window.close()
		my_window.deleteLater()
		
	except:  # noqa: E722
		pass
	my_window = MyWindow(parent=get_maya_window())
	my_window.show()