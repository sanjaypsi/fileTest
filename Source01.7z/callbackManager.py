import maya.OpenMaya as om
import maya.OpenMayaUI as omui
import maya.cmds as cmds
from shiboken2 import wrapInstance, isValid

class CallbackManager:
    """Manages attribute change callbacks for a Maya node."""
    def __init__(self, control, slider_name, LineEdit, attribute, ui_object):
        self.node_name          = control
        self.sliderName         = slider_name
        self.lineEdit           = LineEdit
        self.attribute          = attribute
        self.ui                 = ui_object
        self.callback_id        = None

        # Create the necessary callbacks for the Maya node
        self.create_callbacks()

    def create_callbacks(self):
        """Create a callback for the specified Maya node."""
        if not cmds.objExists(self.node_name):
            print(f"Node '{self.node_name}' does not exist. Cannot create callback.")
            return

        selection_list      = om.MSelectionList()
        selection_list.add(self.node_name)
        self.node           = om.MObject()
        selection_list.getDependNode(0, self.node)
        self.callback_id    = om.MNodeMessage.addAttributeChangedCallback(self.node, self.attribute_changed)
        print(f"Callback created for node '{self.node_name}'.")

    def attribute_changed(self, msg, plug, other_plug, client_data):
        """
        Callback function to update sliders and labels when Maya attributes change.

        :param msg: Message from Maya.
        :param plug: Attribute that changed.
        :param other_plug: Other plug involved in the change (if any).
        :param client_data: Client data passed to the callback.
        """
        if msg & om.MNodeMessage.kAttributeSet:
            if plug.partialName(False, False, False, False, False, True) == self.attribute:
                # Get the current attribute value
                value = cmds.getAttr(f"{self.node_name}.{self.attribute}")

                # Get the corresponding slider and label
                slider = getattr(self.ui, self.sliderName, None)
                label = getattr(self.ui, self.lineEdit, None)

                # Validate slider
                if slider and hasattr(slider, "blockSignals") and callable(slider.blockSignals):
                    slider.blockSignals(True)
                    slider.setValue(int(value * 10))  # Assuming scaling factor
                    slider.blockSignals(False)
                else:
                    print(f"Error: Slider for attribute '{self.attribute}' is not valid or not found.")

                # Validate label
                if label and hasattr(label, "setText") and callable(label.setText):
                    label.setText(f"{value:.1f}")  # Format to one decimal place
                else:
                    print(f"Error: Label for attribute '{self.lineEdit}' is not valid or not found.")

    def remove_callback(self):
        """Remove the callback when the window is closed."""
        if self.callback_id is not None:
            om.MMessage.removeCallback(self.callback_id)
            self.callback_id = None
            print("Callback removed.")


