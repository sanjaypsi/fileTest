import json
import os

# Path to where your presets are located (adjust as needed)
# ==========================================================================================================
SCRIPT_LOC 	= os.path.dirname(__file__)
icons 		= os.path.join(SCRIPT_LOC, 'resource')

# Define the LoadPreset class to load the JSON file
class LoadSelectPreset:
    def __init__(self, file_path, jsonFile):
        self._filePath      = file_path
        self._jsonFile      = jsonFile
        self._loaded_values = []  # Initialize an empty list to store the loaded preset data

    def load_from_json(self):
        """Load the stored values from a JSON file."""
        filePath = os.path.join(SCRIPT_LOC, self._filePath, self._jsonFile).replace('\\','/')

        if not filePath:
            print(f" FIND NOT FOUND:- {filePath}")

        # Open and load the JSON data from the file
        with open(filePath, "r") as json_file:
            loaded_data = json.load(json_file)

            # Check if the 'DATA' key is in the loaded data
            if "DATA" in loaded_data:
                self._loaded_values = loaded_data["DATA"]
                # print(f"Data successfully loaded from {filePath}")
                # print("Loaded values:", self._loaded_values)
            else:
                print(f"No 'DATA' key found in {filePath}")

        return self._loaded_values 


# # Example of how you might use the class:
# # This will instantiate the class, load the JSON data, and print the loaded values.
# file_path       = 'preset_data.json'  # Adjust the file name as needed
# preset_loader   = LoadPreset(file_path)
# preset_loader.load_from_json()
# loaded_values   = preset_loader.get_loaded_values()

# # Optionally, you can print or process the loaded values further:
# print("Accessed loaded values:", loaded_values)
