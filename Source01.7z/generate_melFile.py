
def create_dynamic_mel(file_path, proc_name, json_name):
    """
    Creates a dynamic MEL procedure and saves it to a .mel file.

    Args:
        file_path (str): Path where the MEL file will be created.
        proc_name (str): Name of the global procedure.
        json_name (str): Name of the JSON file to be processed.

    Returns:
        str: Path to the created MEL file.
    """

    proc = 'loadPreset'
    # Ensure the file ends with .mel
    if not file_path.endswith(".mel"):
        file_path += ".mel"

    # Construct the MEL procedure
    proc_body = f"""
    string $location = `whatIs "{proc_name}"`;
    string $buff1[];
    tokenize($location, " ", $buff1);
    string $dn = dirname($buff1[4]);
    string $file = "{json_name}.json";
    string $toval;

    // Import Python sys module
    $toval = "python(\\"import sys\\")";
    eval($toval);

    // Add the directory to sys.path if not already present
    $toval = "python(\\"if r'" + $dn + "' not in sys.path: sys.path.append(r'" + $dn + "')\\")";
    eval($toval);

    // Import the Python module
    $toval = "python(\\"import " + "{proc}" + "\\")";
    eval($toval);

    // Reload the Python module (for live updates during development)
    $toval = "python(\\"from importlib import reload; reload(" + "{proc}" + ")\\")";
    eval($toval);

    // Call the LoadPreset function from the module
    $toval = "python(\\"{proc}.LoadPreset(r'" + $file + "')\\")";
    eval($toval);
    """

    # Add the global proc definition
    proc_definition = f"global proc {proc_name}() {{\n{proc_body}\n}}\n\n{proc_name};"

    # Write the procedure to a MEL file
    with open(file_path, "w") as mel_file:
        mel_file.write(proc_definition)

    print(f"Dynamic MEL file created: {file_path}")
    return file_path


# # Example Usage
# mel_file_path   = os.path.join(os.getcwd(), "character01.mel")  # Save in current directory
# procedure_name  = "character01"  # Dynamic procedure name
# json_filename   = "character01"           # JSON file to process

# # Create the dynamic MEL file
# create_dynamic_mel(mel_file_path, procedure_name, json_filename)
