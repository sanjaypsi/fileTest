

class DynamicUI_List:

	def __init__(self):

		self.MainUI			= None
		self.headUI 		= None
		self.NeckUI			= None
		self.NoseUI			= None
		self.EarUI 			= None
		self.ShoulderUI		= None
		self.ArmUI 			= None
		self.HandUI			= None
		self.TorsoUI		= None
		self.LegUI 			= None
		self.FootUI			= None
		self.AdjustUI		= None

	def list_dynamic_ui(self):
		self.uiName_map 	= {
							"Main" 		: self.MainUI,
							"head" 		: self.headUI,
							'Neck'		: self.NeckUI,
							"Shoulder" 	: self.ShoulderUI,
							"Arm" 		: self.ArmUI,
							'Hand'		: self.HandUI,
							"Torso" 	: self.TorsoUI,
							"Leg" 		: self.LegUI,
							'Foot'		: self.FootUI,
							'Adjust' 	: self.AdjustUI,
						}
		
		return self.uiName_map
	