import maya.OpenMaya as om
import maya.cmds as cmds
import os
import json  # For JSON file handling
from datetime import datetime
import eST3 as eST
import getpass

PRESET 		= {
			'Main'        	: {
				'con_world_L': ['all_scale', 'all_translate'],
			},

			'head'        	: {
				'con_headScaleUp': ['size', 'scaleX', 'scaleY', 'scaleZ'],
				'con_headPosition': ['translateY', 'translateZ'],
				'con_headRotate': ['rotateY'],
			},

			'Neck'        	: {
				'con_headScaleDn': ['size', 'scaleY', 'scaleZ'],
				'con_neck': ['size', 'scaleY', 'scaleZ'],
				'con_neckPosition': ['translateY', 'translateZ'],
			},

			'Shoulder'   	: {
				'con_upArmPosition_L': ['translateY', 'translateX', 'translateZ'],
				'adjust_clvclPosition_L': ['translateY', 'translateX', 'translateZ'],
			},

			'Arm'         	: {
				'con_parameters': ['arm_length'],
				'con_upArm_L': ['size', 'scaleY', 'scaleZ'],
				'con_lowArmScaleUp_L': ['size', 'scaleY', 'scaleZ'],
				'con_lowArm_L': ['size', 'scaleY', 'scaleZ'],
				'con_lowArmScaleDn_L': ['size', 'scaleY', 'scaleZ'],
				'con_wristScaleUp_L': ['size', 'scaleY', 'scaleZ'],
			},

			'Hand'        	: {
				'con_hand_L': ['hand_scale', 'hand_width', 'finger_width', 'palmSize'],
				'adjust_thuA_jtAdj_L': ['translateY', 'rotateZ'],
			},

			'Torso'       	: {
				'con_parameters': ['torso_length', 'hip_position'],
				'con_spineCPosition': ['translateZ'],
				'con_hip': ['size', 'scaleY', 'scaleZ'],
				'con_spineA': ['size', 'scaleY', 'scaleZ'],
				'con_spineB': ['size', 'scaleY', 'scaleZ'],
				'con_spineC': ['size', 'scaleY', 'scaleZ'],
			},

			'Leg'         	: {
				'con_upLegRot_L': ['rotateY'],
				'con_parameters': ['leg_length', 'elbow_position', 'knee_position'],
				'con_upLeg_L': ['size', 'scaleY', 'scaleZ'],
				'con_lowLegScaleUp_L': ['size', 'scaleY', 'scaleZ'],
				'con_lowLeg_L': ['size', 'scaleY', 'scaleZ'],
				'con_lowLegScaleDn_L': ['size', 'scaleY', 'scaleZ'],
				'con_ankleScaleUp_L': ['size', 'scaleY', 'scaleZ'],
			},

			'Foot'        	: {
		'con_ankleScaleDn_L': ['size', 'scaleX', 'scaleY', 'scaleZ'],
		'con_ankle_L': ['rotateY'],
	}
		}
SCRIPT_LOC 	= os.path.dirname(__file__)

class SavePreset:
	def __init__(self, fullPath, file_path, Variation):
		
		self._stored_values = []  # To store data in the desired format
		self._information   = {}
		
		self._Variation		= Variation
		self._fullPath		= fullPath
		self._file_path 	= file_path

		self.storeValue()  # Call storeValue during initialization
		self.addInfo()
		self.save_to_json()

	def storeValue(self):
		"""Retrieve values from the PRESET structure and store them."""
		for ui_element, mappings in PRESET.items():  # Iterate over top-level keys and their mappings
			for control, attributes in mappings.items():  # Iterate over nested mappings
				for attribute in attributes:  # Iterate over the list of attributes
					try:
						# Retrieve the attribute value
						value = cmds.getAttr(f"{control}.{attribute}")
						# Format the data as "UIElement: control.attribute,value"
						formatted_data = f"{ui_element}:{control}.{attribute},{value}"
						# Store the formatted data
						self._stored_values.append(formatted_data)
						print(formatted_data)  # Debug print for confirmation

					except Exception as e:
						print(f"Error retrieving {control}.{attribute}: {e}")
	
	def addInfo(self):
		# The input string
		today 				= datetime.now()
		formatted_today 	= today.strftime("%a %b %d %H:%M:%S %Y")
		self._project 		= eST.Project().getName()
		username 			= getpass.getuser()

		self._information 	= {
				'Prest'		    :'Characterize Preset Scripts 3.0',
				'Creation Date' : formatted_today,
				'Project' 	    : self._project,
				'Variation' 	: self._Variation,
				'User'		    : username,
		}

	def save_to_json(self):
		"""Save the stored values to a JSON file."""
		# Ensure the file path is valid
		filePath = os.path.join(self._fullPath[0], self._file_path)
		
		# Prepare data for saving (change 'DATA' to your desired key)
		STORE = {
			"DATA": self._stored_values,
			"INFO": self._information,
		}
		try:
			with open(filePath, "w") as json_file:
				# Save the stored values as a JSON object
				json.dump(STORE, json_file, indent=4)
			print(f"Data successfully saved to {filePath}")
		except Exception as e:
			print(f"Error saving to JSON file: {e}")


# import importlib
# import savePreset as SP
# importlib.reload(SP)
# SP.SavePreset(preset_data.json, Variation)
