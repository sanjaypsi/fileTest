import os

def create_dynamic_py(file_path, proc_name):
    """
    Creates a dynamic Python procedure and saves it to a .py file.

    Args:
        file_path (str): Path where the Python file will be created.
        proc_name (str): Name of the global procedure.

    Returns:
        str: Path to the created Python file.
    """
    e 				= 'e'
    set_attr 		= 'set_attr'
    value 			= 'value'
    attribute_info 	= 'attribute_info'
    item 			= 'item'
    
    # Ensure the file ends with .py
    # if not file_path.endswith("loadPreset"):
    #     file_path += "loadPreset"

    # Construct the Python procedure with dynamic procedure name
    proc_body = f"""
import json
import os
import maya.cmds as cmds

# Path to where your presets are located (adjust as needed)
SCRIPT_LOC = os.path.dirname(__file__)

# Define the {proc_name} class to load the JSON file
class {proc_name}:
    def __init__(self, file_path):
        self._file_path = file_path
        self._loaded_values = []  # Initialize an empty list to store the loaded preset data

        self.load_from_json()

    def load_from_json(self):
        # Load the stored values from a JSON file.
        file_path = os.path.join(SCRIPT_LOC, self._file_path)
        
        if not os.path.exists(file_path):
            print(f"File not found: {file_path}")
            return

        try:
            # Open and load the JSON data from the file
            with open(file_path, "r") as json_file:
                loaded_data = json.load(json_file)

                # Check if the 'DATA' key is in the loaded data
                if "DATA" in loaded_data:
                    self._loaded_values = loaded_data["DATA"]
                    print(f"Data successfully loaded from {file_path}")
                    print("Loaded values:", self._loaded_values)
                else:
                    print(f"No 'DATA' key found in {file_path}")
                    return
        except Exception as ex:  # Use 'ex' as the exception variable
            print(f"Error loading JSON file: {e}")
            return

        # Iterate through the loaded values and set Maya attributes
        for item in self._loaded_values:
            try:
                # Parse the attribute and value
                if ':' in item:
                    attribute_info = item.split(':')[1]
                    if ',' in attribute_info:
                        set_attr, value = attribute_info.split(',')

                        # Convert the value to a proper type (int/float if applicable)
                        try:
                            value = float(value) if '.' in value else int(value)
                        except ValueError:
                            value = value.strip()  # Keep it as a string if conversion fails

                        # Set the attribute in Maya
                        if cmds.objExists(set_attr):
                            cmds.setAttr(set_attr, value)
                            print(f"Set attribute: {set_attr} to value: {value}")
                        else:
                            print(f"Attribute does not exist: {set_attr}")
                    else:
                        print(f"Invalid format for attribute data: {attribute_info}")
                else:
                    print(f"Invalid format for item: {item}")
            except Exception as e:
                print(f"Error processing item '{item}': {e}")
    """

    # Write the procedure to a py file
    PATH = os.path.join(file_path, "loadPreset.py")
    with open(PATH, "w") as py_file:
        py_file.write(proc_body)

    print(f"Dynamic Python file created: {PATH}")

# Example usage:
# create_dynamic_py("load_preset.py", "LoadPreset")
