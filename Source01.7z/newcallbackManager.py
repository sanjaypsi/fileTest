import maya.OpenMaya as om
import maya.OpenMayaUI as omui
import maya.cmds as cmds
from PySide2 import QtWidgets, QtCore
import shiboken2 as sip


class CallbackManager:
    def __init__(self, control, slider_name, LineEdit, attribute, ui_object):
        self.node_name = control
        self.slider_label_map = slider_name
        self.lineEdit = LineEdit
        self.attribute = attribute
        self.ui = ui_object
        self.callback_id = None

        # Connect the UI's destroyed signal to remove callbacks
        if self.is_valid_ui_object(self.ui):
            self.ui.destroyed.connect(self.remove_callback)

    def is_valid_ui_object(self, obj):
        """
        Check if the PySide2 UI object is still valid.
        """
        try:
            return obj is not None and not sip.isdeleted(obj)
        except Exception:
            return False

    def attribute_changed(self, msg, plug, other_plug, client_data):
        """
        Callback function to handle Maya attribute changes and update the UI components.
        """
        if not (msg & om.MNodeMessage.kAttributeSet):
            return

        try:
            # Check if the UI itself is valid
            if not self.is_valid_ui_object(self.ui):
                print("UI object is no longer valid.")
                return

            # Get the attribute name
            attr_name = plug.partialName()

            if attr_name != self.attribute:
                return

            # Get the updated attribute value
            value = cmds.getAttr(f"{self.node_name}.{attr_name}")

            # Update slider
            slider = getattr(self.ui, self.slider_label_map, None)
            if self.is_valid_ui_object(slider):
                slider.blockSignals(True)
                slider.setValue(int(value * 10))
                slider.blockSignals(False)
            else:
                print("Slider object is no longer valid.")

            # Update LineEdit
            if self.is_valid_ui_object(self.lineEdit):
                self.lineEdit.setText(f"{value:.3f}")
            else:
                print("LineEdit object is no longer valid.")

        except Exception as e:
            print(f"Error in attribute_changed: {e}")

    def add_callback(self):
        """
        Add a callback to listen for attribute changes on the specified node and attribute.
        """
        try:
            sel_list = om.MSelectionList()
            sel_list.add(self.node_name)
            m_object = om.MObject()
            sel_list.getDependNode(0, m_object)

            self.callback_id = om.MNodeMessage.addAttributeChangedCallback(
                m_object, self.attribute_changed
            )
            print(f"Callback added for {self.node_name}.{self.attribute}")

        except Exception as e:
            print(f"Error adding callback: {e}")

    def remove_callback(self):
        """
        Remove the callback to stop listening for attribute changes.
        """
        if self.callback_id:
            try:
                om.MMessage.removeCallback(self.callback_id)
                print("Callback removed.")
                self.callback_id = None
            except Exception as e:
                print(f"Error removing callback: {e}")


# Example Maya UI and usage
# if __name__ == "__main__":
#     # Create a PySide2-based example UI
#     class ExampleUI(QtWidgets.QWidget):
#         def __init__(self, parent=None):
#             super().__init__(parent)
#             self.setWindowTitle("Maya Attribute Callback Example")
#             self.resize(300, 150)

#             # Create a slider and line edit
#             self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
#             self.slider.setMinimum(0)
#             self.slider.setMaximum(100)

#             self.lineEdit = QtWidgets.QLineEdit()

#             # Create a layout and add widgets
#             layout = QtWidgets.QVBoxLayout(self)
#             layout.addWidget(self.slider)
#             layout.addWidget(self.lineEdit)

#     # Example Maya node and attribute setup
#     control = "pSphere1"  # Replace with an actual Maya node
#     attribute = "translateX"  # Replace with an actual attribute

#     # Create the UI
#     app = QtWidgets.QApplication.instance()
#     if not app:
#         app = QtWidgets.QApplication([])
#     ui = ExampleUI()

#     # Initialize and connect the callback manager
#     callback_manager = CallbackManager(control, "slider", ui.lineEdit, attribute, ui)
#     callback_manager.add_callback()

#     # Show the UI
#     ui.show()

#     # For standalone testing outside of Maya
#     app.exec_()
