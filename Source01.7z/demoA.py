import json

# Combined data structure
data = {
    "SLIDER": {
        "scaler": {
            "sliderSacler01": 0.5,
            "sliderSacler02": 0.5,
            "sliderSacler03": 0.5,
            "sliderSacler04": 0.5
        },
        "head": {
            "HeadSliderSize": 0.5,
            "HeadLineEditSize": 0.5,
            "HeadRestSize": 0.5,
            "con_headScaleUp": 0.5,
            "scaleButton": 0.5,
            "restAll_AttrBiuteButton": 0.5
        },
        "neck": {
            "NeckSliderSize": 0.5,
            "NeckLineEditSize": 0.5,
            "NeckRestSize": 0.5,
            "con_neckScaleUp": 0.5
        },
        "shoulder": {
            "ShoulderSliderSize": 0.5,
            "ShoulderLineEditSize": 0.5,
            "ShoulderRestSize": 0.5
        },
        "torso": {
            "TorsoSliderSize": 0.5,
            "TorsoLineEditSize": 0.5,
            "TorsoRestSize": 0.5
        },
        "legs": {
            "LegSliderSize": 0.5,
            "LegLineEditSize": 0.5,
            "LegRestSize": 0.5
        }
    },
    "uiName_map": {
        "sliderSacler01": "Slider 1",
        "sliderSacler02": "Slider 2",
        "sliderSacler03": "Slider 3",
        "sliderSacler04": "Slider 4",
        "HeadSliderSize": "Head Size Slider",
        "HeadLineEditSize": "Head Size Line Edit",
        "HeadRestSize": "Head Size Reset",
        "con_headScaleUp": "Head Scale Up",
        "scaleButton": "Scale Button",
        "restAll_AttrBiuteButton": "Reset All Button",
        "NeckSliderSize": "Neck Size Slider",
        "NeckLineEditSize": "Neck Size Line Edit",
        "NeckRestSize": "Neck Size Reset",
        "con_neckScaleUp": "Neck Scale Up",
        "ShoulderSliderSize": "Shoulder Size Slider",
        "ShoulderLineEditSize": "Shoulder Size Line Edit",
        "ShoulderRestSize": "Shoulder Size Reset",
        "TorsoSliderSize": "Torso Size Slider",
        "TorsoLineEditSize": "Torso Size Line Edit",
        "TorsoRestSize": "Torso Size Reset",
        "LegSliderSize": "Leg Size Slider",
        "LegLineEditSize": "Leg Size Line Edit",
        "LegRestSize": "Leg Size Reset"
    }
}

# Saving to a file
with open('combined_data.json', 'w') as f:
    json.dump(data, f, indent=4)
