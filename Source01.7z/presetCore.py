import os
import sys
import maya.cmds as cmds
from PySide2.QtWidgets import QWidget, QMainWindow
from PySide2 import QtCore, QtUiTools
import maya.OpenMayaUI as omui
import maya.OpenMaya as om
from shiboken2 import wrapInstance
import eST3 as eST
import json

import importlib
import savePreset
import generate_melFile
import generate_pyFile
import presetLoad

importlib.reload(savePreset)
importlib.reload(generate_melFile)
importlib.reload(generate_pyFile)
importlib.reload(presetLoad)

# ==========================================================================================================
SCRIPT_LOC 	= os.path.dirname(__file__)
icons 		= os.path.join(SCRIPT_LOC, 'resource')
subfolder 	= ['CharacterizeRig3.0', 'project', 'presets']

# ==========================================================================================================
def get_maya_window():
	"""Get Maya's main window as a PySide2 object."""
	main_window_ptr = omui.MQtUtil.mainWindow()
	if not main_window_ptr:
		raise RuntimeError("Failed to obtain Maya's main window.")
	return wrapInstance(int(main_window_ptr), QWidget)

# ==========================================================================================================
def load_ui(ui_file, parent=None):
	"""Load the .ui file and return the corresponding widget."""
	loader = QtUiTools.QUiLoader()
	ui_file = QtCore.QFile(ui_file)
	
	if not ui_file.exists():
		raise FileNotFoundError(f"UI file {ui_file.fileName()} not found.")
	ui_file.open(QtCore.QFile.ReadOnly)
	ui_widget = loader.load(ui_file, parent)
	ui_file.close()
	
	if not ui_widget:
		raise RuntimeError(f"Failed to load UI file {ui_file.fileName()}.")
	return ui_widget

# ==========================================================================================================
class PresetWindow(QMainWindow):
	"""Main window class."""
	def __init__(self, parent=None):
		super(PresetWindow, self).__init__(parent)
		self.main_ui = os.path.join(SCRIPT_LOC, "ui", "Preset.ui")
		
		if not os.path.exists(self.main_ui):
			raise FileNotFoundError(f"UI file not found: {self.main_ui}")
		self.ui = load_ui(self.main_ui, parent=self)
		if not self.ui:
			raise RuntimeError("UI failed to load.")
		
		# Setup the window
		self.setWindowTitle("Save / Load Preset ver3.0")
		self.resize(600, 250)
		self.setCentralWidget(self.ui)
		self.init_ui()

		self.name 		= []
		self._project 	= eST.Project().getName()
		self._fullPath  = os.path.join(SCRIPT_LOC, subfolder[0], self._project, subfolder[2])
		self._data		= []
		self.ui.splitter_2.setSizes([300, 200]) 
		
		self._checkBox = {
						'checkBox_1'	: 	'head',
						'checkBox_2'	: 	'Neck', 
						# 'checkBox_3'	:	'Nose', 
						# 'checkBox_4'	:	'Ear',	
						'checkBox_5'	:	'Shoulder',
						'checkBox_6'	:	'Arm', 
						'checkBox_7'	:	'Hand',	
						'checkBox_8'	:	'Torso', 
						'checkBox_9'	:	'Leg', 
						'checkBox_10'	:	'Foot',
						'checkBox_11'	:	'Main',
					}

		self.createConnections()
		self.load_character()

	def init_ui(self):
		"""Initialize the UI."""
		self.ui.destroyed.connect(self.on_exit_code)

	def createConnections(self):
		# """Create the signal/slot connections."""
		# self.ui.sliderSacler.valueChanged.connect(self.update_sphere_translation)
		self.ui.saveButton.clicked.connect(self.save_the_Preset)
		self.ui.characterWidget.selectionModel().selectionChanged.connect(self.get_selected_item)
		self.ui.toggleCheckBox.stateChanged.connect(self.toggle_checkBox)
		self.ui.loadButton.clicked.connect(self.load_select_preset)

	def on_exit_code(self):
		"""Cleanup when the UI is closed."""
		sys.stdout.write("UI successfully closed\n")
		self.deleteLater()
	
	def load_character(self):
		joinfullpath 	= self._fullPath
		extension 		= '.mel'
		if os.path.exists:
			files = [f for f in os.listdir(joinfullpath) if f.endswith(extension)]
			for charList in files:
				_name = charList.split('.')[0]
				self.ui.characterWidget.addItem(_name)

	def add_character(self):
		self.name 	= self.ui.lineEdit.text()
		# Get the total number of items in the QListWidget
		item_count 	= self.ui.characterWidget.count()

		# Create a list to store the text of all items
		all_items 	= []
		# Loop through each item in the QListWidget
		for index in range(item_count):
			item = self.ui.characterWidget.item(index)  # Get the item at the specified index
			all_items.append(item.text())               # Add the item's text to the list

		# Check if the name exists in the list
		for index, item_text in enumerate(all_items):
			if self.name == item_text:
				# Remove the existing item from the QListWidget
				self.ui.characterWidget.takeItem(index)

		# Add the text to QListWidget if not empty
		if self.name.strip():
			self.ui.characterWidget.addItem(self.name)
			self.ui.lineEdit.clear()  # Clear the input field
		else:
			print("Name input is empty!")

		return self.name

	def get_selected_item(self):
		# Get the list of selected items
		itemSelected 	= []
		selected_items 	= self.ui.characterWidget.selectedItems()
		
		# Check if there are selected items
		if selected_items:
			for item in selected_items:
				print(f"Selected item: {item.text()}")
				itemSelected.append(item.text())
		else:
			print("No item selected.")

		file_path = os.path.join(self._fullPath, itemSelected[0]).replace('\\', '/') + '.json'
		self.load_json_file(file_path)

	def load_json_file(self, file_path):
		
		metaData = []
		# Example function to load a JSON file
		# Assuming file_path contains the path to your JSON file
		with open(file_path, 'r') as f:  # Open the file in read mode
			data = json.load(f)  # Parse the JSON content into a Python object

		# Get the 'INFO' section from the JSON
		data = data.get('INFO', {})
		# Format each key-value pair without quotes and append it to metaData
		for key, value in data.items():
			metaData.append(f"{key}: {value}")

		# Join all key-value pairs with a comma and space, and set the text in QTextEdit
		metaData_str = ',\n'.join(metaData)  # Add newline after each item for better readability
		# Assuming self.ui.textEdit is a QTextEdit widget
		self.ui.textEdit.setText(metaData_str)

	def save_the_Preset(self):
		characterName 	= '.'.join([self.add_character(), 'json'])
		jsonFile 		= characterName
		Variation 		= 'Variation'
		fullPath       	= self._fullPath,
		savePreset.SavePreset(fullPath, jsonFile, Variation)

		# Example Usage
		fileName  		= self.name+'.mel'
		mel_file_path   = os.path.join(self._fullPath, fileName)  # Save in current directory
		procedure_name  = 'presetLoad'  # Dynamic procedure name
		json_filename   = self.name  	# JSON file to process

		# Create the dynamic MEL file
		generate_melFile.create_dynamic_mel(mel_file_path, procedure_name, json_filename)

		joinfullpath 	= self._fullPath
		proc_name 		= 'presetLoad'
		if os.path.exists:
			files = [f for f in os.listdir(joinfullpath) if f.endswith('.py')]
			if files:
				pass
			else:
				print(joinfullpath, proc_name)
				generate_pyFile.create_dynamic_py(joinfullpath, proc_name)
	
	def toggle_checkBox(self):
		for ui_group, controls in self._checkBox.items():
			checkBox = getattr(self.ui, ui_group, None)
			if checkBox:
				if self.ui.toggleCheckBox.isChecked():
					checkBox.setChecked(True)
				else:
					checkBox.setChecked(False)

	def load_select_preset(self):
		# Get the list of selected items
		itemSelected 	= []
		selected_items 	= self.ui.characterWidget.selectedItems()
		
		# Check if there are selected items
		if selected_items:
			for item in selected_items:
				print(f"Selected item: {item.text()}")
				itemSelected.append(item.text())
		else:
			print("No item selected.")

		jsonFile 	= str(itemSelected[0]+'.json')
		fullPath 	= self._fullPath
		PLoad		= presetLoad.LoadSelectPreset(fullPath, str(jsonFile) )
		self._data 	= PLoad.load_from_json()
		data 		= self._data 
		self.preset_load(data)

	def preset_load(self, data):
		isChecks = []
		for ui_group, controls in self._checkBox.items():
			checkBox = getattr(self.ui, ui_group, None)
			if checkBox:
				if checkBox.isChecked():
					isChecks.append(controls)
		
		for dataItem in data:
			attrbiute = dataItem.startswith(tuple(isChecks))
			if attrbiute:
				try:
					# Parse the attribute and value
					if ':' in dataItem:
						attribute_info = dataItem.split(':')[1]
						if ',' in attribute_info:
							set_attr, value = attribute_info.split(',')
							# Convert the value to a proper type (int/float if applicable)
							try:
								value = float(value) if '.' in value else int(value)
							except ValueError:
								value = value.strip()  # Keep it as a string if conversion fails
							# Set the attribute in Maya
							if cmds.objExists(set_attr):
								cmds.setAttr(set_attr, value)
								print(f"Set attribute: set_attr to value: value")
							else:
								print(f"Attribute does not exist: set_attr")
						else:
							print(f"Invalid format for attribute data: attribute_info")
					else:
						print(f"Invalid format for item: item")
				except Exception as e:
					print(f"Error processing item 'item': e")
	
# ==========================================================================================================
def show_window():
	"""Show the window."""
	global my_window
	if 'my_window' in globals() and my_window is not None:
		try:
			my_window.close()  # Close the window if it already exists
			my_window.deleteLater()
		
		except:
			pass

	my_window = PresetWindow(parent=get_maya_window())
	my_window.show()