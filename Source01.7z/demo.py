import json
import os


# Specify the file path to save the JSON data
SCRIPT_LOC = os.path.dirname(os.path.abspath(__file__))  # Path where the script is located
json_path = os.path.join(SCRIPT_LOC, 'combined_data.json')


import json
import os

# # SLIDERATTRMAP dictionary with tuples converted to lists
# SLIDERATTRMAP = {
#     'Main': [
#         ['sliderSacler01', 'lineEditSacler01', 'AllRestSize_BT', 'con_world_L', 'all_scale', '1', 'button', 'restAll_AttrBiuteButton'],
#         ['sliderSacler02', 'lineEditSacler02', 'AllRestTranslate_BT', 'con_world_L', 'all_translate', '0', 'button', 'restAll_AttrBiuteButton'],
#     ]
# }

# # Specify the file path to save the JSON data
# SCRIPT_LOC = os.path.dirname(os.path.abspath(__file__))  # Path where the script is located
# json_path = os.path.join(SCRIPT_LOC, 'config.json')

# # Write the data to the file
# try:
#     with open(json_path, 'w', encoding='utf-8') as file:
#         json.dump(SLIDERATTRMAP, file, indent=4)
#     print(f"Data has been written to {json_path}")
# except Exception as e:
#     print(f"Error writing to file: {e}")


#loaded_data['SLIDER'] or loaded_data['uiName_map'].


import json

json_path = 'combined_data.json'  # Path to your JSON file


# Load the data from the file
with open(json_path, 'r', encoding='utf-8') as file:
    loaded_data = json.load(file)

# Ensure 'SLIDER' is a key in the dictionary and iterate through it
if 'NAMEUI' in loaded_data:
    value = loaded_data['NAMEUI']
    
    # If the value under 'SLIDER' is a list, iterate over the list
    if isinstance(value, dict):
        for sub_key, sub_value in value.items():
            print(f"{sub_key}: {sub_value}")

else:
    print("'SLIDER' key not found in the data.")

# # Iterate through the loaded data
# for key, value in loaded_data.items():
#     # Check if the value is a dictionary
#     if isinstance(value, dict):
#         for sub_key, sub_value in value.items():
#             print(f"  {sub_value}")
#     else:
#         print(f"  Value is not a dictionary: {value}")

